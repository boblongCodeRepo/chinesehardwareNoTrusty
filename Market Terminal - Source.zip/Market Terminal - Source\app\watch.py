"""Influence Watch - who is pushing which narrative, and who is documented as being paid to.

News: ~65 RSS feeds - US government, US media across the spectrum, international media, publicly funded
international broadcasters (VOA, RFE/RL, BBC, DW, France 24, Al Jazeera), state-controlled media of Russia, China,
Iran and Venezuela, and disinformation researchers. Items are archived locally (SQLite) so history builds up while
the app runs.

Money: only public disclosure records -
  * DOJ FARA (Foreign Agents Registration Act): who is registered as working for which foreign government/party
  * LDA lobbying disclosures (lda.gov): lobbying for foreign clients / foreign-linked entities
  * FEC itemized contributions: what a person gave to which political committees

Narrative analytics (stories, framing terms, phrase echoes, state-media profile) are descriptive SIGNALS of
narrative overlap - shared quotes, wire copy and genuine news all produce overlap. They are not evidence that anyone
is coordinated or paid; only the disclosure records show money.
"""
from __future__ import annotations

import calendar
import csv
import hashlib
import html
import io
import json
import math
import os
import re
import sqlite3
import threading
import time
import zipfile
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import quote_plus

import feedparser
import requests

DATA_DIR = Path(os.environ.get("MT_DATA_DIR") or Path(os.environ.get("LOCALAPPDATA", Path.home())) / "MarketTerminal")
WDIR = DATA_DIR / "influence"
WDIR.mkdir(parents=True, exist_ok=True)

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Safari/537.36"
S = requests.Session()
S.headers.update({"User-Agent": UA, "Accept-Language": "en-US,en;q=0.9",
                  "Accept": "application/rss+xml, application/xml, text/xml, application/json, */*"})

REFRESH = 15 * 60          # feed refresh while the app is open
KEEP_DAYS = 120            # archive retention


def _gn(q):
    return f"https://news.google.com/rss/search?q={quote_plus(q)}&hl=en-US&gl=US&ceid=US:en"


GROUPS = {
    "usgov": "US Government",
    "us": "US Media",
    "intl": "International Media",
    "public": "Publicly Funded Intl Broadcasters",
    "state": "State-Controlled Media",
    "research": "Disinformation Research",
}
COUNTRIES = {"RU": "Russia", "CN": "China", "IR": "Iran", "VE": "Venezuela", "US": "United States",
             "UK": "United Kingdom", "DE": "Germany", "FR": "France", "QA": "Qatar", "EU": "European Union",
             "HK": "Hong Kong", "JP": "Japan"}
STATE_CC = ["RU", "CN", "IR", "VE"]

# key, outlet name, group, country, url, ownership note
_SRC = [
    # --- US government
    ("whitehouse", "White House", "usgov", "US", "https://www.whitehouse.gov/news/feed/", "Executive Office of the President"),
    ("state", "State Dept", "usgov", "US", "https://www.state.gov/rss-feed/press-releases/feed/", "US Department of State press releases"),
    ("dod", "Defense Dept", "usgov", "US", "https://www.defense.gov/DesktopModules/ArticleCS/RSS.ashx?ContentType=1&Site=945&max=10", "US Department of Defense releases"),
    ("doj", "Justice Dept", "usgov", "US", "https://www.justice.gov/news/rss?type=press_release&m=1", "US Department of Justice press releases (incl. National Security Division: FARA, espionage, foreign influence cases)"),
    ("fbi", "FBI", "usgov", "US", "https://www.fbi.gov/feeds/national-press-releases/rss.xml", "FBI national press releases"),
    ("gao", "GAO", "usgov", "US", "https://www.gao.gov/rss/reports.xml", "Government Accountability Office reports"),
    # --- US media (alphabetical, no lean labels)
    ("ap", "AP", "us", "US", _gn("site:apnews.com when:2d"), "Associated Press (via Google News)"),
    ("reuters", "Reuters", "us", "US", _gn("site:reuters.com when:2d"), "Reuters (via Google News)"),
    ("abc", "ABC News", "us", "US", "https://abcnews.go.com/abcnews/topstories", ""),
    ("axios", "Axios", "us", "US", "https://api.axios.com/feed/", ""),
    ("breitbart", "Breitbart", "us", "US", "https://feeds.feedburner.com/breitbart", ""),
    ("cbs", "CBS News", "us", "US", "https://www.cbsnews.com/latest/rss/main", ""),
    ("cnbc", "CNBC", "us", "US", "https://www.cnbc.com/id/100003114/device/rss/rss.html", ""),
    ("cnn", "CNN", "us", "US", "http://rss.cnn.com/rss/cnn_topstories.rss", ""),
    ("dailycaller", "Daily Caller", "us", "US", "https://dailycaller.com/feed/", ""),
    ("dailywire", "Daily Wire", "us", "US", "https://www.dailywire.com/feeds/rss.xml", ""),
    ("federalist", "The Federalist", "us", "US", "https://thefederalist.com/feed/", ""),
    ("fox", "Fox News", "us", "US", "https://moxie.foxnews.com/google-publisher/latest.xml", ""),
    ("foxpol", "Fox News", "us", "US", "https://moxie.foxnews.com/google-publisher/politics.xml", ""),
    ("huffpost", "HuffPost", "us", "US", "https://chaski.huffpost.com/us/auto/vertical/politics", ""),
    ("intercept", "The Intercept", "us", "US", "https://theintercept.com/feed/?rss", ""),
    ("latimes", "LA Times", "us", "US", "https://www.latimes.com/world-nation/rss2.0.xml", ""),
    ("motherjones", "Mother Jones", "us", "US", "https://www.motherjones.com/feed/", ""),
    ("nationalreview", "National Review", "us", "US", "https://www.nationalreview.com/feed/", ""),
    ("nbc", "NBC News", "us", "US", "https://feeds.nbcnews.com/nbcnews/public/news", ""),
    ("newsmax", "Newsmax", "us", "US", _gn("site:newsmax.com when:2d"), "via Google News (direct feed times out)"),
    ("npr", "NPR", "us", "US", "https://feeds.npr.org/1001/rss.xml", ""),
    ("nypost", "New York Post", "us", "US", "https://nypost.com/feed/", ""),
    ("nyt", "New York Times", "us", "US", "https://rss.nytimes.com/services/xml/rss/nyt/HomePage.xml", ""),
    ("pbs", "PBS NewsHour", "us", "US", "https://www.pbs.org/newshour/feeds/rss/headlines", ""),
    ("politico", "Politico", "us", "US", "https://rss.politico.com/politics-news.xml", ""),
    ("reason", "Reason", "us", "US", "https://reason.com/feed/", ""),
    ("thehill", "The Hill", "us", "US", "https://thehill.com/feed/", ""),
    ("vox", "Vox", "us", "US", "https://www.vox.com/rss/index.xml", ""),
    ("wapo", "Washington Post", "us", "US", "https://feeds.washingtonpost.com/rss/politics", ""),
    ("washexaminer", "Washington Examiner", "us", "US", "https://www.washingtonexaminer.com/feed/", ""),
    ("washtimes", "Washington Times", "us", "US", "https://www.washingtontimes.com/rss/headlines/news/", ""),
    ("wsj", "Wall Street Journal", "us", "US", _gn("site:wsj.com when:2d"), "via Google News (WSJ's own feeds stopped updating)"),
    ("zerohedge", "ZeroHedge", "us", "US", "https://feeds.feedburner.com/zerohedge/feed", ""),
    # --- international (independent / commercial)
    ("guardian", "The Guardian", "intl", "UK", "https://www.theguardian.com/us-news/rss", "UK, owned by the Scott Trust"),
    ("euronews", "Euronews", "intl", "EU", "https://www.euronews.com/rss", ""),
    ("scmp", "South China Morning Post", "intl", "HK", "https://www.scmp.com/rss/91/feed", "Hong Kong, owned by Alibaba"),
    ("hkfp", "Hong Kong Free Press", "intl", "HK", "https://hongkongfp.com/feed/", "Independent, Hong Kong"),
    ("japantimes", "Japan Times", "intl", "JP", "https://www.japantimes.co.jp/feed/", ""),
    ("moscowtimes", "Moscow Times", "intl", "RU", "https://www.themoscowtimes.com/rss/news", "Independent Russian outlet in exile (Amsterdam)"),
    ("meduza", "Meduza", "intl", "RU", "https://meduza.io/rss/en/all", "Independent Russian outlet in exile (Riga)"),
    # --- publicly funded international broadcasters (state-funded, with editorial-independence charters)
    ("rferl", "RFE/RL", "public", "US", "https://www.rferl.org/api/epiqq", "Funded by the US government (US Agency for Global Media)"),
    ("bbc", "BBC", "public", "UK", "https://feeds.bbci.co.uk/news/world/us_and_canada/rss.xml", "UK public broadcaster (licence fee)"),
    ("dw", "Deutsche Welle", "public", "DE", "https://rss.dw.com/rdf/rss-en-all", "Funded by the German federal government"),
    ("france24", "France 24", "public", "FR", "https://www.france24.com/en/rss", "French state-owned (France Medias Monde)"),
    ("aljazeera", "Al Jazeera", "public", "QA", "https://www.aljazeera.com/xml/rss/all.xml", "Funded by the government of Qatar"),
    # --- state-controlled media / official channels
    ("rt", "RT", "state", "RU", "https://www.rt.com/rss/", "Russian state-funded broadcaster (ANO TV-Novosti); sanctioned by the US Treasury in 2024"),
    ("tass", "TASS", "state", "RU", "https://tass.com/rss/v2.xml", "Russian state news agency"),
    ("sputnik", "Sputnik", "state", "RU", _gn("site:sputnikglobe.com when:2d"), "Russian state media (Rossiya Segodnya); via Google News"),
    ("kremlin", "Kremlin", "state", "RU", "http://en.kremlin.ru/events/president/news/feed", "Official website of the President of Russia"),
    ("cgtn", "CGTN", "state", "CN", "https://www.cgtn.com/subscribe/rss/section/world.xml", "China Global Television Network, part of state broadcaster China Media Group"),
    ("cgtnchina", "CGTN", "state", "CN", "https://www.cgtn.com/subscribe/rss/section/china.xml", "CGTN China section"),
    ("xinhua", "Xinhua", "state", "CN", _gn("site:english.news.cn when:2d"), "China's official state news agency; via Google News"),
    ("globaltimes", "Global Times", "state", "CN", _gn("site:globaltimes.cn when:2d"), "Published by People's Daily, the Communist Party's newspaper; via Google News"),
    ("peoplesdaily", "People's Daily", "state", "CN", _gn("site:en.people.cn when:3d"), "Official newspaper of the Chinese Communist Party Central Committee; via Google News"),
    ("chinadaily", "China Daily", "state", "CN", _gn("site:chinadaily.com.cn when:2d"), "Owned by the Communist Party's Publicity Department; via Google News"),
    ("presstv", "Press TV", "state", "IR", "https://www.presstv.ir/rss.xml", "English service of Iran's state broadcaster IRIB"),
    ("tehrantimes", "Tehran Times", "state", "IR", "https://www.tehrantimes.com/rss", "Iranian daily owned by the state Islamic Propagation Organization"),
    ("telesur", "teleSUR", "state", "VE", "https://www.telesurenglish.net/feed/", "Funded mainly by the Venezuelan government"),
    # --- disinformation researchers
    ("euvsdisinfo", "EUvsDisinfo", "research", "EU", "https://euvsdisinfo.eu/feed/", "EU External Action Service East StratCom Task Force"),
    ("dfrlab", "DFRLab", "research", "US", "https://dfrlab.org/feed/", "Atlantic Council's Digital Forensic Research Lab"),
]
SOURCES = [dict(key=k, name=n, grp=g, cc=c, url=u, note=note, gn="news.google.com" in u) for k, n, g, c, u, note in _SRC]
SRC = {s["key"]: s for s in SOURCES}
# outlet names that identify state media inside Google News results ("... - RT")
STATE_NAMES = {s["name"].lower(): s["cc"] for s in SOURCES if s["grp"] == "state"}
STATE_NAMES.update({"rt.com": "RU", "sputnik international": "RU", "sputnik globe": "RU", "tass.com": "RU",
                    "cgtn.com": "CN", "china daily": "CN", "chinadaily.com.cn": "CN", "globaltimes.cn": "CN",
                    "xinhuanet": "CN", "news.cn": "CN", "presstv": "IR", "irna": "IR", "mehr news agency": "IR",
                    "tasnim news agency": "IR", "telesur english": "VE", "people's daily online": "CN"})

# ------------------------------------------------------------------ storage
_LOCK = threading.RLock()
_CON = None
COLS = ("id", "src", "grp", "cc", "title", "summary", "url", "ts")


def _con():
    global _CON
    if _CON is None:
        c = sqlite3.connect(str(WDIR / "archive.db"), timeout=30, check_same_thread=False)
        c.execute("PRAGMA journal_mode=WAL")
        c.execute("CREATE TABLE IF NOT EXISTS items(id TEXT PRIMARY KEY, src TEXT, grp TEXT, cc TEXT, title TEXT,"
                  " summary TEXT, url TEXT, ts REAL, fetched REAL)")
        c.execute("CREATE INDEX IF NOT EXISTS ix_ts ON items(ts)")
        c.commit()
        _CON = c
    return _CON


def _q(sql, args=()):
    with _LOCK:
        return _con().execute(sql, args).fetchall()


_TAG = re.compile(r"<[^>]+>")
# feed boilerplate that would otherwise dominate term statistics ("Read Full Article at RT.com")
_BOILER = re.compile(r"Read Full Article at RT\.com|The post .{0,200}? appeared first on .{0,80}?(?:\.|$)|"
                     r"Continue reading\.*|Read more\.*$|\[(?:…|\.\.\.)\]|\(Full Story\)", re.I)


def _clean(s, n=None):
    s = html.unescape(_TAG.sub(" ", s or ""))
    s = re.sub(r"\s+", " ", _BOILER.sub(" ", s)).strip()
    return s[:n] if n else s


STATUS = {}
UNDATED = {"presstv"}  # feeds without publish times: excluded from "who said it first" logic
_RUN = {"started": False, "last": 0.0, "busy": False}
_FIRST = threading.Event()
_WAKE = threading.Event()
_START = threading.Lock()


def _get_capped(url, limit=25, max_bytes=6_000_000):
    """GET with a hard wall-clock limit (requests' timeout only bounds each read, so a slow-trickling server
    could otherwise stall a feed for minutes)."""
    t0 = time.time()
    with S.get(url, timeout=(10, 15), stream=True) as r:
        r.raise_for_status()
        buf = bytearray()
        for chunk in r.iter_content(65536):
            buf += chunk
            if time.time() - t0 > limit:
                raise TimeoutError(f"feed took longer than {limit}s")
            if len(buf) > max_bytes:
                break
        return bytes(buf)


def _fetch(s):
    t0 = time.time()
    try:
        fp = feedparser.parse(_get_capped(s["url"]))
        now = time.time()
        rows = []
        for e in fp.entries[:200]:
            title = _clean(e.get("title"))
            if not title:
                continue
            if s["gn"]:
                title = re.sub(r"\s+-\s+[^-]{2,40}$", "", title)  # "Headline - AP News"
            url = (e.get("link") or "").strip()
            tsp = e.get("published_parsed") or e.get("updated_parsed")
            if tsp:
                ts = float(calendar.timegm(tsp))
            else:  # undated feed (Press TV): use the date in the URL, never treat the item as "first"
                UNDATED.add(s["key"])
                m = re.search(r"/(20\d\d)/(\d\d)/(\d\d)/", url)
                ts = now
                if m:
                    day = calendar.timegm((int(m[1]), int(m[2]), int(m[3]), 0, 0, 0))
                    ts = min(now, day + 86399.0)
            if ts > now + 3600:
                ts = now
            if ts < now - 30 * 86400:
                continue
            summ = "" if s["gn"] else _clean(e.get("summary") or e.get("description"), 600)
            if summ.lower() == title.lower():
                summ = ""
            iid = hashlib.sha1((url or (s["key"] + title)).encode("utf-8", "ignore")).hexdigest()[:20]
            rows.append((iid, s["key"], s["grp"], s["cc"], title, summ, url, ts, now))
        with _LOCK:
            c = _con()
            before = c.total_changes
            c.executemany("INSERT OR IGNORE INTO items VALUES (?,?,?,?,?,?,?,?,?)", rows)
            c.commit()
            new = c.total_changes - before
        STATUS[s["key"]] = {"ok": True, "n": len(rows), "new": new, "at": now, "ms": int((time.time() - t0) * 1000)}
    except Exception as e:  # noqa: BLE001
        STATUS[s["key"]] = {"ok": False, "err": f"{type(e).__name__}: {str(e)[:140]}", "at": time.time()}


def collect():
    _RUN["busy"] = True
    try:
        with ThreadPoolExecutor(12) as ex:
            list(ex.map(_fetch, SOURCES))
        with _LOCK:
            _con().execute("DELETE FROM items WHERE ts < ?", (time.time() - KEEP_DAYS * 86400,))
            _con().commit()
        _RUN["last"] = time.time()
        _MEMO.clear()
    finally:
        _RUN["busy"] = False
        _FIRST.set()


def _loop():
    while True:
        try:
            collect()
        except Exception:  # noqa: BLE001
            pass
        _WAKE.wait(REFRESH)
        _WAKE.clear()


def ensure():
    """Start the background collector; on a brand-new archive wait for the first pass."""
    with _START:
        if not _RUN["started"]:
            _RUN["started"] = True
            threading.Thread(target=_loop, daemon=True).start()
    if not _FIRST.is_set():
        n = _q("SELECT COUNT(*) FROM items WHERE ts > ?", (time.time() - 86400,))[0][0]
        if n < 300:
            _FIRST.wait(90)


def refresh():
    ensure()
    _WAKE.set()
    return {"ok": True}


_MEMO = {}
_MEMO_LOCKS = {}
_MEMO_GUARD = threading.Lock()


def _memo(key, ttl, fn):
    """Small TTL cache; one lock per key so nested cached calls (stories -> docs) don't deadlock."""
    hit = _MEMO.get(key)
    if hit and time.time() - hit[0] < ttl:
        return hit[1]
    with _MEMO_GUARD:
        lock = _MEMO_LOCKS.setdefault(key, threading.Lock())
    with lock:
        hit = _MEMO.get(key)
        if hit and time.time() - hit[0] < ttl:
            return hit[1]
        v = fn()
        _MEMO[key] = (time.time(), v)
        return v


def docs(hours):
    def load():
        rows = _q("SELECT id,src,grp,cc,title,summary,url,ts FROM items WHERE ts >= ? ORDER BY ts",
                  (time.time() - hours * 3600,))
        out = []
        for r in rows:
            if r[1] in SRC:
                d = dict(zip(COLS, r))
                d["summary"] = re.sub(r"\s+", " ", _BOILER.sub(" ", d["summary"] or "")).strip()
                out.append(d)
        return out
    return _memo(("docs", hours), 90, load)


def _out(d, summ=True):
    s = SRC[d["src"]]
    o = {"src": d["src"], "name": s["name"], "grp": d["grp"], "cc": d["cc"], "title": d["title"], "url": d["url"], "ts": d["ts"]}
    if summ:
        o["summary"] = (d["summary"] or "")[:280]
    return o


def _archive():
    n, lo = _q("SELECT COUNT(*), MIN(ts) FROM items")[0]
    return {"items": n, "since": lo, "last": _RUN["last"], "busy": _RUN["busy"],
            "feeds_ok": sum(1 for v in STATUS.values() if v.get("ok")), "feeds": len(SOURCES)}


# ------------------------------------------------------------------ text helpers
STOP = set("""a about above after again against all also am an and any are as at be because been before being below
between both but by can could did do does doing down during each few for from further had has have having he her here
hers herself him himself his how i if in into is it its itself just me more most my no nor not now of off on once only
or other our ours out over own same she should so some such than that the their theirs them then there these they this
those through to too under until up very was we were what when where which while who whom why will with would you your
yours new says said say saying told tells according report reports reported amid year years day days week weeks month
months monday tuesday wednesday thursday friday saturday sunday today yesterday tomorrow time first last one two three
four five six seven eight nine ten us via may might must get gets got make makes made take takes took back like still
even many much well way another per since around it's don't won't can't isn't news latest live update updates video
watch photos read full story also could would should people know need want see show shows set use used going
matters opinion editorial column podcast newsletter here's what's
jan feb mar apr jun jul aug sep sept oct nov dec related
""".split())
_W = re.compile(r"[a-z][a-z'\-]{2,}")


def _content(text):
    out = []
    for w in _W.findall((text or "").lower()):
        w = w.strip("'-")
        if w.endswith("'s"):
            w = w[:-2]
        if len(w) > 2 and w not in STOP:
            out.append(w)
    return out


def _bucket_series(items, hours, key=lambda d: d["grp"]):
    """Counts per time bucket per key (1h buckets up to 48h, 6h beyond)."""
    step = 3600 if hours <= 48 else 6 * 3600 if hours <= 24 * 10 else 86400
    now = time.time()
    start = (now - hours * 3600) // step * step
    nb = int((now - start) // step) + 1
    labels = [start + i * step for i in range(nb)]
    ser = defaultdict(lambda: [0] * nb)
    for d in items:
        b = int((d["ts"] - start) // step)
        if 0 <= b < nb:
            ser[key(d)][b] += 1
    return {"labels": labels, "step": step, "series": dict(ser)}


def _grp_key(d):
    return "state:" + d["cc"] if d["grp"] == "state" else d["grp"]


# ------------------------------------------------------------------ WIRE
def wire(q):
    ensure()
    hours = float(q.get("hours", 24))
    grp = q.get("grp", "all")
    text = (q.get("q") or "").strip().lower()
    ds = docs(hours)

    def keep(d):
        if grp == "all":
            ok = True
        elif grp.startswith("state:"):
            ok = d["grp"] == "state" and d["cc"] == grp[6:]
        else:
            ok = d["grp"] == grp
        if ok and text:
            ok = all(t in (d["title"] + " " + d["summary"]).lower() for t in text.split())
        return ok

    sel = sorted((d for d in ds if keep(d)), key=lambda d: d["ts"], reverse=True)
    day = [d for d in docs(24)]
    counts = Counter(_grp_key(d) for d in day)
    return {"items": [_out(d) for d in sel[:500]], "total": len(sel), "counts24": counts,
            "chart": _bucket_series(sel, hours, _grp_key), "archive": _archive()}


# ------------------------------------------------------------------ STORIES (clusters)
def _vectors(ds):
    tfs, df = [], Counter()
    for d in ds:
        tf = Counter()
        for w in _content(d["title"]):
            tf[w] += 2
        for w in _content(d["summary"][:300]):
            tf[w] += 1
        tfs.append(tf)
        df.update(tf.keys())
    n = max(len(ds), 1)
    hi = max(4, n * 0.12)
    vecs = []
    for tf in tfs:
        v = {t: (1 + math.log(c)) * math.log(n / df[t]) for t, c in tf.items() if 2 <= df[t] <= hi}
        nm = math.sqrt(sum(x * x for x in v.values())) or 1.0
        vecs.append({t: x / nm for t, x in v.items()})
    return vecs


def _cluster(vecs, thr=0.33):
    cl, index = [], defaultdict(set)
    for i, v in enumerate(vecs):
        if len(v) < 2:
            continue
        top = sorted(v, key=v.get, reverse=True)[:8]
        cands = set()
        for t in top:
            cands |= index[t]
        best, bs = None, thr
        for ci in cands:
            c = cl[ci]
            s = sum(x * c["c"].get(t, 0.0) for t, x in v.items()) / c["norm"]
            if s > bs:
                best, bs = ci, s
        if best is None:
            cl.append({"c": dict(v), "ids": [i], "norm": 1.0})
            best = len(cl) - 1
        else:
            c = cl[best]
            for t, x in v.items():
                c["c"][t] = c["c"].get(t, 0.0) + x
            c["ids"].append(i)
            if len(c["c"]) > 90:
                c["c"] = dict(sorted(c["c"].items(), key=lambda kv: kv[1], reverse=True)[:60])
            c["norm"] = math.sqrt(sum(x * x for x in c["c"].values())) or 1.0
        c = cl[best]
        for t in sorted(c["c"], key=c["c"].get, reverse=True)[:10]:
            index[t].add(best)
    return cl


def stories(q):
    ensure()
    hours = float(q.get("hours", 48))
    return _memo(("stories", hours, _RUN["last"]), 900, lambda: _stories(hours))


def _stories(hours):
    ds = [d for d in docs(hours) if d["grp"] != "research"]
    vecs = _vectors(ds)
    out = []
    for c in _cluster(vecs):
        ids = c["ids"]
        names = {SRC[ds[i]["src"]]["name"] for i in ids}
        if len(ids) < 2 or len(names) < 2:
            continue
        items = sorted((ds[i] for i in ids), key=lambda d: d["ts"])
        outlets_by = defaultdict(set)
        for d in items:
            outlets_by[_grp_key(d)].add(SRC[d["src"]]["name"])
        g = Counter(d["grp"] for d in items)
        best = max(ids, key=lambda i: sum(x * c["c"].get(t, 0.0) for t, x in vecs[i].items()))
        first = next((d for d in items if d["src"] not in UNDATED), items[0])
        n_state = g.get("state", 0)
        n_usmedia = g.get("us", 0) + g.get("usgov", 0)
        state_outlets = {n for k, v in outlets_by.items() if k.startswith("state:") for n in v}
        flags = []
        if first["grp"] == "state" and len(names) >= 3:
            flags.append("state-first")
        if n_state / len(items) >= 0.5 and len(names) >= 3 and n_usmedia:
            flags.append("state-heavy")
        if len(state_outlets) >= 2 and n_usmedia == 0:
            flags.append("state-only")
        if n_state == 0 and len(names) >= 8:
            flags.append("no-state")
        out.append({
            "label": ds[best]["title"], "url": ds[best]["url"], "terms": sorted(c["c"], key=c["c"].get, reverse=True)[:6],
            "n": len(items), "outlets": len(names), "first": _out(first, False), "last_ts": items[-1]["ts"],
            "by": {k: len(v) for k, v in outlets_by.items()}, "flags": flags,
            "state_cc": sorted({d["cc"] for d in items if d["grp"] == "state"}),
            "items": [_out(d, False) for d in items[-80:]],
        })
    out.sort(key=lambda s: (s["outlets"], s["n"]), reverse=True)
    return {"stories": out[:150], "docs": len(ds), "hours": hours, "archive": _archive()}


# ------------------------------------------------------------------ FRAMING terms
# Wording that researchers and fact-checkers (EUvsDisinfo, DFRLab, ASD/GMF, academic studies) associate with
# each government's messaging. Mainstream outlets often QUOTE these terms - the tracker shows who uses them, and the
# examples let you judge whether it is adoption or reporting.
FRAMES = [
    ("Kiev regime", "RU"), ("Kyiv regime", "RU"), ("special military operation", "RU"), ("collective West", "RU"),
    ("Russophobia", "RU"), ("Russophobic", "RU"), ("neo-Nazi", "RU"), ("denazification", "RU"),
    ("Anglo-Saxons", "RU"), ("NATO expansion", "RU"), ("proxy war", "RU"), ("biolabs", "RU"),
    ("Maidan coup", "RU"), ("color revolution", "RU"), ("multipolar world", "RU"), ("deep state", "RU"),
    ("Cold War mentality", "CN"), ("hegemony", "CN"), ("hegemonic", "CN"), ("anti-China forces", "CN"),
    ("internal affairs", "CN"), ("Taiwan question", "CN"), ("separatist forces", "CN"), ("Taiwan independence", "CN"),
    ("smear campaign", "CN"), ("China threat", "CN"), ("win-win", "CN"), ("long-arm jurisdiction", "CN"),
    ("small yard, high fence", "CN"), ("bloc confrontation", "CN"), ("peaceful reunification", "CN"),
    ("community with a shared future", "CN"), ("Global Development Initiative", "CN"),
    ("Zionist regime", "IR"), ("Zionist entity", "IR"), ("Axis of Resistance", "IR"), ("global arrogance", "IR"),
    ("Great Satan", "IR"), ("resistance front", "IR"),
    ("imperialist aggression", "VE"), ("economic war", "VE"), ("Yankee imperialism", "VE"),
]


def _rx(term):
    parts = [re.escape(p) for p in re.split(r"[\s\-]+", term.strip()) if p]
    return re.compile(r"(?<![a-z])" + r"[\s\-]+".join(parts) + r"(?![a-z])", re.I)


def framing(q):
    ensure()
    days = int(q.get("days", 30))
    extra = tuple(t.strip() for t in (q.get("extra") or "").split("|") if t.strip())[:30]
    return _memo(("framing", days, extra, _RUN["last"]), 900, lambda: _framing(days, extra))


def _framing(days, extra):
    ds = [d for d in docs(days * 24) if d["grp"] != "research"]
    low = [(d["title"] + " " + d["summary"]).lower() for d in ds]
    now = time.time()
    terms = list(FRAMES) + [(t, "custom") for t in extra]
    out = []
    for term, origin in terms:
        rx = _rx(term)
        key = re.split(r"[\s\-]+", term.lower())[0]
        hits = [d for d, t in zip(ds, low) if key in t and rx.search(t)]
        state = [d for d in hits if d["grp"] == "state"]
        other = [d for d in hits if d["grp"] in ("us", "intl", "public")]
        gov = [d for d in hits if d["grp"] == "usgov"]
        daily = [0] * days
        for d in other:
            b = int((now - d["ts"]) // 86400)
            if 0 <= b < days:
                daily[days - 1 - b] += 1
        out.append({
            "term": term, "origin": origin,
            "state": len(state), "state_by": Counter(d["cc"] for d in state),
            "state_outlets": Counter(SRC[d["src"]]["name"] for d in state).most_common(6),
            "other": len(other), "gov": len(gov),
            "outlets": Counter(SRC[d["src"]]["name"] for d in other).most_common(12),
            "daily": daily,
            "examples": [_out(d, False) for d in sorted(other, key=lambda d: -d["ts"])[:10]],
            "state_examples": [_out(d, False) for d in sorted(state, key=lambda d: -d["ts"])[:5]],
        })
    return {"terms": out, "days": days, "docs": len(ds), "archive": _archive()}


# ------------------------------------------------------------------ ECHOES (phrase transfer)
_WT = re.compile(r"[a-z0-9][a-z0-9'\-]*")
_SEG = re.compile(r"[.!?;:\"“”()\[\]|—]+")
N_SH = 4


def _shingles(text):
    out, toks = {}, []
    for seg in _SEG.split((text or "").lower()):
        w = _WT.findall(seg)
        base = len(toks)
        for i in range(len(w) - N_SH + 1):
            g = w[i:i + N_SH]
            if sum(1 for x in g if x not in STOP and not x[0].isdigit()) >= 3:
                out.setdefault(" ".join(g), base + i)
        toks.extend(w)
    return out, toks


def echoes(q):
    ensure()
    days = int(q.get("days", 14))
    return _memo(("echoes", days, _RUN["last"]), 1200, lambda: _echoes(days))


def _echoes(days):
    # timing is the whole point here, so items without real publish times are left out
    ds = [d for d in docs(days * 24) if d["grp"] != "research" and d["src"] not in UNDATED]
    n = max(len(ds), 1)
    df = Counter()
    for d in ds:
        df.update(set(_content(d["title"] + " " + d["summary"])))
    sh = [None] * len(ds)
    origin = {}  # shingle -> earliest state doc index
    for i, d in enumerate(ds):  # ds is time-ordered
        if d["grp"] == "state":
            sh[i] = _shingles(d["title"] + " . " + d["summary"])
            for g in sh[i][0]:
                origin.setdefault(g, i)
    uses = defaultdict(list)       # shingle -> non-state doc indexes
    state_uses = defaultdict(set)  # shingle -> state outlet names
    gov_hit = set()
    for i, d in enumerate(ds):
        if d["grp"] == "state":
            for g in sh[i][0]:
                state_uses[g].add(SRC[d["src"]]["name"])
            continue
        gs, _ = _shingles(d["title"] + " . " + d["summary"])
        for g in gs:
            if g in origin:
                if d["grp"] == "usgov":
                    gov_hit.add(g)
                else:
                    uses[g].append(i)
    caps = {}

    def name_words(i):  # capitalised words in the origin item = names/places/titles
        if i not in caps:
            caps[i] = {w.lower() for w in re.findall(r"\b[A-Z][A-Za-z'\-]+", ds[i]["title"] + " " + ds[i]["summary"])}
        return caps[i]

    groups = defaultdict(list)
    for g, later in uses.items():
        if g in gov_hit:
            continue  # official statements quoted by everyone
        o = origin[g]
        plain = [x for x in g.split() if x not in STOP and not x[0].isdigit() and x not in name_words(o)]
        if len(plain) < 2:
            continue  # mostly a name ("russian president vladimir putin") - shared names are not narrative
        if any(ds[j]["ts"] < ds[o]["ts"] for j in later):
            continue  # someone else used it before state media did
        later = [j for j in later if ds[j]["ts"] >= ds[o]["ts"]]
        outlets = {SRC[ds[j]["src"]]["name"] for j in later}
        if not outlets or len(outlets) + len(state_uses[g]) > 16:
            continue
        cw = [w for w in g.split() if w not in STOP and not w[0].isdigit()]
        spec = sum(math.log(n / max(df.get(w.strip("'-"), 1), 1)) for w in cw) / max(len(cw), 1)
        if spec < 3.2:
            continue
        groups[(o, tuple(sorted(later)))].append((sh[o][0][g], spec))
    out = []
    for (o, later), shs in groups.items():
        toks = sh[o][1]
        pos = sorted(p for p, _ in shs)
        spans, a, b = [], pos[0], pos[0]
        for p in pos[1:]:
            if p <= b + 1:
                b = p
            else:
                spans.append((a, b))
                a = b = p
        spans.append((a, b))
        a, b = max(spans, key=lambda ab: ab[1] - ab[0])
        phrase = " ".join(toks[a:b + N_SH])
        spec = max(s for _, s in shs)
        lat = sorted((ds[j] for j in later), key=lambda d: d["ts"])
        outlets = sorted({SRC[d["src"]]["name"] for d in lat})
        out.append({
            "phrase": phrase, "spec": round(spec, 2), "origin": _out(ds[o], False),
            "state_outlets": sorted(state_uses.get(" ".join(toks[a:a + N_SH]), {SRC[ds[o]["src"]]["name"]})),
            "later": [dict(_out(d, False), lag_h=round((d["ts"] - ds[o]["ts"]) / 3600, 1)) for d in lat[:12]],
            "outlets": outlets, "score": round(len(outlets) * spec + (b - a) * 0.5, 2),
        })
    # one row per phrase (keep the strongest pairing)
    best = {}
    for e in out:
        k = e["phrase"]
        if k not in best or e["score"] > best[k]["score"]:
            best[k] = e
    rows = sorted(best.values(), key=lambda e: e["score"], reverse=True)[:120]
    return {"echoes": rows, "days": days, "docs": len(ds), "archive": _archive()}


# ------------------------------------------------------------------ STATE-MEDIA PROFILE
_ENT = re.compile(r"\b([A-Z][a-z]+(?:[-'][A-Z]?[a-z]+)?(?:\s+(?:[A-Z][a-z]+(?:[-'][A-Z]?[a-z]+)?|[A-Z]\.)){1,2})\b")
_ENT_STOP = set("""The A An In On At For From With As By And But Or If After Before Why How What When Where Who This That
These Those Our Your His Her Their Its New More Most Breaking Watch Live Video Photos Opinion Analysis Exclusive Report Here
Is Are Was Were Will Can Could Should Would Over Under Not No All Some Every Former Top Monday Tuesday Wednesday Thursday
Friday Saturday Sunday January February March April May June July August September October November December Mr Mrs Ms
Dr President Prime Minister Secretary Senator Rep Gov General Chief Spokesperson Spokesman Foreign Ministry Leader
Chairman Vice Deputy Ambassador According Despite Amid During While Meanwhile Also Following Just Only Read More""".split())


_TITLES = set("""President Premier Prime Minister Chancellor Secretary Senator Governor King Queen Prince Ambassador
Spokesperson Spokesman Spokeswoman Chairman Chairwoman Leader Speaker General Director Chief Mayor CEO""".split())
_ENT = re.compile(r"\b([A-Z][a-z]+(?:[-'][A-Z]?[a-z]+)?(?:\s+(?:[A-Z][a-z]+(?:[-'][A-Z]?[a-z]+)?|[A-Z]\.|CEO)){1,3})\b")


def _entities(text):
    out = set()
    for m in _ENT.finditer(text or ""):
        seg, segs = [], []
        for x in m.group(1).split():  # "Gabonese President Brice Oligui" -> "Brice Oligui"
            if x in _TITLES:
                segs.append(seg)
                seg = []
            else:
                seg.append(x)
        segs.append(seg)
        for w in segs:
            while w and w[0] in _ENT_STOP:
                w = w[1:]
            while w and w[-1] in _ENT_STOP:
                w = w[:-1]
            if len(w) >= 2:
                out.add(" ".join(w))
    return out


def _grams(text):
    w = _content(text)
    return set(w) | {a + " " + b for a, b in zip(w, w[1:])}


def profile(q):
    ensure()
    days = int(q.get("days", 7))
    return _memo(("profile", days, _RUN["last"]), 1200, lambda: _profile(days))


def _logodds(ci, ni, cj, nj, allc, nall, a0=800.0, minc=3, k=30):
    res = []
    for w, yi in ci.items():
        if yi < minc:
            continue
        aw = a0 * allc[w] / nall
        yj = cj.get(w, 0)
        dlt = math.log((yi + aw) / (ni + a0 - yi - aw)) - math.log((yj + aw) / (nj + a0 - yj - aw))
        z = dlt / math.sqrt(1 / (yi + aw) + 1 / (yj + aw))
        res.append((z, w, yi, yj))
    res.sort(reverse=True)
    # drop single words that only repeat half of a pair already in the list ("abu" when "abu dhabi" is shown)
    covered = {p for _, w, _, _ in res[:k] if " " in w for p in w.split()}
    return [r for r in res if " " in r[1] or r[1] not in covered][:k]


def _profile(days):
    ds = docs(days * 24)
    corp, nd, ents = defaultdict(Counter), Counter(), defaultdict(Counter)
    for d in ds:
        k = _grp_key(d)
        if not (k == "us" or k.startswith("state:")):
            continue
        txt = d["title"] + " " + d["summary"][:300]
        corp[k].update(_grams(txt))
        ents[k].update(_entities(d["title"] + ". " + d["summary"][:300]))
        nd[k] += 1
    allc = Counter()
    for c in corp.values():
        allc.update(c)
    nall = sum(allc.values()) or 1
    us, nus = corp["us"], sum(corp["us"].values()) or 1
    res = {}
    for cc in STATE_CC:
        k = "state:" + cc
        if nd[k] < 10:
            res[cc] = {"docs": nd[k], "terms": [], "avoid": [], "entities": []}
            continue
        ci, ni = corp[k], sum(corp[k].values()) or 1
        terms = [{"term": w, "z": round(z, 1), "per100": round(100 * yi / nd[k], 1), "us_per100": round(100 * yj / max(nd["us"], 1), 2)}
                 for z, w, yi, yj in _logodds(ci, ni, us, nus, allc, nall)]
        avoid = [{"term": w, "z": round(z, 1), "us_per100": round(100 * yi / max(nd["us"], 1), 1), "per100": round(100 * yj / nd[k], 2)}
                 for z, w, yi, yj in _logodds(us, nus, ci, ni, allc, nall, minc=8, k=20)]
        e_us = ents["us"]
        ent = []
        for e, c in ents[k].most_common(60):
            if c < 3:
                break
            lift = (c / nd[k]) / ((e_us.get(e, 0) + 0.5) / max(nd["us"], 1))
            ent.append({"name": e, "docs": c, "per100": round(100 * c / nd[k], 1),
                        "us_per100": round(100 * e_us.get(e, 0) / max(nd["us"], 1), 2), "lift": round(lift, 1)})
        res[cc] = {"docs": nd[k], "terms": terms, "avoid": avoid, "entities": ent[:40]}
    return {"countries": res, "us_docs": nd["us"], "days": days, "archive": _archive()}


# ------------------------------------------------------------------ PEOPLE / ORGS
def _name_rx(aliases):
    return re.compile("|".join(_rx(a).pattern for a in aliases), re.I)


def person(q):
    ensure()
    raw = (q.get("name") or "").strip()
    aliases = [a.strip() for a in re.split(r"[|,]", raw) if a.strip()][:5]
    if not aliases:
        raise ValueError("enter a name")
    return _memo(("person", tuple(a.lower() for a in aliases), _RUN["last"]), 600, lambda: _person(aliases))


def _gnews_search(aliases, days=7):
    qs = " OR ".join(f'"{a}"' for a in aliases) + f" when:{days}d"
    r = S.get(_gn(qs), timeout=20)
    r.raise_for_status()
    fp = feedparser.parse(r.content)
    out = []
    for e in fp.entries[:100]:
        t = _clean(e.get("title"))
        src = _clean((e.get("source") or {}).get("title", "")) or (t.rsplit(" - ", 1)[1] if " - " in t else "")
        t = re.sub(r"\s+-\s+[^-]{2,60}$", "", t)
        tsp = e.get("published_parsed")
        out.append({"title": t, "outlet": src, "url": e.get("link"), "ts": calendar.timegm(tsp) if tsp else None,
                    "state_cc": STATE_NAMES.get(src.lower())})
    return out


def _person(aliases):
    rx = _name_rx(aliases)
    ds = [d for d in docs(30 * 24) if d["grp"] != "research"]
    hits = [d for d in ds if rx.search(d["title"]) or rx.search(d["summary"])]
    base_state = sum(1 for d in ds if d["grp"] == "state") / max(len(ds), 1)
    hs = sum(1 for d in hits if d["grp"] == "state")
    share = hs / len(hits) if hits else None
    try:
        gn = _gnews_search(aliases)
        gn_err = None
    except Exception as e:  # noqa: BLE001
        gn, gn_err = [], str(e)
    return {
        "name": aliases[0], "aliases": aliases, "mentions": len(hits),
        "by": Counter(_grp_key(d) for d in hits),
        "outlets": Counter(SRC[d["src"]]["name"] for d in hits).most_common(25),
        "state_share": share, "base_state_share": base_state,
        "amplification": (share / base_state) if (share is not None and base_state) else None,
        "chart": _bucket_series(hits, 30 * 24, _grp_key),
        "state_items": [_out(d) for d in sorted((d for d in hits if d["grp"] == "state"), key=lambda d: -d["ts"])[:50]],
        "other_items": [_out(d) for d in sorted((d for d in hits if d["grp"] != "state"), key=lambda d: -d["ts"])[:60]],
        "gnews": gn, "gnews_outlets": Counter(x["outlet"] for x in gn if x["outlet"]).most_common(25), "gnews_error": gn_err,
        "archive": _archive(),
    }


# ------------------------------------------------------------------ settings (FEC key stays on this PC)
_SET = WDIR / "settings.json"


def get_settings():
    try:
        return json.loads(_SET.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return {}


def settings(q):
    st = get_settings()
    changed = False
    if "fec_key" in q:
        st["fec_key"] = q["fec_key"].strip()
        changed = True
    if "sec_contact" in q:   # the SEC asks automated tools to include a contact email; used only in requests to sec.gov
        c = q["sec_contact"].strip()[:120]
        if c and not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", c):
            return {"error": "That doesn't look like an email address"}
        st["sec_contact"] = c
        changed = True
    if changed:
        _SET.write_text(json.dumps(st), encoding="utf-8")
    k = st.get("fec_key", "")
    return {"fec_key_set": bool(k), "fec_key_hint": (k[:4] + "..." + k[-3:]) if len(k) > 8 else "",
            "sec_contact": st.get("sec_contact", "")}


# ------------------------------------------------------------------ FEC contributions
_FEC_CACHE = WDIR / "fec_cache.json"
_FEC_LOCK = threading.Lock()


def fec(q):
    name = (q.get("name") or "").split("|")[0].split(",")[0].strip()
    if not name:
        raise ValueError("enter a name")
    key = name.lower()
    with _FEC_LOCK:
        try:
            cache = json.loads(_FEC_CACHE.read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001
            cache = {}
        hit = cache.get(key)
        if hit and time.time() - hit["at"] < 86400 and not q.get("force"):
            return dict(hit["data"], cached=True)
    api_key = get_settings().get("fec_key") or "DEMO_KEY"
    r = S.get("https://api.open.fec.gov/v1/schedules/schedule_a/", timeout=60, params={
        "api_key": api_key, "contributor_name": name, "is_individual": "true",
        "sort": "-contribution_receipt_amount", "per_page": 100})
    if r.status_code == 429 or (r.status_code == 403 and "rate" in r.text.lower()):
        raise RuntimeError("FEC rate limit reached. The shared DEMO_KEY allows only a few lookups per hour - "
                           "add your own free api.data.gov key in ABOUT > Settings.")
    r.raise_for_status()
    j = r.json()
    last = name.split()[-1].upper()
    rows = []
    for x in j.get("results", []):
        nm = (x.get("contributor_name") or "").upper()
        if last not in nm:
            continue
        cm = x.get("committee") or {}
        rows.append({
            "name": x.get("contributor_name"), "amount": x.get("contribution_receipt_amount"),
            "date": x.get("contribution_receipt_date"), "committee": cm.get("name") or x.get("committee_id"),
            "committee_type": cm.get("committee_type_full"), "party": cm.get("party_full"),
            "employer": x.get("contributor_employer"), "occupation": x.get("contributor_occupation"),
            "place": ", ".join(p for p in (x.get("contributor_city"), x.get("contributor_state")) if p),
            "cycle": x.get("two_year_transaction_period"), "memo": x.get("memo_code") == "X",
            "memo_text": x.get("memo_text"),
        })
    real = [x for x in rows if not x["memo"] and isinstance(x["amount"], (int, float))]
    by_c = defaultdict(float)
    by_cycle = defaultdict(float)
    for x in real:
        by_c[(x["committee"], x["committee_type"] or "", x["party"] or "")] += x["amount"]
        by_cycle[x["cycle"]] += x["amount"]
    data = {
        "name": name, "rows": rows, "total_listed": sum(x["amount"] for x in real),
        "itemized_count": (j.get("pagination") or {}).get("count"),
        "by_committee": [{"committee": c, "type": t, "party": p, "amount": a}
                         for (c, t, p), a in sorted(by_c.items(), key=lambda kv: -kv[1])],
        "by_cycle": sorted(([k, v] for k, v in by_cycle.items() if k), key=lambda kv: kv[0]),
        "names_matched": Counter(x["name"] for x in rows).most_common(8),
        "link": f"https://www.fec.gov/data/receipts/individual-contributions/?contributor_name={quote_plus(name)}",
        "key": "own" if api_key != "DEMO_KEY" else "demo", "remaining": r.headers.get("X-RateLimit-Remaining"),
    }
    with _FEC_LOCK:
        try:
            cache = json.loads(_FEC_CACHE.read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001
            cache = {}
        cache[key] = {"at": time.time(), "data": data}
        if len(cache) > 300:
            cache = dict(sorted(cache.items(), key=lambda kv: -kv[1]["at"])[:300])
        _FEC_CACHE.write_text(json.dumps(cache), encoding="utf-8")
    return data


# ------------------------------------------------------------------ LDA lobbying disclosures
LDA = "https://lda.gov/api/v1/filings/"


def _lda(params):
    r = S.get(LDA, params=params, timeout=45)
    if r.status_code in (429, 503):
        raise RuntimeError(f"lda.gov is busy (HTTP {r.status_code}) - try again in a minute")
    r.raise_for_status()
    return r.json()


def _filing(f):
    acts = f.get("lobbying_activities") or []
    amt = f.get("income") or f.get("expenses")
    try:
        amt = float(amt) if amt is not None else None
    except ValueError:
        amt = None
    return {
        "registrant": (f.get("registrant") or {}).get("name"), "client": (f.get("client") or {}).get("name"),
        "client_country": (f.get("client") or {}).get("country_display"),
        "client_desc": (f.get("client") or {}).get("general_description"),
        "year": f.get("filing_year"), "period": f.get("filing_period_display"), "type": f.get("filing_type_display"),
        "amount": amt, "posted": (f.get("dt_posted") or "")[:10], "url": f.get("filing_document_url"),
        "issues": sorted({a.get("general_issue_code_display") for a in acts if a.get("general_issue_code_display")}),
        "desc": next((_clean(a.get("description"), 220) for a in acts if a.get("description")), ""),
        "foreign": [{"name": e.get("name"), "country": e.get("country_display") or e.get("country"),
                     "ownership": e.get("ownership_percentage"), "contribution": e.get("contribution")}
                    for e in f.get("foreign_entities") or []],
    }


def lda_country(q):
    cc = (q.get("cc") or "").upper()[:2]
    if not cc:
        raise ValueError("country code needed")

    def load():
        a = _lda({"client_country": cc, "ordering": "-dt_posted", "page_size": 25})
        b = _lda({"foreign_entity_country": cc, "ordering": "-dt_posted", "page_size": 25})
        return {"cc": cc, "client": {"count": a.get("count"), "filings": [_filing(f) for f in a.get("results", [])]},
                "foreign": {"count": b.get("count"), "filings": [_filing(f) for f in b.get("results", [])]}}
    return _memo(("lda_cc", cc), 6 * 3600, load)


def lda_client(q):
    name = (q.get("name") or "").split("|")[0].split(",")[0].strip()
    if not name:
        raise ValueError("enter a name")

    def load():
        a = _lda({"client_name": name, "ordering": "-dt_posted", "page_size": 25})
        fl = [_filing(f) for f in a.get("results", [])]
        by_year = defaultdict(float)
        for f in fl:
            if f["amount"]:
                by_year[f["year"]] += f["amount"]
        return {"name": name, "count": a.get("count"), "filings": fl, "by_year": sorted(by_year.items()),
                "link": f"https://lda.gov/filings/public/filing/search/?client_name={quote_plus(name)}"}
    return _memo(("lda_client", name.lower()), 6 * 3600, load)


# ------------------------------------------------------------------ FARA (foreign agents)
FARA_FILES = {"principals": "FARA_All_ForeignPrincipals.csv.zip", "registrants": "FARA_All_Registrants.csv.zip",
              "docs": "FARA_All_RegistrantDocs.csv.zip", "short": "FARA_All_ShortForms.csv.zip"}
_FARA = {"at": 0.0}
_FARA_LOCK = threading.Lock()
MEDIA_RX = re.compile(r"\b(television|tv|broadcast\w*|news\w*|media|press|daily|times|radio|xinhua|cgtn|cctv|"
                      r"sputnik|rt|tass|people's daily|global times|china daily|telesur|channel|magazine|"
                      r"rossiya|ria novosti|tv-novosti|publish\w*|journal|gazette|herald|post)\b", re.I)
FARA_CC = {"RUSSIA": "RU", "CHINA": "CN", "IRAN": "IR", "VENEZUELA": "VE", "QATAR": "QA", "SAUDI ARABIA": "SA",
           "UNITED ARAB EMIRATES": "AE", "ISRAEL": "IL", "TURKEY": "TR", "HUNGARY": "HU", "JAPAN": "JP",
           "KOREA, SOUTH": "KR", "TAIWAN": "TW", "UKRAINE": "UA", "INDIA": "IN", "PAKISTAN": "PK", "EGYPT": "EG",
           "MOROCCO": "MA", "MEXICO": "MX", "BELARUS": "BY", "CUBA": "CU", "HONG KONG": "HK", "IRAQ": "IQ",
           "AZERBAIJAN": "AZ", "ARMENIA": "AM", "GEORGIA": "GE", "SERBIA": "RS", "NIGERIA": "NG", "CANADA": "CA",
           "UNITED KINGDOM": "GB", "GERMANY": "DE", "FRANCE": "FR", "BAHRAIN": "BH", "KUWAIT": "KW", "OMAN": "OM",
           "JORDAN": "JO", "LIBYA": "LY", "SUDAN": "SD", "SYRIA": "SY", "LEBANON": "LB"}


def _date(s):
    s = (s or "").strip()
    for f in ("%m/%d/%Y", "%Y-%m-%d"):
        try:
            d = datetime.strptime(s, f)
            return d.strftime("%Y-%m-%d") if d.year > 1900 else ""
        except ValueError:
            pass
    return ""


def _fara():
    with _FARA_LOCK:
        if _FARA["at"] > time.time() - 86400:
            return _FARA
        tables = {}
        for k, fn in FARA_FILES.items():
            p = WDIR / fn
            if not p.exists() or p.stat().st_mtime < time.time() - 86400:
                try:
                    r = S.get("https://efile.fara.gov/bulk/zip/" + fn, timeout=180)
                    r.raise_for_status()
                    p.write_bytes(r.content)
                except Exception:  # noqa: BLE001
                    if not p.exists():
                        raise
            z = zipfile.ZipFile(p)
            raw = z.read(z.namelist()[0])
            try:
                txt = raw.decode("utf-8")
            except UnicodeDecodeError:
                txt = raw.decode("cp1252", errors="replace")  # DOJ exports are Windows-1252 ("General’s")
            tables[k] = [{kk.strip(): (vv or "").strip() for kk, vv in row.items() if isinstance(kk, str) and isinstance(vv, (str, type(None)))}
                         for row in csv.DictReader(io.StringIO(txt))]
        docs_by = defaultdict(list)
        for d in tables["docs"]:
            docs_by[d.get("Registration Number", "")].append({
                "date": _date(d.get("Date Stamped")), "type": d.get("Document Type", ""),
                "principal": d.get("Foreign Principal Name", ""), "country": d.get("Foreign Principal Country", ""),
                "url": d.get("URL", "")})
        for v in docs_by.values():
            v.sort(key=lambda x: x["date"], reverse=True)
        regs = {r.get("Registration Number", ""): r for r in tables["registrants"]}
        _FARA.update(tables)
        _FARA["docs_by"] = docs_by
        _FARA["regs"] = regs
        _FARA["at"] = time.time()
        return _FARA


def _fara_row(r, F):
    reg = r.get("Registration Number", "")
    fp = r.get("Foreign Principal", "")
    dl = F["docs_by"].get(reg, [])
    mine = [d for d in dl if d["principal"] and d["principal"].lower() == fp.lower()] or dl
    types = Counter(d["type"] for d in mine)
    rg = F["regs"].get(reg, {})
    return {
        "principal": fp, "country": r.get("Country/Location Represented", ""), "registrant": r.get("Registrant Name", ""),
        "reg": reg, "fp_date": _date(r.get("Foreign Principal Registration Date")),
        "fp_end": _date(r.get("Foreign Principal Termination Date")),
        "reg_date": _date(rg.get("Registration Date")), "reg_end": _date(rg.get("Termination Date")),
        "city": ", ".join(x for x in (rg.get("City"), rg.get("State")) if x),
        "media": bool(MEDIA_RX.search(fp) or MEDIA_RX.search(r.get("Registrant Name", ""))),
        "doc_types": types.most_common(6), "docs": mine[:6], "ndocs": len(mine),
    }


def fara_country(q):
    country = (q.get("country") or "RUSSIA").upper()
    inc = q.get("terminated") in ("1", "true", "yes")
    F = _fara()
    rows = [r for r in F["principals"] if r.get("Country/Location Represented", "").upper() == country
            and (inc or not r.get("Foreign Principal Termination Date"))]
    out = [_fara_row(r, F) for r in rows]
    out.sort(key=lambda x: (x["fp_end"] == "", x["fp_date"]), reverse=True)
    return {"country": country, "cc": FARA_CC.get(country), "rows": out[:400], "count": len(out),
            "registrants": len({x["reg"] for x in out}), "media": sum(1 for x in out if x["media"]),
            "updated": datetime.fromtimestamp(F["at"], timezone.utc).isoformat()}


def fara_summary(q):
    F = _fara()
    active = [r for r in F["principals"] if not r.get("Foreign Principal Termination Date")]
    by = Counter(r.get("Country/Location Represented", "") for r in active)
    regs_by = defaultdict(set)
    for r in active:
        regs_by[r.get("Country/Location Represented", "")].add(r.get("Registration Number"))
    cutoff = datetime.now().strftime("%Y-%m-%d")
    recent = []
    for r in F["principals"]:
        d = _date(r.get("Foreign Principal Registration Date"))
        if d and (datetime.strptime(cutoff, "%Y-%m-%d") - datetime.strptime(d, "%Y-%m-%d")).days <= 180:
            recent.append(_fara_row(r, F))
    recent.sort(key=lambda x: x["fp_date"], reverse=True)
    media = [_fara_row(r, F) for r in F["principals"]
             if r.get("Country/Location Represented", "").upper() in ("RUSSIA", "CHINA", "IRAN", "VENEZUELA", "QATAR",
                                                                     "SAUDI ARABIA", "UNITED ARAB EMIRATES", "TURKEY", "HUNGARY")
             and (MEDIA_RX.search(r.get("Foreign Principal", "")) or MEDIA_RX.search(r.get("Registrant Name", "")))]
    media.sort(key=lambda x: (x["fp_end"] == "", x["country"], x["fp_date"]), reverse=True)
    return {
        "countries": [{"country": c, "principals": n, "registrants": len(regs_by[c]), "cc": FARA_CC.get(c)}
                      for c, n in by.most_common(40) if c],
        "all_countries": sorted({r.get("Country/Location Represented", "") for r in F["principals"]} - {""}),
        "active_principals": len(active), "active_registrants": len({r.get("Registration Number") for r in active}),
        "recent": recent[:80], "media": media[:150],
        "updated": datetime.fromtimestamp(F["at"], timezone.utc).isoformat(),
    }


def fara_search(q):
    s = (q.get("q") or "").strip().lower()
    if len(s) < 3:
        raise ValueError("type at least 3 characters")
    terms = s.split()
    F = _fara()
    match = lambda *xs: all(t in " ".join(x or "" for x in xs).lower() for t in terms)  # noqa: E731
    pr = [_fara_row(r, F) for r in F["principals"] if match(r.get("Foreign Principal"), r.get("Registrant Name"))][:150]
    rg = []
    for r in F["registrants"]:
        if match(r.get("Name"), r.get("Business Name")):
            reg = r.get("Registration Number", "")
            rg.append({"reg": reg, "name": r.get("Name"), "business": r.get("Business Name"),
                       "date": _date(r.get("Registration Date")), "end": _date(r.get("Termination Date")),
                       "city": ", ".join(x for x in (r.get("City"), r.get("State")) if x),
                       "principals": sorted({p.get("Foreign Principal", "") + " (" + p.get("Country/Location Represented", "") + ")"
                                             for p in F["principals"] if p.get("Registration Number") == reg})[:12],
                       "docs": F["docs_by"].get(reg, [])[:5]})
    sf = [{"name": f"{r.get('Short Form First Name', '')} {r.get('Short Form Last Name', '')}".strip(),
           "registrant": r.get("Registrant Name"), "reg": r.get("Registration Number"),
           "date": _date(r.get("Short Form Date")), "end": _date(r.get("Short Form Termination Date"))}
          for r in F["short"] if match(r.get("Short Form First Name"), r.get("Short Form Last Name"), r.get("Registrant Name"))][:150]
    return {"q": s, "principals": pr, "registrants": rg[:80], "individuals": sf}


# ------------------------------------------------------------------ GOV & RESEARCH
ENFORCE = re.compile(
    r"foreign agent|\bFARA\b|foreign (?:malign )?influence|malign|disinformation|propaganda|sanction|espionage|"
    r"\bspy\b|\bspies\b|spying|acting as an? (?:illegal )?agent|agent of (?:the )?(?:PRC|China|Russia|Iran)|"
    r"transnational repression|election (?:interference|influence)|influence operation|covert|bot farm|"
    r"state-sponsored|united front|ministry of state security|\bGRU\b|\bFSB\b|\bIRGC\b|Chinese Communist Party|"
    r"\bPRC\b|Kremlin|export control|evading sanctions|smuggl\w+ .{0,40}(?:Russia|China|Iran)|"
    r"(?:Russian|Chinese|Iranian|North Korean) (?:hackers?|intelligence|government|national|agents?)", re.I)
_FR_NOISE = re.compile(r"Information Collection|Paperwork Reduction|Submitted for Review|Sunshine Act|Meeting Notice", re.I)
FR_TERMS = ["foreign malign influence", "Foreign Agents Registration Act", "foreign adversary", "disinformation"]


def _fedreg():
    out, seen = [], set()
    for t in FR_TERMS:
        try:
            r = S.get("https://www.federalregister.gov/api/v1/documents.json", timeout=30, params=[
                ("conditions[term]", f'"{t}"'), ("order", "newest"), ("per_page", "12"),
                ("fields[]", "title"), ("fields[]", "publication_date"), ("fields[]", "html_url"),
                ("fields[]", "agencies"), ("fields[]", "type"), ("fields[]", "abstract")])
            r.raise_for_status()
            for x in r.json().get("results", []):
                if x["html_url"] in seen or _FR_NOISE.search(x.get("title") or ""):
                    continue
                seen.add(x["html_url"])
                out.append({"title": x.get("title"), "date": x.get("publication_date"), "url": x.get("html_url"),
                            "type": x.get("type"), "term": t, "abstract": _clean(x.get("abstract"), 260),
                            "agency": ", ".join(a.get("name", "") for a in x.get("agencies") or [] if a.get("name"))})
        except Exception:  # noqa: BLE001
            continue
    out.sort(key=lambda x: x["date"] or "", reverse=True)
    return out


def gov(q):
    ensure()
    ds = docs(30 * 24)
    g = [d for d in ds if d["grp"] == "usgov"]
    by = defaultdict(list)
    for d in sorted(g, key=lambda d: -d["ts"]):
        by[SRC[d["src"]]["name"]].append(_out(d))
    enf = [d for d in sorted(g, key=lambda d: -d["ts"]) if ENFORCE.search(d["title"] + " " + d["summary"])]
    res = [d for d in sorted(ds, key=lambda d: -d["ts"]) if d["grp"] == "research"]
    return {"agencies": {k: v[:15] for k, v in by.items()}, "enforcement": [_out(d) for d in enf[:80]],
            "research": [_out(d) for d in res[:40]], "fedreg": _memo(("fedreg",), 6 * 3600, _fedreg),
            "archive": _archive()}


# ------------------------------------------------------------------ status
def status(q):
    ensure()
    rows = {r[0]: (r[1], r[2]) for r in _q("SELECT src, COUNT(*), MAX(ts) FROM items GROUP BY src")}
    out = []
    for s in SOURCES:
        st = STATUS.get(s["key"], {})
        n, last = rows.get(s["key"], (0, None))
        out.append({"key": s["key"], "name": s["name"], "grp": s["grp"], "cc": s["cc"], "note": s["note"],
                    "url": s["url"], "ok": st.get("ok"), "err": st.get("err"), "fetched": st.get("at"),
                    "archived": n, "latest": last})
    return {"sources": out, "groups": GROUPS, "countries": COUNTRIES, "archive": _archive()}

/* Signal Monitor - alternative open-data signals vs price */
"use strict";
const PAGE = $("#page");
const SS = Object.assign({ tab: "dive", sym: "NVDA", scanList: "" }, store("sig.state") || {});
const saveS = () => store("sig.state", SS);
{ // deep links: /signal/#scan, /signal/#about, /signal/#dive/TSLA
  const [t, s] = location.hash.replace(/^#\/?/, "").split("/");
  if (["dive", "scan", "about"].includes(t)) SS.tab = t;
  if (s) SS.sym = decodeURIComponent(s).toUpperCase();
}
let gen = 0;

/* ------------------------------------------------------------------ routing */
function go(tab, sym) {
  SS.tab = tab;
  if (sym) SS.sym = sym.toUpperCase();
  saveS();
  render();
}
$("#tabs").onclick = (e) => { const b = e.target.closest("button[data-tab]"); if (b) go(b.dataset.tab); };
const cmd = $("#cmd");
const submit = () => { const v = cmd.value.trim().toUpperCase().split(/\s+/)[0]; cmd.value = ""; if (v) go("dive", v); };
cmd.onkeydown = (e) => { if (e.key === "Enter") submit(); };
$(".cmd-go").onclick = submit;

function render() {
  gen++;
  $$("#tabs button").forEach((b) => b.classList.toggle("active", b.dataset.tab === SS.tab));
  ({ dive, scan, about }[SS.tab] || dive)(gen);
}

/* ------------------------------------------------------------------ helpers */
const zClass = (z) => (!isNum(z) ? "" : z >= 2.5 ? "z-hot" : z >= 1.5 ? "z-warm" : z <= -1.5 ? "z-cold" : "z-norm");
const zBadge = (z) => `<span class="zb ${zClass(z)}">${isNum(z) ? (z > 0 ? "+" : "") + fmt(z, 1) + "σ" : "--"}</span>`;
const zWord = (z) => (!isNum(z) ? "unknown" : z >= 2.5 ? "EXTREME" : z >= 1.5 ? "elevated" : z <= -1.5 ? "unusually quiet" : "normal");
const sentClass = (s) => (s > 0.05 ? "up" : s < -0.05 ? "down" : "muted");
function newsLi(n) {
  return `<li><span class="tm">${ago(n.ts)}</span><span class="sc ${sentClass(n.score)}">${n.score > 0 ? "+" : ""}${fmt(n.score, 1)}</span>
    <span><a href="${esc(n.link)}" target="_blank" rel="noopener">${esc(n.title)}</a> <span class="so">${esc(n.source)}</span></span></li>`;
}

/* ================================================================== DIVE */
async function dive(g) {
  const sym = SS.sym;
  setStatus("busy", `Loading ${sym}...`);
  PAGE.innerHTML = `<div class="loading">Gathering open-data signals for ${esc(sym)}...</div>`;
  const o = await soft(api(`/api/sig/overview?symbol=${enc(sym)}`));
  if (g !== gen) return;
  if (o.error) { PAGE.innerHTML = errBox(o.error); setStatus("err", "Error"); return; }
  const m = o.meta, st = o.stats || {};
  const term = (store("sig.term." + sym)) || m.short || sym;
  const P = o.price;
  const lastPx = P.close[P.close.length - 1], firstPx = P.close.find(isNum);
  const ll = o.leadlag;
  const ss = o.spike_stats;
  /* insight bullets */
  const ins = [];
  if (st.z !== undefined) ins.push(`Attention today is <b>${zWord(st.z)}</b> (${zBadge(st.z)} vs. the trailing 60 days, weekday-adjusted). Last 7 days run at <b>${fmt(st.ratio7_60, 2)}x</b> the 60-day average.`);
  if (ss && isNum(ss.avg_abs) && isNum(ss.normal_abs)) ins.push(`On the <b>${ss.n}</b> attention-spike days (&gt;2.5&sigma;) the stock moved <b>${fmt(ss.avg_abs, 2)}%</b> on average, vs <b>${fmt(ss.normal_abs, 2)}%</b> on normal days${ss.avg_abs > ss.normal_abs * 1.5 ? " - spikes reliably flag big moves" : ""}.`);
  if (ss && isNum(ss.avg_fwd5)) ins.push(`Average 5-day return <i>after</i> a spike: <b class="${cls(ss.avg_fwd5)}">${pct(ss.avg_fwd5)}</b>${Math.abs(ss.avg_fwd5) < 1 ? " (no consistent follow-through)" : ss.avg_fwd5 < 0 ? " (attention peaks have tended to mark local tops)" : " (momentum has tended to continue)"}.`);
  if (ll) {
    const lead = ll.abs[ll.lags.indexOf(1)], same = ll.abs[ll.lags.indexOf(0)];
    ins.push(`Attention vs. trading volume correlation: <b>${fmt(ll.vol_corr, 2)}</b>. Attention vs. same-day |move|: <b>${fmt(same, 2)}</b>; vs. next-day |move|: <b>${fmt(lead, 2)}</b>${isNum(lead) && lead > 0.1 ? " - attention tends to <b>lead</b> volatility" : ""}.`);
  }
  if (o.edits) ins.push(`Wikipedia article edited <b>${o.edits.last30}</b> times in the last 30 days (${o.edits.total} in 180 days). Edit bursts usually mark real-world events.`);
  const head = `<section class="panel c12"><div class="des-head">
      <span class="amber" style="font-size:18px">${esc(sym)}</span><span class="nm">${esc(m.name)}</span>
      <span class="px">${fmt(lastPx)}</span><span class="${cls((lastPx / firstPx - 1) * 100)}">${pct((lastPx / firstPx - 1) * 100)} 1Y</span>
      <span class="muted">${esc([m.type, m.sector, m.industry].filter(Boolean).join(" | "))}</span>
      <span style="margin-left:auto" class="muted">Wikipedia article:
        <input id="wiki-title" class="inp wide" value="${esc(m.title || "")}" placeholder="Article title" spellcheck="false"><button class="btn sm" id="wiki-set">SET</button>
        ${m.title ? `<a href="https://en.wikipedia.org/wiki/${enc(m.title.replace(/ /g, "_"))}" target="_blank" class="muted">&#8599;</a>` : ""}</span>
    </div></section>`;
  const viewsErr = o.views_error ? `<div class="err-box">&#9888; ${esc(o.views_error)}${o.retry ? ` <button class="btn sm" id="retry">RETRY IN <span id="cd">${o.retry}</span>s</button>` : ""}</div>` : "";
  const spikesT = !arr(o.spikes).length ? `<div class="loading">No attention spikes above 2.5&sigma; in the past year</div>` :
    `<table class="t"><thead><tr><th>Date</th><th>Views</th><th>Attn z</th><th>Day Move</th><th>Next 5D</th><th>Volume x</th></tr></thead><tbody>${
      o.spikes.map((s) => `<tr><td>${esc(s.date)}</td><td>${big(s.views)}</td><td>${zBadge(s.z)}</td><td><span class="pill ${cls(s.ret)}">${pct(s.ret)}</span></td>
        <td class="${cls(s.fwd5)}">${pct(s.fwd5)}</td><td class="${s.volx > 1.5 ? "amber" : ""}">${isNum(s.volx) ? fmt(s.volx, 1) + "x" : "--"}</td></tr>`).join("")}</tbody></table>`;
  PAGE.innerHTML = `<div class="grid">${head}
    ${panel("Signal Read-out", `<ul class="insights">${ins.map((x) => `<li>${x}</li>`).join("") || "<li>Attention data unavailable</li>"}</ul>${viewsErr}`, { cls: "c5" })}
    ${panel("Price vs Wikipedia Attention (1Y)", `<div class="chart-box"><canvas id="pv-cv"></canvas></div>`, { cls: "c7", src: "Yahoo Finance + Wikimedia pageviews" })}
    ${panel("Attention z-score (weekday-adjusted, 60D baseline)", `<div class="chart-box short"><canvas id="z-cv"></canvas></div>`, { cls: "c7" })}
    ${panel("Lead / Lag: does attention precede moves?", `<div class="chart-box short"><canvas id="ll-cv"></canvas></div>
      <div class="note">Correlation of attention z on day t with the stock's |move| (bars) and signed move (line) on day t+k. Bars right of 0 = attention leads volatility.</div>`, { cls: "c5" })}
    ${panel("Attention Spikes &amp; What Price Did", spikesT, { cls: "c7", scroll: true, maxh: 380 })}
    ${panel("Wikipedia Edit Activity (180D)", o.edits ? `<div class="chart-box short"><canvas id="ed-cv"></canvas></div>` : `<div class="loading">Unavailable</div>`, { cls: "c5", src: "MediaWiki API" })}
    ${panel(`Headline Sentiment - last 30 days <span class="muted">query: <input id="term" class="inp wide" value="${esc(term)}" spellcheck="false"><button class="btn sm" id="term-set">SET</button></span>`,
      `<div id="news-box"><div class="loading">Scoring headlines...</div></div>`, { cls: "c12", src: "Google News RSS, finance lexicon" })}
    ${panel("Hacker News Mentions (52 weeks)", `<div id="hn-box"><div class="loading">Counting...</div></div>`, { cls: "c7", src: "HN Algolia API" })}
    ${panel("GDELT Global News Volume &amp; Tone (3M)", `<div id="gd-box"><div class="note">GDELT monitors news in 65 languages worldwide. It is heavily rate-limited, so it loads on request.</div>
      <div style="padding:0 10px 10px"><button class="btn" id="gd-load">LOAD GDELT</button></div></div>`, { cls: "c5", src: "GDELT DOC 2.0" })}
  </div>`;
  /* charts */
  if (o.views) {
    const V = o.views;
    const vmap = Object.fromEntries(V.labels.map((d, i) => [d, V.views[i]]));
    mkChart("pv-cv", {
      type: "bar",
      data: { labels: P.labels, datasets: [
        { type: "line", label: sym + " price", data: P.close, borderColor: "#ffa028", borderWidth: 1.8, pointRadius: 0, yAxisID: "y", tension: 0.1 },
        { type: "bar", label: "Wikipedia views", data: P.labels.map((d) => vmap[d] ?? null), backgroundColor: "rgba(92,179,255,.45)", yAxisID: "y2", barPercentage: 1, categoryPercentage: 1 },
      ] },
      options: { responsive: true, maintainAspectRatio: false, animation: false, interaction: { mode: "index", intersect: false },
        plugins: { legend: { labels: { color: "#cfcfcf", boxWidth: 12 } }, tooltip: { ...TIP } },
        scales: { x: { ticks: { maxTicksLimit: 8, maxRotation: 0 }, grid: { display: false } },
          y: { position: "right", ticks: { maxTicksLimit: 6 } }, y2: { position: "left", grid: { display: false }, ticks: { maxTicksLimit: 5, callback: (v) => big(v) } } } },
    });
    line("z-cv", V.labels, [{ label: "z", data: V.z, color: "#c084fc", fill: true, bg: "rgba(192,132,252,.08)" },
      { label: "+2.5", data: V.labels.map(() => 2.5), color: "#ff525299", dash: [4, 3], borderWidth: 1, noTip: true, noLegend: true },
      { label: "0", data: V.labels.map(() => 0), color: "#55555c", borderWidth: 1, noTip: true, noLegend: true }], { legend: false, fmt: (v) => fmt(v, 2) });
  }
  if (ll) {
    bars("ll-cv", ll.lags.map((k) => (k > 0 ? "+" + k : String(k))), [
      { label: "corr(z, |move|)", data: ll.abs, backgroundColor: ll.lags.map((k) => (k > 0 ? "#ffa028" : k === 0 ? "#c084fc" : "#55555c")) },
      { type: "line", label: "corr(z, move)", data: ll.ret, borderColor: "#5cb3ff" }], { fmt: (v) => fmt(v, 3), yfmt: (v) => fmt(v, 2) });
  }
  if (o.edits) bars("ed-cv", o.edits.labels, [{ label: "Edits", data: o.edits.count, backgroundColor: "#2dd4bf" }], { legend: false, fmt: (v) => fmt(v, 0), xticks: 6 });
  setStatus("ok", "Updated " + new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }));
  /* bindings */
  $("#wiki-set").onclick = async () => {
    const t = $("#wiki-title").value.trim();
    if (!t) return;
    await soft(api(`/api/sig/overview?symbol=${enc(sym)}&title=${enc(t)}`));
    render();
  };
  $("#term-set").onclick = () => { store("sig.term." + sym, $("#term").value.trim() || m.short); loadNews(g, $("#term").value.trim() || m.short, sym); loadHN(g, $("#term").value.trim() || m.short); };
  $("#gd-load").onclick = () => loadGdelt(g, term);
  if (o.retry) {
    let n = o.retry;
    const t = setInterval(() => { n--; const c = $("#cd"); if (!c || g !== gen) { clearInterval(t); return; } c.textContent = n; if (n <= 0) { clearInterval(t); render(); } }, 1000);
    $("#retry").onclick = () => { clearInterval(t); render(); };
  }
  loadNews(g, term, sym);
  loadHN(g, term);
}

async function loadNews(g, term, sym) {
  const box = $("#news-box");
  box.innerHTML = `<div class="loading">Scoring headlines for "${esc(term)}"...</div>`;
  const n = await soft(api(`/api/sig/news?name=${enc(term)}&symbol=${enc(sym)}`));
  if (g !== gen) return;
  if (n.error) { box.innerHTML = errBox(n.error); return; }
  const gaugePos = isNum(n.avg) ? ((n.avg + 1) / 2) * 100 : 50;
  box.innerHTML = `<div class="grid" style="padding:6px">
    <div class="c3"><div class="kpis col">
      <div class="kpi"><span>Net tone (-1 to +1)</span><b class="${sentClass(n.avg)}">${isNum(n.avg) ? (n.avg > 0 ? "+" : "") + fmt(n.avg, 2) : "--"}</b>
        <div class="tone"><span style="left:calc(${gaugePos}% - 2px)"></span></div></div>
      <div class="kpi"><span>Headlines (30D)</span><b>${n.n}</b><small>${n.scored} carry sentiment words</small></div>
      <div class="kpi"><span>Positive / Negative</span><b><span class="up">${fmt(n.pos_share, 0)}%</span> / <span class="down">${fmt(n.neg_share, 0)}%</span></b></div>
    </div>
    <div class="note">Top sources: ${n.sources.slice(0, 8).map(([s, c]) => `${esc(s)} <b>${c}</b>`).join(" &middot; ")}</div></div>
    <div class="c5"><div class="chart-box short"><canvas id="ns-cv"></canvas></div></div>
    <div class="c4"><div class="hl"><b class="up">Most positive</b><ul class="news">${n.top_pos.slice(0, 5).map(newsLi).join("") || "<li class='muted'>none</li>"}</ul>
      <b class="down">Most negative</b><ul class="news">${n.top_neg.slice(0, 5).map(newsLi).join("") || "<li class='muted'>none</li>"}</ul></div></div>
    <div class="c12"><details><summary class="muted">All ${n.items.length} headlines, newest first</summary><ul class="news">${n.items.map(newsLi).join("")}</ul></details></div>
  </div>
  <div class="note">Sentiment uses a finance word list (beat/upgrade/surge vs miss/probe/plunge) with simple negation handling. It is a fast, transparent signal, not deep NLP.
    Google News returns the 100 most recent headlines, so for heavily covered names the daily counts are concentrated in the last few days.</div>`;
  bars("ns-cv", n.days.map((d) => d.slice(5)), [
    { label: "Headlines", data: n.count, backgroundColor: "rgba(92,179,255,.45)", yAxisID: "y2" },
    { type: "line", label: "Avg tone", data: n.score, borderColor: "#ffa028", yAxisID: "y", pointRadius: 2 }],
  { fmt: (v) => fmt(v, 2), yfmt: (v) => fmt(v, 1), y2: (v) => fmt(v, 0) });
}

async function loadHN(g, term) {
  const box = $("#hn-box");
  box.innerHTML = `<div class="loading">Counting Hacker News stories for "${esc(term)}"...</div>`;
  const h = await soft(api(`/api/sig/hn?q=${enc(term)}`));
  if (g !== gen) return;
  if (h.error) { box.innerHTML = errBox(h.error); return; }
  const tot = h.count.reduce((a, b) => a + b, 0);
  const recent = h.count.slice(-4).reduce((a, b) => a + b, 0) / 4, base = h.count.slice(0, -4).reduce((a, b) => a + b, 0) / Math.max(1, h.count.length - 4);
  box.innerHTML = `<div class="note">${fmt(tot, 0)} stories in 52 weeks &middot; last 4 weeks averaging <b>${fmt(recent, 1)}</b>/wk vs <b>${fmt(base, 1)}</b>/wk before
    (${base ? `<span class="${cls(recent - base)}">${pct((recent / base - 1) * 100, 0)}</span>` : "--"}). Tech-community attention often leads mainstream coverage.</div>
    <div class="chart-box short"><canvas id="hn-cv"></canvas></div>
    <ul class="news">${h.top.slice(0, 8).map((s) => `<li><span class="tm">${ago(s.ts)}</span><span class="sc amber">${fmt(s.points, 0)}&#9650;</span>
      <span><a href="${esc(s.url)}" target="_blank" rel="noopener">${esc(s.title)}</a> <a class="so" href="${esc(s.hn)}" target="_blank">${fmt(s.comments, 0)} comments</a></span></li>`).join("")}</ul>`;
  bars("hn-cv", h.weeks.map((d) => d.slice(5)), [{ label: "Stories / week", data: h.count, backgroundColor: "#ff6600cc" }], { legend: false, fmt: (v) => fmt(v, 0), xticks: 10 });
}

async function loadGdelt(g, term) {
  const box = $("#gd-box");
  box.innerHTML = `<div class="loading">Querying GDELT (paced at one request per 5s)...</div>`;
  const d = await soft(api(`/api/sig/gdelt?q=${enc(term)}`));
  if (g !== gen) return;
  if (d.error) { box.innerHTML = errBox(d.error) + `<div style="padding:0 10px 10px"><button class="btn" id="gd-load">TRY AGAIN</button></div>`; $("#gd-load").onclick = () => loadGdelt(g, term); return; }
  box.innerHTML = `<div class="chart-box short"><canvas id="gd-cv"></canvas></div><div class="note">Bars: articles per day worldwide. Line: average tone (negative = critical coverage).</div>`;
  const L = d.vol.dates.map((x) => `${x.slice(4, 6)}-${x.slice(6, 8)}`);
  const tmap = Object.fromEntries(d.tone.dates.map((x, i) => [x, d.tone.values[i]]));
  bars("gd-cv", L, [{ label: "Articles", data: d.vol.values, backgroundColor: "rgba(92,179,255,.45)", yAxisID: "y2" },
    { type: "line", label: "Tone", data: d.vol.dates.map((x) => tmap[x] ?? null), borderColor: "#ffa028", yAxisID: "y" }],
  { fmt: (v) => fmt(v, 2), yfmt: (v) => fmt(v, 1), y2: (v) => big(v) });
}

/* ================================================================== SCAN */
let UNIS = null; // preset universes from the server
/* Signal tags: [label, colour, explanation] */
const SIG_DEFS = {
  SURGE: ["#ff5252", "Attention more than 2.5σ above this company's normal today"],
  BUILDING: ["#ffa028", "7-day attention 30%+ above the 60-day average and still rising vs a week ago"],
  UNPRICED: ["#c084fc", "Attention ≥2σ but the price has moved less than 2% over 5 days - the move may not have happened yet"],
  "VOL CONFIRM": ["#34d27b", "Trading volume ≥2x its 20-day average together with elevated attention"],
  "QUIET MOVE": ["#5cb3ff", "Price moved ≥7% in 5 days with no rise in public attention - insiders/institutions, or nobody noticed yet"],
  FADING: ["#8b8b92", "Spiked above 2.5σ within the last 7 days, already back to normal"],
};
function sigTags(r) {
  const t = [], z = r.z;
  if (!isNum(z)) return t;
  if (z >= 2.5) t.push("SURGE");
  else if (isNum(r.zmax7) && r.zmax7 >= 2.5 && z < 1) t.push("FADING");
  if (isNum(r.ratio) && r.ratio >= 1.3 && z >= 1 && isNum(r.z7ago) && z > r.z7ago) t.push("BUILDING");
  if (z >= 2 && isNum(r.r5) && Math.abs(r.r5) < 2) t.push("UNPRICED");
  if (z >= 1.5 && isNum(r.volx) && r.volx >= 2) t.push("VOL CONFIRM");
  if (z < 1 && isNum(r.r5) && Math.abs(r.r5) >= 7) t.push("QUIET MOVE");
  return t;
}
const sigHTML = (t) => t.map((s) => `<span class="stag" style="--c:${SIG_DEFS[s][0]}" title="${esc(SIG_DEFS[s][1])}">${s}</span>`).join("");
const SCAN_COLS = [
  ["#", null], ["Ticker", "sym"], ["Name", "name"], ["Sector", "sector"], ["Signals", "nsig"], ["Views", "last"], ["Attn z", "z"],
  ["z 7D ago", "z7ago"], ["Max z 7D", "zmax7"], ["7D/60D", "ratio"], ["Spikes 30D", "spikes30"], ["Price", "px"], ["1D", "r1"],
  ["5D", "r5"], ["1M", "r21"], ["Vol x", "volx"], ["60-Day Views", null], ["", null],
];

async function scan(g) {
  if (!UNIS) { const u = await soft(api("/api/sig/universes")); if (g !== gen) return; UNIS = u.error ? { max: 150, lists: [] } : u; }
  const wl = (store("mt.watchlist") || []).filter((s) => !/[=^]/.test(s));
  const uni = SS.scanUni || (SS.scanList ? "custom" : "default");
  const preset = UNIS.lists.find((l) => l.key === uni);
  const list = uni === "custom" ? (SS.scanList || "") : uni === "default" ? [...new Set([...wl, ...(preset ? preset.syms : [])])].join(" ") : (preset ? preset.syms.join(" ") : "");
  const syms = [...new Set(list.toUpperCase().split(/[\s,]+/).filter(Boolean))].slice(0, UNIS.max || 150);
  const sort = SS.scanSort || { k: "z", d: -1 };
  let filt = SS.scanFilt || "all";
  let q = "";
  PAGE.innerHTML = `<div class="grid">
    ${panel("Attention Scanner - who is the internet suddenly reading about?", `<div class="scanbar">
        <label>List <select id="scan-uni">${UNIS.lists.map((l) => `<option value="${l.key}" ${l.key === uni ? "selected" : ""}>${esc(l.label)}${l.key === "default" ? "" : ` (${l.syms.length})`}</option>`).join("")}
          <option value="custom" ${uni === "custom" ? "selected" : ""}>Custom list...</option></select></label>
        <label class="grow">Tickers (space or comma separated, max ${UNIS.max || 150}) <input id="scan-in" value="${esc(syms.join(" "))}" spellcheck="false"></label>
        <span class="btns"><button class="btn primary" id="scan-run">SCAN</button><button class="btn" id="scan-stop">STOP</button><button class="btn" id="scan-csv">CSV</button></span>
      </div>
      <div class="scanbar">${segHTML("scan-filt", [["all", "ALL"], ["sig", "WITH SIGNALS"], ["hot", "Z ≥ 1.5"], ["cold", "UNUSUALLY QUIET"], ["err", "ERRORS"]], filt)}
        <input id="scan-q" class="inp wide" placeholder="Filter by ticker / name / sector" spellcheck="false">
        <span class="sig-leg">${Object.keys(SIG_DEFS).map((s) => sigHTML([s])).join("")}<span class="muted small">hover a tag for its meaning</span></span></div>
      <div id="scan-kpis"></div>
      <div id="scan-prog" class="note"></div>`, { cls: "c12", src: "Wikimedia pageviews + Yahoo Finance" })}
    ${panel("Attention vs 5-Day Price Move", `<div class="chart-box"><canvas id="sc-cv"></canvas></div>
      <div class="note">Top-left/right = crowds piling in after a move. Top-centre = attention with no move yet (UNPRICED). Bottom edges = moves nobody is talking about (QUIET MOVE).</div>`, { cls: "c7" })}
    ${panel("Average Attention by Sector", `<div class="chart-box"><canvas id="sec-cv"></canvas></div>`, { cls: "c5" })}
    ${panel("Results", `<div id="scan-res"></div>`, { cls: "c12", scroll: true, maxh: 760 })}
    <section class="panel c12"><div class="pb flush"><div class="note">Daily Wikipedia pageviews per company, weekday-adjusted and compared with each company's own last 60 days.
      <b>Attn z</b> above +2.5&sigma; = an unusual surge in public attention. Page views are cached for 12 hours and prices for 15 minutes, so a re-scan is fast.
      Wikimedia throttles anonymous apps, so new rows fill in gradually (add a contact in <a href="#" id="go-about">Settings</a> to raise the limit).
      Click a row for the deep dive; <b>+WL</b> adds the ticker to the Terminal watchlist.</div></div></section>
  </div>`;
  $("#go-about").onclick = (e) => { e.preventDefault(); go("about"); };
  $("#scan-uni").onchange = (e) => { SS.scanUni = e.target.value; if (SS.scanUni === "custom" && !SS.scanList) SS.scanList = $("#scan-in").value.trim(); saveS(); render(); };
  $("#scan-run").onclick = () => {
    const v = $("#scan-in").value.trim().toUpperCase().split(/[\s,]+/).filter(Boolean).join(" ");
    if (v !== syms.join(" ")) { SS.scanUni = "custom"; SS.scanList = v; }
    saveS(); render();
  };
  let stopped = false;
  $("#scan-stop").onclick = () => { stopped = true; $("#scan-prog").innerHTML = "Stopped."; };
  bindSeg("scan-filt", (v) => { filt = SS.scanFilt = v; saveS(); draw(); });
  $("#scan-q").oninput = (e) => { q = e.target.value.trim().toLowerCase(); draw(); };

  const rows = {}, px = {};
  const merged = () => Object.values(rows).map((r) => { const m = { ...r, ...(px[r.sym] || {}) }; m.tags = sigTags(m); m.nsig = m.tags.length; return m; });
  $("#scan-csv").onclick = () => downloadCSV(`attention-scan-${new Date().toISOString().slice(0, 10)}.csv`, [
    ["Ticker", "Name", "Article", "Sector", "Signals", "Views", "Attn z", "z 7D ago", "Max z 7D", "7D/60D", "Spikes 30D", "Price", "1D %", "5D %", "1M %", "Vol x", "Data date", "Error"],
    ...merged().map((r) => [r.sym, r.name, r.title, r.sector, (r.tags || []).join(" "), r.last, r.z, r.z7ago, r.zmax7, r.ratio, r.spikes30, r.px, r.r1, r.r5, r.r21, r.volx, r.date, r.error])]);

  let chartTick = 0;
  function draw(force) {
    if (g !== gen) return;
    const all = merged();
    const ok = all.filter((r) => isNum(r.z));
    /* KPIs */
    const n = (f) => ok.filter(f).length;
    const avg = ok.length ? ok.reduce((a, r) => a + r.z, 0) / ok.length : null;
    const sigCount = (s) => ok.filter((r) => r.tags.includes(s)).length;
    $("#scan-kpis").innerHTML = `<div class="kpis small">
      <div class="kpi"><span>Scanned</span><b>${ok.length}<small> / ${syms.length}</small></b></div>
      <div class="kpi"><span>Surging (&ge;2.5&sigma;)</span><b class="${n((r) => r.z >= 2.5) ? "down" : ""}">${n((r) => r.z >= 2.5)}</b></div>
      <div class="kpi"><span>Elevated (1.5-2.5&sigma;)</span><b>${n((r) => r.z >= 1.5 && r.z < 2.5)}</b></div>
      <div class="kpi"><span>Unusually quiet</span><b>${n((r) => r.z <= -1.5)}</b></div>
      <div class="kpi"><span>Building</span><b>${sigCount("BUILDING")}</b></div>
      <div class="kpi"><span>Unpriced attention</span><b>${sigCount("UNPRICED")}</b></div>
      <div class="kpi"><span>Quiet moves</span><b>${sigCount("QUIET MOVE")}</b></div>
      <div class="kpi"><span>Average z</span><b class="${cls(avg)}">${isNum(avg) ? (avg > 0 ? "+" : "") + fmt(avg, 2) : "--"}</b></div></div>`;
    /* table */
    let vis = filt === "err" ? all.filter((r) => !isNum(r.z)) : ok.filter((r) => filt === "sig" ? r.nsig > 0 : filt === "hot" ? r.z >= 1.5 : filt === "cold" ? r.z <= -1.5 : true);
    if (q) vis = vis.filter((r) => [r.sym, r.name, r.title, r.sector].some((x) => String(x || "").toLowerCase().includes(q)));
    vis.sort((a, b) => { const x = a[sort.k], y = b[sort.k];
      if (x == null && y == null) return 0; if (x == null) return 1; if (y == null) return -1;
      return (typeof x === "string" ? x.localeCompare(y) : x - y) * sort.d; });
    const wlNow = new Set(store("mt.watchlist") || []);
    $("#scan-res").innerHTML = filt === "err" ? `<table class="t"><tbody>${vis.map((r) => `<tr><td class="amber">${esc(r.sym)}</td><td class="muted wrap">${esc(r.error || "")}</td></tr>`).join("") || "<tr><td class='muted'>No errors</td></tr>"}</tbody></table>` :
      `<table class="t scan"><thead><tr>${SCAN_COLS.map(([l, k]) => `<th ${k ? `data-k="${k}" class="sortable ${sort.k === k ? "sorted" : ""}"` : ""}>${l}${sort.k === k ? (sort.d > 0 ? " &#9650;" : " &#9660;") : ""}</th>`).join("")}</tr></thead><tbody>${
      vis.map((r, i) => `<tr class="click" data-sym="${esc(r.sym)}"><td class="muted">${i + 1}</td><td class="amber">${esc(r.sym)}</td>
        <td class="nm" title="${esc(r.title)}">${esc(r.name || r.title)}</td><td class="muted">${esc(r.sector || "")}</td><td class="tags">${sigHTML(r.tags)}</td>
        <td>${big(r.last)}</td><td>${zBadge(r.z)}</td><td>${zBadge(r.z7ago)}</td><td>${zBadge(r.zmax7)}</td>
        <td class="${r.ratio > 1.3 ? "up" : r.ratio < 0.75 ? "down" : ""}">${fmt(r.ratio, 2)}x</td><td class="${r.spikes30 ? "amber" : "muted"}">${r.spikes30 ?? "--"}</td>
        <td>${fmt(r.px)}</td><td class="${cls(r.r1)}">${pct(r.r1)}</td><td class="${cls(r.r5)}">${pct(r.r5)}</td><td class="${cls(r.r21)}">${pct(r.r21)}</td>
        <td class="${r.volx >= 2 ? "amber" : ""}">${isNum(r.volx) ? fmt(r.volx, 1) + "x" : "--"}</td>
        <td class="spk" style="width:130px">${spark(r.spark, 120, 22)}</td>
        <td>${wlNow.has(r.sym) ? `<span class="muted small">in WL</span>` : `<button class="btn sm" data-wl="${esc(r.sym)}" title="Add to the Terminal watchlist">+WL</button>`}</td></tr>`).join("")}
      </tbody></table>${all.length - ok.length ? `<div class="note">${all.length - ok.length} ticker(s) without data - see the ERRORS filter.</div>` : ""}`;
    $$("#scan-res th[data-k]").forEach((th) => (th.onclick = () => {
      const k = th.dataset.k; sort.d = sort.k === k ? -sort.d : (["sym", "name", "sector"].includes(k) ? 1 : -1); sort.k = k;
      SS.scanSort = sort; saveS(); draw(true); }));
    $$("#scan-res [data-wl]").forEach((b) => (b.onclick = (e) => { e.stopPropagation();
      const w = store("mt.watchlist") || []; if (!w.includes(b.dataset.wl)) store("mt.watchlist", [...w, b.dataset.wl]); draw(true); }));
    $$("#scan-res tr[data-sym]").forEach((tr) => (tr.onclick = () => go("dive", tr.dataset.sym)));
    /* charts: redraw every few rows while scanning, always when forced */
    if (force || ++chartTick % 6 === 0) drawCharts(ok);
  }
  function drawCharts(ok) {
    const pts = ok.filter((r) => isNum(r.r5));
    const col = (z) => (z >= 2.5 ? "#ff5252" : z >= 1.5 ? "#ffa028" : z <= -1.5 ? "#5cb3ff" : "#8b8b92");
    mkChart("sc-cv", {
      type: "scatter",
      data: { datasets: [{ data: pts.map((r) => ({ x: r.r5, y: r.z, s: r.sym })), pointRadius: 4, pointHoverRadius: 6,
        backgroundColor: pts.map((r) => col(r.z)), borderWidth: 0 }] },
      options: { responsive: true, maintainAspectRatio: false, animation: false,
        onClick: (e, el) => { if (el.length) go("dive", pts[el[0].index].sym); },
        plugins: { legend: { display: false }, tooltip: { ...TIP, callbacks: { label: (c) => ` ${c.raw.s}: z ${fmt(c.raw.y, 2)}, 5D ${pct(c.raw.x)}` } } },
        scales: { x: { title: { display: true, text: "5-day price move %" }, ticks: { callback: (v) => v + "%" } },
          y: { title: { display: true, text: "Attention z (σ)" } } } },
      plugins: [{ id: "lbl", afterDatasetsDraw(ch) {
        const c = ch.ctx; c.save(); c.font = "10px Cascadia Mono, Consolas, monospace"; c.fillStyle = "#cfcfcf";
        ch.getDatasetMeta(0).data.forEach((p, i) => { const r = pts[i]; if (r && (Math.abs(r.z) >= 1.5 || Math.abs(r.r5) >= 7)) c.fillText(r.sym, p.x + 5, p.y - 4); });
        c.restore(); } }],
    });
    const sec = {};
    ok.forEach((r) => { const k = r.sector || "Other"; (sec[k] = sec[k] || []).push(r.z); });
    const rowsS = Object.entries(sec).map(([k, v]) => [k, v.reduce((a, b) => a + b, 0) / v.length, v.length]).sort((a, b) => b[1] - a[1]);
    bars("sec-cv", rowsS.map((r) => `${r[0]} (${r[2]})`), [{ label: "Avg z", data: rowsS.map((r) => r[1]),
      backgroundColor: rowsS.map((r) => col(r[1])) }], { horizontal: true, legend: false, fmt: (v) => fmt(v, 2), yfmt: (v) => fmt(v, 1) });
  }

  if (!syms.length) { $("#scan-prog").innerHTML = "Add some tickers, then press SCAN."; return; }
  /* prices: one batched request alongside the attention rows */
  soft(api(`/api/sig/scanpx?symbols=${enc(syms.join(","))}`)).then((p) => { if (g !== gen || p.error) return; Object.assign(px, p); draw(true); });
  /* attention rows: 3 workers; rate-limited symbols go back in the queue after the cooldown */
  let queue = syms.slice(), attempts = 0;
  const okCount = () => Object.values(rows).filter((r) => isNum(r.z)).length;
  while (queue.length && g === gen && !stopped && attempts < 8) {
    const retry = []; let wait = 0, i = 0;
    const worker = async () => {
      while (i < queue.length && g === gen && !stopped) {
        const s = queue[i++];
        $("#scan-prog").innerHTML = `Loading <b>${esc(s)}</b> &middot; ${okCount()}/${syms.length} done`;
        const r = await soft(api(`/api/sig/scan1?symbol=${enc(s)}`));
        if (r.retry) { retry.push(s); wait = Math.max(wait, r.retry); rows[s] = { sym: s, error: "rate-limited - queued for retry" }; }
        else rows[s] = r.error && !r.sym ? { sym: s, error: r.error } : r;
        draw();
      }
    };
    await Promise.all([worker(), worker(), worker()]);
    queue = retry; attempts++;
    for (let n = wait; queue.length && n > 0 && g === gen && !stopped; n--) {
      $("#scan-prog").innerHTML = `Wikimedia rate limit reached - resuming ${queue.length} remaining in <b>${n}s</b> (cached rows load instantly next time)`;
      await new Promise((res) => setTimeout(res, 1000));
    }
  }
  if (g !== gen) return;
  draw(true);
  if (!stopped) $("#scan-prog").innerHTML = `Scanned ${okCount()} of ${syms.length}. Click a row for the deep dive, a column header to sort.`;
}

/* ================================================================== ABOUT */
async function about(g) {
  const s = await soft(api("/api/sig/settings"));
  if (g !== gen) return;
  PAGE.innerHTML = `<div class="grid">
    ${panel("What Signal Monitor does", `<div class="desc">
      <p>Prices tell you <i>what</i> happened. Open data can tell you <i>who is paying attention, and how they feel</i>, often before or alongside a move.</p>
      <ul class="insights">
        <li><b>Wikipedia pageviews</b>: a clean, public, daily measure of retail and global attention. Spikes cluster around earnings, scandals, launches and squeezes.</li>
        <li><b>Wikipedia edit activity</b>: bursts of edits usually mean something factual just changed (CEO exit, acquisition, lawsuit).</li>
        <li><b>Headline sentiment</b>: Google News headlines over 30 days, scored with a finance-specific word list.</li>
        <li><b>Hacker News</b>: tech-community attention, a leading indicator for software, AI and semiconductor names.</li>
        <li><b>GDELT</b>: worldwide news volume and tone across 65 languages (rate-limited; load on demand).</li>
        <li><b>Lead/lag</b> and <b>spike studies</b> test, per stock, whether attention historically preceded volatility or returns.</li>
      </ul>
      <p class="muted">These are research signals with small samples. Correlation is not causation, and none of this is investment advice.</p></div>`, { cls: "c7" })}
    ${panel("Settings", `<div class="form">
      <label>Contact for Wikimedia API (optional): email or URL
        <input id="contact" value="${esc(s.contact || "")}" placeholder="you@example.com or https://your-site" spellcheck="false"></label>
      <div class="note" style="padding:0">Wikimedia's API policy asks apps to identify themselves with a contact. Anonymous clients are limited to roughly 10 quick requests,
      which makes the Attention Scanner slow. If you add a contact it is stored only on this PC and sent only to Wikimedia, in the User-Agent header of its API requests.</div>
      <button class="btn primary" id="contact-save">SAVE</button>
      <div class="note" style="padding:0">Current Wikimedia cooldown: <b>${fmt(s.cooldown || 0, 0)}s</b></div></div>`, { cls: "c5" })}
  </div>`;
  $("#contact-save").onclick = async () => { await soft(api(`/api/sig/settings?contact=${enc($("#contact").value)}`)); render(); };
}

render();

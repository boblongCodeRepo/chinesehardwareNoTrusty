/* Influence Watch - narratives across US government, US & international media and foreign state media,
   plus documented money (FARA foreign agents, LDA lobbying, FEC contributions). */
"use strict";
const PAGE = $("#page");
const IW = Object.assign({
  tab: "wire", grp: "all", hours: 24, q: "", stHours: 48, stFilter: "all", frDays: 30, frOrigin: "all",
  ecDays: 14, cc: "RU", pfDays: 7, person: "Elon Musk", fcountry: "RUSSIA", fterm: false,
  cgDays: 90, cgSide: "all", cgParty: "all", cgKind: "stocks", cgQ: "", inDays: 7, inQ: "", conQ: "",
}, store("iw.state") || {});
const save = () => store("iw.state", IW);
if (!store("iw.v2")) { IW.tab = "today"; IW.grp = "all"; store("iw.v2", 1); } // new opening screen
const TABS = ["today", "wire", "stories", "framing", "echoes", "lens", "people", "money", "congress", "insiders", "contracts", "gov", "about"];
{ // deep links: /watch/#people/Elon%20Musk, /watch/#lens/CN, /watch/#money/CHINA, /watch/#contracts/Palantir, /watch/#congress/NVDA
  const [t, a] = location.hash.replace(/^#\/?/, "").split("/");
  if (TABS.includes(t)) IW.tab = t;
  if (a) {
    const v = decodeURIComponent(a);
    if (t === "people") IW.person = v;
    if (t === "lens") IW.cc = v.toUpperCase();
    if (t === "money") IW.fcountry = v.toUpperCase();
    if (t === "contracts") IW.conQ = v;
    if (t === "insiders") IW.inQ = v;
    if (t === "congress") IW.cgQ = v;
  }
}
let gen = 0;

function go(tab, arg) {
  IW.tab = tab;
  if (arg !== undefined) {
    if (tab === "people") IW.person = arg;
    if (tab === "lens") IW.cc = arg;
    if (tab === "money") IW.fcountry = arg;
    if (tab === "contracts") IW.conQ = arg;
    if (tab === "insiders") IW.inQ = arg;
    if (tab === "congress") IW.cgQ = arg;
  }
  save();
  render();
}
$("#tabs").onclick = (e) => { const b = e.target.closest("button[data-tab]"); if (b) go(b.dataset.tab); };
const cmd = $("#cmd");
const submit = () => { const v = cmd.value.trim(); cmd.value = ""; if (v) go("people", v); };
cmd.onkeydown = (e) => { if (e.key === "Enter") submit(); };
$(".cmd-go").onclick = submit;
$("#iw-refresh").onclick = async () => {
  setStatus("busy", "Fetching all feeds...");
  await soft(api("/api/iw/refresh"));
  setTimeout(() => { setStatus("ok", "Feeds refreshed"); render(); }, 25000);
};

function render() {
  gen++;
  $$("#tabs button[data-tab]").forEach((b) => b.classList.toggle("active", b.dataset.tab === IW.tab));
  history.replaceState(null, "", "#" + IW.tab);
  return ({ today, wire, stories, framing, echoes, lens, people, money: moneyTab, congress, insiders, contracts, gov, about }[IW.tab] || today)(gen);
}

/* Quiet in-place refresh for background updates: no "Loading..." screen, keeps the page and panel scroll positions,
   and carries over panels the user opened (company lookup, ticker detail) instead of rebuilding them. */
let SOFT = false;
const KEEP = ["in-res", "c-detail", "k-res"];
async function softRefresh() {
  const busyUser = document.activeElement && /INPUT|SELECT|TEXTAREA/.test(document.activeElement.tagName);
  if (busyUser || String(window.getSelection() || "").length) return false;  // typing or selecting: try next time
  const y = window.scrollY;
  const inner = $$(".pb.scroll").map((el) => el.scrollTop);
  const kept = KEEP.map((id) => document.getElementById(id)).filter(Boolean);
  SOFT = true;
  try { await render(); } finally { SOFT = false; }
  kept.forEach((old) => { const now = document.getElementById(old.id); if (now) now.replaceWith(old); });
  $$(".pb.scroll").forEach((el, i) => { if (inner[i] !== undefined) el.scrollTop = inner[i]; });
  window.scrollTo(0, y);
  return true;
}

/* ------------------------------------------------------------------ shared bits */
const GORDER = ["usgov", "us", "intl", "public", "state:RU", "state:CN", "state:IR", "state:VE", "research"];
const GCOL = { usgov: "#5cb3ff", us: "#d4d4d8", intl: "#34d27b", public: "#2dd4bf", research: "#c084fc",
  "state:RU": "#ff5252", "state:CN": "#ffd84a", "state:IR": "#fb923c", "state:VE": "#f472b6" };
const GLAB = { usgov: "US Government", us: "US Media", intl: "World Media", public: "Public Broadcasters",
  research: "Researchers", "state:RU": "Russian State Media", "state:CN": "Chinese State Media", "state:IR": "Iranian State Media", "state:VE": "Venezuelan State Media" };
const GSHORT = { usgov: "US GOVT", us: "US MEDIA", intl: "WORLD MEDIA", public: "PUBLIC TV", research: "RESEARCHERS",
  "state:RU": "RUSSIA", "state:CN": "CHINA", "state:IR": "IRAN", "state:VE": "VENEZUELA" };
const intro = (text) => `<div class="c12 intro">${text}</div>`;
const CCN = { RU: "Russia", CN: "China", IR: "Iran", VE: "Venezuela" };
const gk = (it) => (it.grp === "state" ? "state:" + it.cc : it.grp);
const srcTag = (it) => `<span class="stag" style="--c:${GCOL[gk(it)] || "#888"}" title="${esc(GLAB[gk(it)] || it.grp)}">${esc(it.name)}</span>`;
const ccTag = (cc) => `<span class="stag" style="--c:${GCOL["state:" + cc]}">${esc(CCN[cc] || cc)}</span>`;
const link = (url, text) => `<a href="${esc(url)}" target="_blank" rel="noopener">${esc(text)}</a>`;
const dstr = (ts) => (ts ? new Date(ts * 1000).toLocaleString("en-US", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }) : "");
function itemLi(it, o = {}) {
  return `<li><span class="tm" title="${esc(dstr(it.ts))}">${ago(it.ts)}</span>${srcTag(it)}<span class="tx">${link(it.url, it.title)}${o.summ && it.summary ? `<small>${esc(it.summary)}</small>` : ""}</span></li>`;
}
const itemList = (items, o = {}) => (items && items.length ? `<ul class="news iw">${items.map((x) => itemLi(x, o)).join("")}</ul>` : `<div class="note">Nothing yet. The archive grows every 15 minutes while the app is open.</div>`);
function covBar(by) {
  const keys = GORDER.filter((k) => by[k]);
  const tot = keys.reduce((a, k) => a + by[k], 0) || 1;
  return `<div class="cov">${keys.map((k) => `<i style="width:${(100 * by[k]) / tot}%;background:${GCOL[k]}" title="${GLAB[k]}: ${by[k]} outlet(s)"></i>`).join("")}</div>`;
}
const legend = (keys = GORDER) => `<div class="chips iwleg">${keys.map((k) => `<span class="chip"><i style="background:${GCOL[k]}"></i>${GLAB[k]}&nbsp;</span>`).join("")}</div>`;
let lastArch = null;
function archNote(a) { if (a) lastArch = a; return ""; } // status details live on TODAY / HOW IT WORKS only
function archText(a) {
  a = a || lastArch;
  if (!a) return "";
  if (a.busy || !a.feeds_ok) return `Archive ${fmt(a.items, 0)} headlines &middot; <span class='amber'>updating feeds now...</span>`;
  const since = a.since ? new Date(a.since * 1000).toLocaleDateString("en-US", { month: "short", day: "numeric" }) : "--";
  return `Archive ${fmt(a.items, 0)} items since ${since} &middot; feeds OK ${a.feeds_ok}/${a.feeds}${a.last ? ` &middot; refreshed ${ago(a.last)} ago` : ""}${a.busy ? " &middot; <span class='amber'>refreshing...</span>" : ""}`;
}
function flagBadges(flags) {
  const L = { "state-first": ["STATE MEDIA FIRST", "f-red"], "state-heavy": ["PUSHED BY STATE MEDIA", "f-amber"], "state-only": ["ONLY STATE MEDIA", "f-purple"], "no-state": ["STATE MEDIA IGNORING", "f-dim"] };
  return (flags || []).map((f) => `<span class="flag ${L[f][1]}">${L[f][0]}</span>`).join(" ");
}
function loading(msg) { if (!SOFT) PAGE.innerHTML = `<div class="loading">${msg}</div>`; }
function fail(g, e) { if (g === gen) { if (!SOFT) PAGE.innerHTML = errBox(e); setStatus("err", "Error"); } }
const timeLabels = (labels, step) => labels.map((t) => new Date(t * 1000).toLocaleString("en-US", step >= 86400 ? { month: "short", day: "numeric" } : { weekday: "short", hour: "numeric" }));
function stackedChart(id, chart, keys) {
  const ks = (keys || GORDER).filter((k) => chart.series[k]);
  bars(id, timeLabels(chart.labels, chart.step), ks.map((k) => ({ label: GLAB[k], data: chart.series[k], backgroundColor: GCOL[k] })), { stacked: true, legend: false, fmt: (v) => fmt(v, 0) });
}

/* ================================================================== TODAY (briefing) */
const sumState = (by) => Object.entries(by).filter(([k]) => k.startsWith("state:")).reduce((a, [, v]) => a + v, 0);
const plural = (n, w) => `${n} ${w}${n === 1 ? "" : "s"}`;
function storyLine(s) {
  const us = (s.by.us || 0) + (s.by.usgov || 0), stc = sumState(s.by);
  return `<li><span class="tx">${link(s.url, s.label)}<small>${plural(stc, "state outlet")} &middot; ${plural(us, "US outlet")} &middot; ${s.outlets} in total</small></span></li>`;
}
const ul = (rows, empty) => (rows.length ? `<ul class="news iw brief">${rows.join("")}</ul>` : `<div class="note">${empty}</div>`);
const more = (tab, label) => `<button class="btn sm more" data-go="${tab}">${label} &rarr;</button>`;
const titleCase = (s) => String(s || "").toLowerCase().replace(/\b[a-z]/g, (c) => c.toUpperCase());

async function today(g) {
  loading("Putting together today's briefing (the very first run takes about 30 seconds)...");
  setStatus("busy", "Building briefing...");
  const [st, fr, pf, fa, gv, mh] = await Promise.all([soft(api("/api/iw/stories?hours=48")), soft(api("/api/iw/framing?days=30")),
    soft(api("/api/iw/profile?days=7")), soft(api("/api/iw/fara_summary")), soft(api("/api/iw/gov")), soft(api("/api/iw/money_highlights"))]);
  if (g !== gen) return;
  if (st.error && pf.error) return fail(g, st.error);
  const S = st.stories || [];
  const cards = Object.entries(CCN).map(([cc, name]) => {
    const push = S.filter((s) => s.state_cc.includes(cc) && (s.flags.includes("state-only") || s.flags.includes("state-heavy"))).slice(0, 3);
    const p = (pf.countries || {})[cc] || { terms: [], docs: 0 };
    const own = { RU: /\brussian?s?\b/, CN: /\b(china|chinese)\b/, IR: /\biran(ian)?s?\b/, VE: /\bvenezuelan?s?\b/ }[cc];
    const topics = p.terms.map((t) => t.term).filter((t) => !own.test(t)).slice(0, 7);
    return panel(`<span style="color:${GCOL["state:" + cc]}">${esc(name)}'s state media</span>`,
      `<div class="note"><b>Talking about most this week:</b> ${topics.length ? topics.map(esc).join(", ") : "not enough items yet"}</div>
       <div class="sub-h">Stories they're pushing hardest</div>${ul(push.map(storyLine), "Nothing stands out right now.")}
       <div class="btnrow">${more("lens:" + cc, `${name} profile`)}</div>`, { cls: "c3", src: `${fmt(p.docs, 0)} items this week` });
  }).join("");
  const quiet = S.filter((s) => s.flags.includes("no-state")).slice(0, 5);
  const first = S.filter((s) => s.flags.includes("state-first")).slice(0, 5);
  const words = (fr.terms || []).filter((t) => t.other > 0).sort((a, b) => b.other - a.other).slice(0, 5);
  const recent = (fa.recent || []).slice(0, 6);
  const acts = (gv.enforcement || []).slice(0, 6);
  PAGE.innerHTML = `<div class="grid">
    ${intro(`<b>Your briefing.</b> This app reads ~65 news sources, from the US government and US media to the state-run media of Russia, China, Iran and Venezuela, and shows <b>what each side is pushing</b>, <b>whose wording spreads</b>, and <b>who is officially paid</b> by foreign governments. Coloured tags show who published something: ${["state:RU", "state:CN", "state:IR", "state:VE"].map((k) => `<span class="stag" style="--c:${GCOL[k]}">${GSHORT[k]}</span>`).join("")} are foreign state media. <span class="muted">${archText(st.archive || pf.archive)}</span>`)}
    ${cards}
    ${panel("Big stories state media are staying quiet about", `${ul(quiet.map(storyLine), "None right now.")}<div class="btnrow">${more("stories:no-state", "All stories")}</div>`, { cls: "c6", src: "8+ outlets, no state media" })}
    ${panel("Stories state media reported first", `${ul(first.map(storyLine), "None right now.")}<div class="note small">Often they were simply faster. It matters when their <i>framing</i> sticks.</div><div class="btnrow">${more("stories:state-first", "All stories")}</div>`, { cls: "c6" })}
    ${panel("Their wording, showing up in other outlets", `${ul(words.map((t) => `<li><span class="tx"><b class="term">&ldquo;${esc(t.term)}&rdquo;</b> <span class="muted">(typical of ${esc(CCN[t.origin] || "custom list")})</span><small>Other outlets used it ${plural(t.other, "time")}: ${t.outlets.slice(0, 4).map(([n, c]) => `${esc(n)} ${c}`).join(", ")}. State media used it ${plural(t.state, "time")}.</small></span></li>`), "No state-media catchphrases spotted in other outlets in the last 30 days.")}
       <div class="note small">Usually these are quotes. Click through to check.</div><div class="btnrow">${more("framing", "All loaded words")}</div>`, { cls: "c4" })}
    ${panel("Follow the money: newest foreign-agent registrations", `${ul(recent.map((r) => `<li><span class="tx"><b>${esc(r.principal)}</b> <span class="muted">(${esc(titleCase(r.country))})</span><small>hired ${esc(r.registrant)} &middot; registered ${esc(r.fp_date)}${r.docs[0] ? ` &middot; <a href="${esc(r.docs[0].url)}" target="_blank" rel="noopener">filing</a>` : ""}</small></span></li>`), fa.error ? esc(fa.error) : "None in the last 6 months.")}
       <div class="btnrow">${more("money", "Follow the money")}</div>`, { cls: "c4", src: "US Justice Dept (FARA)" })}
    ${panel("US government actions on foreign influence", `${ul(acts.map((x) => `<li><span class="tm">${ago(x.ts)}</span><span class="tx">${link(x.url, x.title)}<small>${esc(x.name)}</small></span></li>`), "Nothing in the last 30 days.")}
       <div class="btnrow">${more("gov", "All government actions")}</div>`, { cls: "c4" })}
    ${moneyMoves(mh)}
  </div>`;
  $$("button[data-go]").forEach((b) => (b.onclick = () => {
    const [t, a] = b.dataset.go.split(":");
    if (t === "stories" && a) IW.stFilter = a;
    if (t === "lens" && a) IW.cc = a;
    go(t);
  }));
  setStatus("ok", "Briefing ready");
}

function moneyMoves(mh) {
  if (!mh || mh.error) return "";
  const c = mh.congress || {}, i = mh.insiders || {}, k = mh.contracts || {};
  const cg = c.error ? esc(c.error) : !c.trades || !c.trades.length ? (c.busy ? "Reading the latest House reports... check back in a minute." : "No stock trades reported in the last 30 days.")
    : ul(c.trades.map((t) => `<li><span class="tx"><b>${esc(t.member)}</b> ${partyTag(t.party, t.sd)} ${txTag(t.tx)} <b>${esc(t.ticker)}</b> ${range(t.lo, t.hi)}<small>${esc(companyName(t.asset))} &middot; traded ${esc(t.tdate)}, reported ${esc(t.filed)}${t.late ? ` &middot; <span class="amber">${t.late} days late</span>` : ""}</small></span></li>`), "");
  const ins = i.error ? esc(i.error) : !i.contact ? `<div class="note">${ADD_EMAIL}</div>`
    : ul(i.buys.map((t) => `<li><span class="tx"><b>${esc(titleCase(t.owner))}</b> bought <b class="up">${money(t.value)}</b> of ${t.ticker ? `<b>${esc(t.ticker)}</b>` : esc(titleCase(t.issuer))}<small>${esc(t.rel)}${isNum(t.pct) ? ` &middot; stake +${fmt(t.pct, t.pct < 10 ? 1 : 0)}%` : ""} &middot; ${esc(t.last)}</small></span></li>`), "No insider buys read yet this week.");
  const con = k.loading ? `<div class="note">Loading from USAspending.gov...</div>`
    : ul((k.new || []).map((a) => `<li><span class="tx">${a.url ? link(a.url, titleCase(a.recipient)) : esc(titleCase(a.recipient))} <b>${money(a.amount)}</b><small>${esc(a.agency)} &middot; ${esc((a.descr || "").slice(0, 110))}</small></span></li>`), "None.");
  return `${panel("Congress: biggest stock trades reported (30 days)", `${cg}<div class="btnrow">${more("congress", "All Congress trades")}</div>`, { cls: "c4", src: "House STOCK Act reports" })}
    ${panel("Company insiders buying their own stock (7 days)", `${ins}<div class="btnrow">${more("insiders", "All insider trades")}</div>`, { cls: "c4", src: "SEC Form 4" })}
    ${panel("Biggest new federal contracts (30 days)", `${con}<div class="btnrow">${more("contracts", "Government contracts")}</div>`, { cls: "c4", src: "USAspending.gov" })}`;
}

/* ================================================================== WIRE */
async function wire(g) {
  loading("Collecting ~65 feeds (first run takes about 30 seconds)...");
  setStatus("busy", "Loading wire...");
  let d;
  try { d = await api(`/api/iw/wire?hours=${IW.hours}&grp=${enc(IW.grp)}&q=${enc(IW.q)}`); } catch (e) { return fail(g, e); }
  if (g !== gen) return;
  const c = d.counts24 || {};
  const tot24 = Object.values(c).reduce((a, b) => a + b, 0) || 1;
  const st24 = Object.entries(c).filter(([k]) => k.startsWith("state:")).reduce((a, [, v]) => a + v, 0);
  archNote(d.archive);
  const grpSeg = segHTML("w-grp", [["all", "EVERYONE"], ...GORDER.map((k) => [k, GSHORT[k]])], IW.grp);
  PAGE.innerHTML = `<div class="grid">
    ${intro(`<b>Every headline from every source, newest first.</b> The coloured tag shows who published it. Use the buttons to show just one kind of source, for example only Russian state media.`)}
    ${panel("Show", `<div class="iwbar">${grpSeg}
        ${segHTML("w-hrs", [[6, "6 HOURS"], [24, "1 DAY"], [48, "2 DAYS"], [168, "1 WEEK"]], IW.hours)}
        <input id="w-q" class="inp wide" placeholder="search for a word..." value="${esc(IW.q)}"><button class="btn sm" id="w-go">SEARCH</button></div>`, { cls: "c12", flush: false })}
    <div class="c12 kpis">
      <div class="kpi"><span>Headlines shown</span><b>${fmt(d.total, 0)}</b><small>matching your filter</small></div>
      <div class="kpi"><span>From foreign state media</span><b>${fmt((100 * st24) / tot24, 0)}%</b><small>of the last day's ${fmt(tot24, 0)} headlines</small></div>
      ${["state:RU", "state:CN", "state:IR", "state:VE"].map((k) => `<div class="kpi"><span style="color:${GCOL[k]}">${GLAB[k]}</span><b>${fmt(c[k] || 0, 0)}</b><small>headlines in the last day</small></div>`).join("")}
    </div>
    ${panel("Headlines", itemList(d.items, { summ: true }), { cls: "c8", scroll: true, maxh: 1100, src: d.total > 500 ? "newest 500 shown" : "" })}
    <div class="c4 stack">
      ${panel("Headlines per hour, by source", `<div class="chart-box tall"><canvas id="w-ch"></canvas></div>${legend()}`, { flush: false })}
      ${panel("Headlines in the last day, by source", `<table class="t"><tbody>${GORDER.map((k) => `<tr class="click" data-g="${k}"><td><i class="sw" style="background:${GCOL[k]}"></i>${GLAB[k]}</td><td>${fmt(c[k] || 0, 0)}</td><td class="muted">${fmt((100 * (c[k] || 0)) / tot24, 1)}%</td></tr>`).join("")}</tbody></table><div class="note small">Click a row to show only that source. "Public broadcasters" (BBC, DW, France 24, Al Jazeera, RFE/RL) are government-funded but editorially independent.</div>`)}
    </div></div>`;
  stackedChart("w-ch", d.chart);
  bindSeg("w-grp", (v) => { IW.grp = v; save(); render(); });
  bindSeg("w-hrs", (v) => { IW.hours = +v; save(); render(); });
  const q = () => { IW.q = $("#w-q").value.trim(); save(); render(); };
  $("#w-go").onclick = q;
  $("#w-q").onkeydown = (e) => { if (e.key === "Enter") q(); };
  $$("tr[data-g]").forEach((r) => (r.onclick = () => { IW.grp = r.dataset.g; save(); render(); }));
  setStatus("ok", `${fmt(d.total, 0)} items`);
}

/* ================================================================== STORIES */
async function stories(g) {
  loading("Clustering stories across all outlets...");
  setStatus("busy", "Clustering...");
  let d;
  try { d = await api(`/api/iw/stories?hours=${IW.stHours}`); } catch (e) { return fail(g, e); }
  if (g !== gen) return;
  const F = { all: () => true, "state-first": (s) => s.flags.includes("state-first"), "state-heavy": (s) => s.flags.includes("state-heavy"),
    "state-only": (s) => s.flags.includes("state-only"), "no-state": (s) => s.flags.includes("no-state"),
    RU: (s) => s.state_cc.includes("RU"), CN: (s) => s.state_cc.includes("CN"), IR: (s) => s.state_cc.includes("IR"), VE: (s) => s.state_cc.includes("VE") };
  const list = d.stories.filter(F[IW.stFilter] || F.all);
  const cnt = (f) => d.stories.filter(F[f]).length;
  const rows = list.map((s, i) => `<tr class="click" data-i="${i}">
      <td>${s.outlets}</td><td class="covc">${covBar(s.by)}</td>
      <td class="nm wrap">${link(s.url, s.label)}<div class="terms">${s.terms.map(esc).join(" &middot; ")}</div></td>
      <td class="nm">${srcTag(s.first)} <span class="muted">${ago(s.first.ts)}</span></td>
      <td class="nm wrap">${flagBadges(s.flags)}</td></tr>
      <tr class="det hidden" id="sd-${i}"><td colspan="5">${itemList(s.items.slice().reverse())}</td></tr>`).join("");
  archNote(d.archive);
  const HELP = { all: "All stories, biggest first.", "state-first": "Stories where foreign state media published before anyone else. Often they were just faster; it matters when their framing sticks.",
    "state-heavy": "Stories mostly carried by state media, though US outlets covered them too. These are topics state media are pushing hard.",
    "state-only": "Stories carried by 2+ state outlets that no US outlet is covering. This is their agenda: what they want people talking about.",
    "no-state": "Big stories (8+ outlets) that state media aren't touching. Often stories that are awkward for them." };
  PAGE.innerHTML = `<div class="grid">
    ${intro(`<b>The same news, grouped into stories, so you can see who is covering what.</b> The coloured bar shows the mix of outlets on each story (${["us", "state:RU", "state:CN"].map((k) => `<span class="stag" style="--c:${GCOL[k]}">${GSHORT[k]}</span>`).join("")}...). Click any story to see every headline in it.`)}
    ${panel("Stories", `<div class="iwbar">
        ${segHTML("s-f", [["all", `ALL (${d.stories.length})`], ["state-only", `ONLY STATE MEDIA COVER (${cnt("state-only")})`], ["state-heavy", `PUSHED BY STATE MEDIA (${cnt("state-heavy")})`], ["state-first", `STATE MEDIA WAS FIRST (${cnt("state-first")})`], ["no-state", `STATE MEDIA IGNORING (${cnt("no-state")})`]], IW.stFilter)}
        <span class="muted small">involving:</span>${segHTML("s-cc", [["RU", "RUSSIA"], ["CN", "CHINA"], ["IR", "IRAN"], ["VE", "VENEZUELA"]], IW.stFilter)}
        <span class="muted small">from the last:</span>${segHTML("s-h", [[24, "DAY"], [48, "2 DAYS"], [168, "WEEK"]], IW.stHours)}</div>
      ${HELP[IW.stFilter] ? `<div class="note" style="padding:2px 0 8px">${HELP[IW.stFilter]}</div>` : ""}
      <table class="t stories"><thead><tr><th>Outlets</th><th>Who's covering it</th><th>Story</th><th>First published by</th><th></th></tr></thead><tbody>${rows || `<tr><td colspan="5" class="muted">No stories match.</td></tr>`}</tbody></table>`, { cls: "c12", flush: false })}
    </div>`;
  $$("tr[data-i]").forEach((r) => (r.onclick = (e) => { if (e.target.closest("a")) return; $("#sd-" + r.dataset.i).classList.toggle("hidden"); }));
  bindSeg("s-f", (v) => { IW.stFilter = v; save(); render(); });
  bindSeg("s-cc", (v) => { IW.stFilter = v; save(); render(); });
  bindSeg("s-h", (v) => { IW.stHours = +v; save(); render(); });
  setStatus("ok", `${list.length} stories`);
}

/* ================================================================== FRAMING */
async function framing(g) {
  loading("Scanning for framing terms...");
  setStatus("busy", "Scanning...");
  const custom = store("iw.terms") || [];
  let d;
  try { d = await api(`/api/iw/framing?days=${IW.frDays}&extra=${enc(custom.join("|"))}`); } catch (e) { return fail(g, e); }
  if (g !== gen) return;
  const list = d.terms.filter((t) => IW.frOrigin === "all" || t.origin === IW.frOrigin)
    .sort((a, b) => (b.other + b.state) - (a.other + a.state));
  const oTag = (o) => (o === "custom" ? `<span class="stag" style="--c:#a3a3a3">CUSTOM</span>` : ccTag(o));
  const rows = list.map((t, i) => `<tr class="click" data-i="${i}">
      <td class="nm"><b class="term">${esc(t.term)}</b></td><td class="nm">${oTag(t.origin)}</td>
      <td>${t.state ? `<b style="color:${GCOL["state:" + (t.origin in CCN ? t.origin : "RU")]}">${t.state}</b>` : "0"}</td>
      <td>${t.other ? `<b class="amber">${t.other}</b>` : "0"}</td><td>${t.gov || 0}</td>
      <td class="nm wrap small">${t.outlets.map(([n, c]) => `${esc(n)} <span class="muted">${c}</span>`).join(", ") || "<span class='muted'>none</span>"}</td>
      <td class="spk">${spark(t.daily, 90, 18)}</td></tr>
      <tr class="det hidden" id="fd-${i}"><td colspan="7"><div class="grid2">
        <div><div class="sub-h">Used by other outlets</div>${itemList(t.examples)}</div>
        <div><div class="sub-h">State media uses (${t.state_outlets.map(([n, c]) => `${esc(n)} ${c}`).join(", ") || "none"})</div>${itemList(t.state_examples)}</div></div></td></tr>`).join("");
  archNote(d.archive);
  PAGE.innerHTML = `<div class="grid">
    ${intro(`<b>Every government has catchphrases.</b> Russia says "Kiev regime" and "collective West", China says "Cold War mentality", and Iran says "Zionist regime". This counts how often state media use them, and whether <b>other outlets</b> have started using them too. Most uses elsewhere are quotes, so click a row and read the headlines. You can add any phrase to track, including US political slogans.`)}
    ${panel("Loaded words", `<div class="iwbar">
        ${segHTML("f-o", [["all", "ALL"], ["RU", "RUSSIA'S"], ["CN", "CHINA'S"], ["IR", "IRAN'S"], ["VE", "VENEZUELA'S"], ["custom", "MY PHRASES"]], IW.frOrigin)}
        <span class="muted small">in the last:</span>${segHTML("f-d", [[7, "WEEK"], [30, "MONTH"], [90, "3 MONTHS"]], IW.frDays)}
        <input id="f-add" class="inp wide" placeholder="track a phrase..."><button class="btn sm" id="f-addb">+ ADD</button>
        ${custom.length ? `<span class="chips">${custom.map((t) => `<span class="chip">${esc(t)} <button class="x" data-t="${esc(t)}">&times;</button></span>`).join("")}</span>` : ""}</div>
      <table class="t"><thead><tr><th>Phrase</th><th>Typical of</th><th>Times in state media</th><th>Times in other media</th><th>In US gov releases</th><th>Which other outlets</th><th>Trend</th></tr></thead><tbody>${rows}</tbody></table>`, { cls: "c12", flush: false })}</div>`;
  $$("tr[data-i]").forEach((r) => (r.onclick = (e) => { if (e.target.closest("a")) return; $("#fd-" + r.dataset.i).classList.toggle("hidden"); }));
  bindSeg("f-o", (v) => { IW.frOrigin = v; save(); render(); });
  bindSeg("f-d", (v) => { IW.frDays = +v; save(); render(); });
  const add = () => { const v = $("#f-add").value.trim(); if (v && !custom.includes(v)) { store("iw.terms", [...custom, v].slice(-30)); IW.frOrigin = "custom"; save(); render(); } };
  $("#f-addb").onclick = add;
  $("#f-add").onkeydown = (e) => { if (e.key === "Enter") add(); };
  $$("button.x[data-t]").forEach((b) => (b.onclick = () => { store("iw.terms", custom.filter((t) => t !== b.dataset.t)); render(); }));
  setStatus("ok", `${list.length} terms`);
}

/* ================================================================== ECHOES */
async function echoes(g) {
  loading("Tracing phrases from state media into other outlets...");
  setStatus("busy", "Tracing phrases...");
  let d;
  try { d = await api(`/api/iw/echoes?days=${IW.ecDays}`); } catch (e) { return fail(g, e); }
  if (g !== gen) return;
  const rows = d.echoes.map((e, i) => `<tr class="click" data-i="${i}">
      <td class="nm wrap"><span class="phrase">&ldquo;${esc(e.phrase)}&rdquo;</span></td>
      <td class="nm">${srcTag(e.origin)} <span class="muted">${dstr(e.origin.ts)}</span></td>
      <td class="nm wrap">${e.later.map((x) => `${srcTag(x)}<span class="lag">${x.lag_h < 1 ? "same hour" : fmt(x.lag_h, 0) + "h later"}</span>`).join(" ")}</td>
      <td class="muted small">details &#9662;</td></tr>
      <tr class="det hidden" id="ed-${i}"><td colspan="4"><div class="sub-h">First: state media</div>${itemList([e.origin])}<div class="sub-h">Later: other outlets</div>${itemList(e.later)}</td></tr>`).join("");
  archNote(d.archive);
  PAGE.innerHTML = `<div class="grid">
    ${intro(`<b>Phrases that appeared in foreign state media first, then turned up word for word in other outlets</b>, with how many hours later. This is <b>not proof of anything</b>: outlets often share the same news-wire text or quote the same official. Look for <b>patterns</b>, such as the same outlet repeatedly picking up state-media wording. Gets better as the app collects more history.`)}
    ${panel("Copied phrases", `<div class="iwbar"><span class="muted small">in the last:</span>
        ${segHTML("e-d", [[7, "WEEK"], [14, "2 WEEKS"], [30, "MONTH"], [60, "2 MONTHS"]], IW.ecDays)}</div>
      <table class="t"><thead><tr><th>Phrase</th><th>First said by</th><th>Then used by (hours later)</th><th></th></tr></thead><tbody>${rows || `<tr><td colspan="4" class="note">Nothing yet. This needs history: leave the app open and it will build up.</td></tr>`}</tbody></table>`, { cls: "c12", flush: false })}</div>`;
  $$("tr[data-i]").forEach((r) => (r.onclick = (e) => { if (e.target.closest("a")) return; $("#ed-" + r.dataset.i).classList.toggle("hidden"); }));
  bindSeg("e-d", (v) => { IW.ecDays = +v; save(); render(); });
  setStatus("ok", `${d.echoes.length} echoes`);
}

/* ================================================================== LENS (state-media profile) */
async function lens(g) {
  loading("Profiling state media vs US media...");
  setStatus("busy", "Profiling...");
  let d;
  try { d = await api(`/api/iw/profile?days=${IW.pfDays}`); } catch (e) { return fail(g, e); }
  if (g !== gen) return;
  const cc = IW.cc in CCN ? IW.cc : "RU";
  const p = d.countries[cc] || { docs: 0, terms: [], avoid: [], entities: [] };
  const col = GCOL["state:" + cc];
  archNote(d.archive);
  const times = (e) => (!(e.us_per100 > 0) ? "almost never in US news" : e.lift >= 1.5 ? `${fmt(e.lift, 0)}&times; more often`
    : e.lift > 0.67 ? "about the same as US media" : "less than US media");
  PAGE.innerHTML = `<div class="grid">
    ${intro(`<b>Pick a country to see what its state media talks about</b> compared with US media, which people and places it keeps mentioning, and what big US stories it leaves out. Click a name to look that person up.`)}
    ${panel("Country", `<div class="iwbar">${segHTML("l-cc", Object.entries(CCN).map(([k, v]) => [k, v.toUpperCase()]), cc)}
       <span class="muted small">over the last:</span>${segHTML("l-d", [[3, "3 DAYS"], [7, "WEEK"], [30, "MONTH"]], IW.pfDays)}
       <button class="btn sm" id="l-wire">READ ${esc(CCN[cc].toUpperCase())}'S STATE MEDIA HEADLINES &rarr;</button>
       <span class="muted small">${fmt(p.docs, 0)} of their headlines vs ${fmt(d.us_docs, 0)} US headlines</span></div>`, { cls: "c12", flush: false })}
    ${p.docs < 10 ? `<div class="c12">${errBox(`Only ${p.docs} ${CCN[cc]} state-media headlines in this window. Try a longer window, or let the app collect more.`)}</div>` : `
    ${panel(`Topics ${esc(CCN[cc])}'s state media talk about far more than US media`, `<div class="chart-box xtall"><canvas id="l-ch"></canvas></div>`, { cls: "c6", flush: false, src: "mentions per 100 headlines" })}
    ${panel("People & places they keep mentioning", `<table class="t"><thead><tr><th>Name</th><th>Their headlines</th><th>Compared with US media</th></tr></thead><tbody>${p.entities.map((e) => `<tr class="click" data-p="${esc(e.name)}"><td class="nm">${esc(e.name)}</td><td>${e.docs}</td><td class="nm" style="color:${e.lift >= 3 ? col : "inherit"}">${times(e)}</td></tr>`).join("")}</tbody></table>`, { cls: "c6", scroll: true, maxh: 560, src: "click a name to look them up" })}
    ${panel("Big in US news, barely mentioned by them", `<table class="t"><thead><tr><th>Topic</th><th>US media, per 100 headlines</th><th>${esc(CCN[cc])}, per 100 headlines</th></tr></thead><tbody>${p.avoid.map((t) => `<tr><td class="nm">${esc(t.term)}</td><td>${fmt(t.us_per100, 1)}</td><td class="muted">${fmt(t.per100, 1)}</td></tr>`).join("")}</tbody></table>`, { cls: "c12" })}`}
    </div>`;
  if (p.docs >= 10) {
    const top = p.terms.slice(0, 18);
    bars("l-ch", top.map((t) => t.term), [
      { label: `${CCN[cc]} state media`, data: top.map((t) => t.per100), backgroundColor: col },
      { label: "US media", data: top.map((t) => t.us_per100), backgroundColor: "#6b6b72" }],
      { horizontal: true, legend: true, fmt: (v) => fmt(v, 1) + " per 100 headlines", yfmt: (v) => fmt(v, 0) });
  }
  bindSeg("l-cc", (v) => { IW.cc = v; save(); render(); });
  bindSeg("l-d", (v) => { IW.pfDays = +v; save(); render(); });
  $("#l-wire").onclick = () => { IW.grp = "state:" + cc; IW.q = ""; go("wire"); };
  $$("tr[data-p]").forEach((r) => (r.onclick = () => go("people", r.dataset.p)));
  setStatus("ok", `${CCN[cc]}: ${p.docs} items`);
}

/* ================================================================== PEOPLE & ORGS */
const SUGGEST = [
  ["Elon Musk", "Timothy Mellon", "Miriam Adelson", "Richard Uihlein", "Ken Griffin", "Jeff Yass"],
  ["Michael Bloomberg", "George Soros", "Reid Hoffman", "Dustin Moskovitz", "Jon Stryker", "Fred Eychaner"],
  ["TikTok", "Huawei", "SpaceX", "Meta Platforms", "Qatar", "Saudi Arabia"],
];
async function people(g) {
  const name = IW.person || "Elon Musk";
  loading(`Looking up ${esc(name)}...`);
  setStatus("busy", `Looking up ${name}...`);
  let d;
  try { d = await api(`/api/iw/person?name=${enc(name)}`); } catch (e) { return fail(g, e); }
  if (g !== gen) return;
  const amp = d.amplification;
  const gnStateN = d.gnews.filter((x) => x.state_cc).length;
  const nState = d.state_items.length;
  const verdict = !d.mentions ? `<b>${esc(d.name)}</b> hasn't appeared in any of the ~65 sources in the last 30 days.`
    : `In the last 30 days <b>${esc(d.name)}</b> appeared in <b>${plural(d.mentions, "headline")}</b> across ${plural(d.outlets.length, "outlet")}. <b>${nState}</b> of them came from foreign state media${!isNum(amp) ? "." : amp >= 1.5 ? `, <b class="down">${fmt(amp, 1)}&times; more than you'd expect</b>. State media are paying them unusual attention. Read what they say below.` : amp <= 0.67 ? `, less than you'd expect. State media aren't focusing on them.` : `, about what you'd expect.`}`;
  PAGE.innerHTML = `<div class="grid">
    ${intro(`<b>Type any person or organization</b> to see how they're covered, what foreign state media say about them, and any <b>public records of money</b>: political donations (FEC), lobbying, and foreign-agent filings (FARA).`)}
    ${panel("Look up", `<div class="iwbar"><input id="p-n" class="inp wide" style="width:260px" value="${esc(name)}"><button class="btn sm primary" id="p-go">LOOK UP</button>
       <span class="muted small">Tip: add other spellings with | e.g. <i>Elon Musk|Musk</i></span></div>
       <div class="note small" style="padding-top:0">Try: biggest political donors of 2024 (both parties), or organizations:
       ${SUGGEST.map((row) => `<div class="chips" style="margin-top:4px">${row.map((n) => `<button class="btn sm sug" data-n="${esc(n)}">${esc(n)}</button>`).join("")}</div>`).join("")}</div>`, { cls: "c12", flush: false })}
    <div class="c12 intro verdict">${verdict}${d.gnews.length ? ` On Google News this week: ${plural(d.gnews.length, "article")}${gnStateN ? `, ${gnStateN} from state outlets` : ""}.` : ""}</div>
    ${panel(`Headlines about ${esc(d.name)} per day, by source (30 days)`, `<div class="chart-box"><canvas id="p-ch"></canvas></div>${legend()}`, { cls: "c8", flush: false })}
    ${panel("Which outlets cover them most", `<table class="t"><tbody>${d.outlets.map(([n, c]) => `<tr><td class="nm">${esc(n)}</td><td>${c}</td></tr>`).join("") || "<tr><td class='muted'>No mentions yet</td></tr>"}</tbody></table>`, { cls: "c4", scroll: true, maxh: 300 })}
    ${panel(`What foreign state media say about ${esc(d.name)}`, itemList(d.state_items, { summ: true }), { cls: "c6", scroll: true, maxh: 520 })}
    ${panel("Everyone else's coverage", itemList(d.other_items), { cls: "c6", scroll: true, maxh: 520 })}
    ${panel("Money: political donations they made", `<div id="p-fec"><div class="loading">Loading FEC itemized contributions...</div></div>`, { cls: "c8", src: "Federal Election Commission" })}
    ${panel("Google News, 7 days: who is covering them", `<table class="t"><tbody>${d.gnews_outlets.map(([n, c]) => `<tr><td class="nm">${esc(n)}${d.gnews.find((x) => x.outlet === n && x.state_cc) ? " " + ccTag(d.gnews.find((x) => x.outlet === n).state_cc) : ""}</td><td>${c}</td></tr>`).join("") || `<tr><td class="muted">${esc(d.gnews_error || "No results")}</td></tr>`}</tbody></table>`, { cls: "c4", scroll: true, maxh: 420 })}
    ${panel("Money: lobbyists they paid", `<div id="p-lda"><div class="loading">Loading lda.gov...</div></div>`, { cls: "c6", src: "Lobbying Disclosure Act filings" })}
    ${panel("Money: foreign-government ties on record", `<div id="p-fara"><div class="loading">Searching FARA...</div></div>`, { cls: "c6", src: "DOJ Foreign Agents Registration Act" })}
    ${panel("Money: stock trades in Congress & federal contracts", `<div id="p-trd"><div class="loading">Checking House stock-trade reports and USAspending.gov...</div></div>`, { cls: "c12", src: "STOCK Act reports &middot; USAspending.gov" })}
    </div>`;
  stackedChart("p-ch", d.chart);
  const look = () => { const v = $("#p-n").value.trim(); if (v) go("people", v); };
  $("#p-go").onclick = look;
  $("#p-n").onkeydown = (e) => { if (e.key === "Enter") look(); };
  $$(".sug").forEach((b) => (b.onclick = () => go("people", b.dataset.n)));
  setStatus("ok", d.name);
  loadFEC(g, name);
  loadLDAClient(g, name);
  loadFaraHits(g, name);
  loadTradesFor(g, name);
}

async function loadTradesFor(g, name) {
  const first = name.split("|")[0].trim();
  const words = first.toLowerCase().split(/\s+/).filter((w) => w.length > 1);
  const [cg, k] = await Promise.all([soft(api("/api/iw/congress?days=200")), soft(api(`/api/iw/contracts_search?q=${enc(first)}`))]);
  if (g !== gen || !$("#p-trd")) return;
  // a member matches when every word typed appears in their name (so "Pelosi" or "Nancy Pelosi" both work)
  const mine = (cg.trades || []).filter((t) => words.length && words.every((w) => t.member.toLowerCase().includes(w)));
  const parts = [];
  if (mine.length) {
    const m = mine[0];
    parts.push(`<div class="sub-h">${esc(m.member)} ${partyTag(m.party, m.sd)}: ${plural(mine.length, "stock trade")} reported in the last 200 days</div>
      <table class="t"><tbody>${mine.slice(0, 25).map((t) => `<tr><td class="nm">${esc(t.tdate)}</td><td>${txTag(t.tx)}</td><td class="nm wrap">${t.ticker ? `<b>${esc(t.ticker)}</b> ` : ""}${esc(t.asset)}${OWN[t.owner] ? ` <span class="muted small">(${OWN[t.owner]})</span>` : ""}</td><td class="nm">${range(t.lo, t.hi)}</td><td class="nm small">${t.late ? `<span class="flag f-amber">LATE ${t.late}d</span> ` : ""}${link(t.url, "report")}</td></tr>`).join("")}</tbody></table>
      <div class="btnrow"><button class="btn sm more" id="p-cg">All their trades &rarr;</button></div>`);
  }
  if (k.recipients && k.recipients.length) parts.push(`<div class="sub-h">Federal contracts</div>${contractsBlock(k, { compact: true })}<div class="btnrow"><button class="btn sm more" id="p-k">Contract details &rarr;</button></div>`);
  $("#p-trd").innerHTML = parts.length ? parts.join("") : `<div class="note">No House stock-trade reports or federal contracts under "${esc(first)}". Stock trades cover House members only; contracts cover companies, not people.</div>`;
  if ($("#p-cg")) $("#p-cg").onclick = () => go("congress", mine[0].member);
  if ($("#p-k")) $("#p-k").onclick = () => go("contracts", first);
}

async function loadFEC(g, name, force) {
  const box = () => $("#p-fec");
  let d;
  try { d = await api(`/api/iw/fec?name=${enc(name)}${force ? "&force=1" : ""}`); } catch (e) {
    if (g === gen && box()) box().innerHTML = errBox(e) + `<div class="note">Without your own key, FEC lookups share a tiny public quota. Get a free key at <a href="https://api.data.gov/signup/" target="_blank" rel="noopener">api.data.gov/signup</a> and paste it in ABOUT &gt; Settings.</div>`;
    return;
  }
  if (g !== gen || !box()) return;
  if (!d.rows.length) { box().innerHTML = `<div class="note">No itemized individual contributions found for "${esc(d.name)}". Organizations and foreign nationals cannot appear here: foreign nationals are barred from US election contributions. ${link(d.link, "Search FEC.gov")}</div>`; return; }
  const names = d.names_matched.map(([n, c]) => `${esc(n)} (${c})`).join(", ");
  const topC = d.by_committee[0];
  box().innerHTML = `<div class="note"><b>${money(d.total_listed)}</b> in their ${d.rows.length} largest recorded donations, to ${plural(d.by_committee.length, "political committee")}${topC ? `. The biggest recipient was <b>${esc(topC.committee)}</b> (${money(topC.amount)})` : ""}. ${d.itemized_count > d.rows.length ? `FEC lists ${fmt(d.itemized_count, 0)} donations in total.` : ""}</div>
    <div class="grid2"><div><div class="sub-h">By committee</div><table class="t"><tbody>${d.by_committee.slice(0, 14).map((c) => `<tr><td class="nm wrap">${esc(c.committee)}<div class="muted small">${esc(c.type || "")}${c.party ? " &middot; " + esc(c.party) : ""}</div></td><td>${money(c.amount)}</td></tr>`).join("")}</tbody></table></div>
      <div><div class="sub-h">By election cycle</div><div class="chart-box short"><canvas id="fec-ch"></canvas></div>
      <div class="sub-h">Largest contributions</div><table class="t"><tbody>${d.rows.filter((r) => !r.memo).slice(0, 12).map((r) => `<tr><td>${esc(r.date || "")}</td><td>${money(r.amount)}</td><td class="nm wrap small">${esc(r.committee)}</td></tr>`).join("")}</tbody></table></div></div>
    <div class="note small">Matched donor names: ${names}. Check employer and city to make sure it is the same person. ${link(d.link, "Full records at FEC.gov")} &middot; <a href="#" id="fec-re">refresh</a></div>`;
  bars("fec-ch", d.by_cycle.map((x) => String(x[0])), [{ label: "Contributions", data: d.by_cycle.map((x) => x[1]), backgroundColor: "#2dd4bf" }], { legend: false, fmt: money, yfmt: (v) => "$" + big(v) });
  $("#fec-re").onclick = (e) => { e.preventDefault(); box().innerHTML = `<div class="loading">Reloading...</div>`; loadFEC(g, name, true); };
}

function ldaTable(fl) {
  return `<table class="t"><thead><tr><th>Posted</th><th>Registrant (lobbyist)</th><th>Client</th><th>Period</th><th>Amount</th><th>Issues</th></tr></thead><tbody>${fl.map((f) => `<tr>
    <td>${link(f.url, f.posted)}</td><td class="nm wrap">${esc(f.registrant)}</td><td class="nm wrap">${esc(f.client)}${f.client_country ? ` <span class="muted">(${esc(f.client_country)})</span>` : ""}</td>
    <td class="nm small">${esc(f.year)} ${esc((f.period || "").replace(/\s*\(.*\)/, ""))}</td><td>${f.amount ? money(f.amount) : "<span class='muted'>--</span>"}</td>
    <td class="nm wrap small">${esc(f.issues.join(", "))}${f.foreign.length ? `<div class="amber">Foreign entities: ${f.foreign.map((x) => esc(`${x.name} (${x.country || "?"})`)).join("; ")}</div>` : ""}</td></tr>`).join("")}</tbody></table>`;
}
async function loadLDAClient(g, name) {
  let d;
  try { d = await api(`/api/iw/lda_client?name=${enc(name)}`); } catch (e) { if (g === gen && $("#p-lda")) $("#p-lda").innerHTML = errBox(e); return; }
  if (g !== gen || !$("#p-lda")) return;
  $("#p-lda").innerHTML = d.filings.length
    ? `<div class="note small">${fmt(d.count, 0)} filings name "${esc(d.name)}" as the lobbying client. The latest 25 are below. ${link(d.link, "Search lda.gov")}</div>${ldaTable(d.filings)}`
    : `<div class="note">No lobbying filings list "${esc(d.name)}" as a client. Individuals rarely appear here; companies and governments do.</div>`;
}
async function loadFaraHits(g, name) {
  const q = name.split("|")[0].split(",")[0].trim();
  let d;
  try { d = await api(`/api/iw/fara_search?q=${enc(q)}`); } catch (e) { if (g === gen && $("#p-fara")) $("#p-fara").innerHTML = errBox(e); return; }
  if (g !== gen || !$("#p-fara")) return;
  const n = d.principals.length + d.registrants.length + d.individuals.length;
  $("#p-fara").innerHTML = n ? faraHits(d) : `<div class="note">No FARA records mention "${esc(q)}". FARA only covers people and firms that registered as agents of a foreign principal.</div>`;
}
function docLinks(docs) {
  return (docs || []).slice(0, 4).map((x) => `<a href="${esc(x.url)}" target="_blank" rel="noopener" title="${esc(x.type)} ${esc(x.date)}">${esc(x.type.replace("Informational Materials", "Info").replace("Supplemental Statement", "Supp").replace("Registration Statement", "Reg").replace("Exhibit AB", "Ex AB"))}</a>`).join(" ");
}
function faraHits(d) {
  return `${d.principals.length ? `<div class="sub-h">Foreign principals / registrants (${d.principals.length})</div>${faraTable(d.principals)}` : ""}
    ${d.registrants.length ? `<div class="sub-h">Registered agents (${d.registrants.length})</div><table class="t"><tbody>${d.registrants.map((r) => `<tr><td class="nm wrap">${esc(r.name)}${r.business ? `<div class="muted small">${esc(r.business)}</div>` : ""}</td><td>${esc(r.date)}${r.end ? `<div class="muted small">ended ${esc(r.end)}</div>` : ` <span class="flag f-red">ACTIVE</span>`}</td><td class="nm wrap small">${r.principals.map(esc).join("<br>")}</td><td class="nm small">${docLinks(r.docs)}</td></tr>`).join("")}</tbody></table>` : ""}
    ${d.individuals.length ? `<div class="sub-h">Individuals registered under an agent (short forms, ${d.individuals.length})</div><table class="t"><tbody>${d.individuals.slice(0, 60).map((r) => `<tr><td class="nm">${esc(r.name)}</td><td class="nm wrap">${esc(r.registrant)}</td><td>${esc(r.date)}</td><td class="muted">${r.end ? "ended " + esc(r.end) : "<span class='flag f-red'>ACTIVE</span>"}</td></tr>`).join("")}</tbody></table>` : ""}`;
}
function faraTable(rows, o = {}) {
  return `<table class="t"><thead><tr><th>Foreign client</th>${o.country ? "<th>Country</th>" : ""}<th>US agent they pay</th><th>Since</th><th>Status</th><th>Official filings (PDF)</th></tr></thead><tbody>${rows.map((r) => `<tr>
    <td class="nm wrap">${esc(r.principal)}${r.media ? ` <span class="flag f-amber">MEDIA</span>` : ""}</td>${o.country ? `<td class="nm">${esc(r.country)}</td>` : ""}
    <td class="nm wrap">${esc(r.registrant)}${r.city ? `<div class="muted small">${esc(r.city)}</div>` : ""}</td><td>${esc(r.fp_date)}</td>
    <td>${r.fp_end ? `<span class="muted">ended ${esc(r.fp_end)}</span>` : `<span class="flag f-red">ACTIVE</span>`}</td>
    <td class="nm small" title="${esc(r.doc_types.map(([t, c]) => `${t}: ${c}`).join("\n"))}">${r.ndocs} &middot; ${docLinks(r.docs)}</td></tr>`).join("")}</tbody></table>`;
}

/* ================================================================== MONEY */
const QUICK = [["RUSSIA", "RU"], ["CHINA", "CN"], ["IRAN", "IR"], ["VENEZUELA", "VE"], ["QATAR", "QA"], ["SAUDI ARABIA", "SA"], ["UNITED ARAB EMIRATES", "UAE"], ["ISRAEL", "IL"], ["TURKEY", "TR"], ["HUNGARY", "HU"], ["UKRAINE", "UA"], ["TAIWAN", "TW"]];
async function moneyTab(g) {
  loading("Loading DOJ FARA registry (first load downloads ~5 MB, then cached daily)...");
  setStatus("busy", "Loading FARA...");
  let s, c;
  try { [s, c] = await Promise.all([api("/api/iw/fara_summary"), api(`/api/iw/fara_country?country=${enc(IW.fcountry)}&terminated=${IW.fterm ? 1 : 0}`)]); } catch (e) { return fail(g, e); }
  if (g !== gen) return;
  const top = s.countries.slice(0, 22);
  PAGE.innerHTML = `<div class="grid">
    ${intro(`<b>US law requires anyone paid by a foreign government to influence Americans to register with the Justice Department</b> (FARA, the Foreign Agents Registration Act). Right now <b>${fmt(s.active_principals, 0)}</b> foreign governments, parties and companies have <b>${fmt(s.active_registrants, 0)}</b> registered US firms or people working for them. Pick a country to see who. Every row links to the official filing.`)}
    ${panel("Search the records", `<div class="iwbar">
        <input id="m-q" class="inp wide" style="width:300px" placeholder="any name, firm or government..."><button class="btn sm primary" id="m-go">SEARCH</button>
        <span class="muted small">official US Justice Department data, updated ${esc((s.updated || "").slice(0, 10))}</span></div>
        <div id="m-res"></div>`, { cls: "c12", flush: false })}
    ${panel("Which countries pay the most US agents", `<div class="chart-box xtall"><canvas id="m-ch"></canvas></div><div class="note small">Click a bar to see that country.</div>`, { cls: "c4", flush: false, src: "currently active" })}
    ${panel(`${esc(titleCase(c.country))}: ${plural(c.count, "client")} paying ${plural(c.registrants, "US agent")}`, `<div class="iwbar">${segHTML("m-cc", QUICK.map(([k, l]) => [k, l]), IW.fcountry)}
        <select id="m-sel" class="selbox"><option value="">all countries...</option>${s.all_countries.map((x) => `<option ${x === IW.fcountry ? "selected" : ""}>${esc(x)}</option>`).join("")}</select>
        <label class="small"><input type="checkbox" id="m-term" ${IW.fterm ? "checked" : ""}> include terminated</label></div>
        ${c.rows.length ? faraTable(c.rows) : `<div class="note">No ${IW.fterm ? "" : "active "}registrations for ${esc(c.country)}.${IW.fterm ? "" : " Tick \"include terminated\" to see history."}</div>`}`, { cls: "c8", scroll: true, maxh: 620 })}
    ${panel(`Foreign state media &amp; government press offices registered as agents`, faraTable(s.media, { country: true }), { cls: "c7", scroll: true, maxh: 560, src: "Russia, China, Iran, Venezuela, Gulf states, Turkey, Hungary" })}
    ${panel("Newest registrations (last 6 months)", faraTable(s.recent, { country: true }), { cls: "c5", scroll: true, maxh: 560 })}
    ${panel(`Lobbyists working for ${esc(titleCase(c.country))}-based companies`, `<div id="m-lda">${c.cc ? `<div class="loading">Loading lda.gov...</div>` : `<div class="note">No lobbying lookup for ${esc(c.country)}.</div>`}</div>`, { cls: "c12", src: "Lobbying Disclosure Act filings" })}
    ${panel("Reading the filings", `<div class="note">
      <p>Each registration's PDFs include the <b>contract</b> ("Ex AB"), <b>money received and spent</b> ("Supp", supplemental statements), and the <b>material they distribute</b> ("Info"). The US arms of several state broadcasters register this way; for example, China Daily's distributor's filings disclose payments for advertising inserts in US newspapers.</p>
      <p>These records only show <b>disclosed</b> money. Hidden funding exists, but by definition it isn't in public records. When the Justice Department catches it, the charges show up under <b>GOV ACTIONS</b>.</p></div>`, { cls: "c12" })}
    </div>`;
  bars("m-ch", top.map((x) => x.country), [{ label: "Active principals", data: top.map((x) => x.principals), backgroundColor: top.map((x) => (["RUSSIA", "CHINA", "IRAN", "VENEZUELA"].includes(x.country) ? "#ff5252" : "#2dd4bf")) }], { horizontal: true, legend: false, fmt: (v) => fmt(v, 0) });
  const ch = charts["m-ch"];
  if (ch) ch.options.onClick = (e, el) => { if (el && el.length) { IW.fcountry = top[el[0].index].country; save(); render(); } };
  bindSeg("m-cc", (v) => { IW.fcountry = v; save(); render(); });
  $("#m-sel").onchange = (e) => { if (e.target.value) { IW.fcountry = e.target.value; save(); render(); } };
  $("#m-term").onchange = (e) => { IW.fterm = e.target.checked; save(); render(); };
  const search = async () => {
    const q = $("#m-q").value.trim();
    if (q.length < 3) return;
    $("#m-res").innerHTML = `<div class="loading">Searching...</div>`;
    try { const r = await api(`/api/iw/fara_search?q=${enc(q)}`); $("#m-res").innerHTML = (r.principals.length + r.registrants.length + r.individuals.length) ? faraHits(r) : `<div class="note">No FARA records match "${esc(q)}".</div>`; } catch (e) { $("#m-res").innerHTML = errBox(e); }
  };
  $("#m-go").onclick = search;
  $("#m-q").onkeydown = (e) => { if (e.key === "Enter") search(); };
  setStatus("ok", `${c.country}: ${c.count} principals`);
  if (c.cc) {
    try {
      const l = await api(`/api/iw/lda_country?cc=${enc(c.cc)}`);
      if (g !== gen || !$("#m-lda")) return;
      $("#m-lda").innerHTML = `<div class="grid2"><div><div class="sub-h">Clients based in ${esc(titleCase(c.country))} (${fmt(l.client.count, 0)} filings, newest 25)</div>${ldaTable(l.client.filings)}</div>
        <div><div class="sub-h">Clients part-owned, funded or controlled from ${esc(titleCase(c.country))} (${fmt(l.foreign.count, 0)} filings, newest 25)</div>${ldaTable(l.foreign.filings)}</div></div>`;
    } catch (e) { if (g === gen && $("#m-lda")) $("#m-lda").innerHTML = errBox(e); }
  }
}

/* ================================================================== GOV */
async function gov(g) {
  loading("Loading government releases...");
  setStatus("busy", "Loading...");
  let d;
  try { d = await api("/api/iw/gov"); } catch (e) { return fail(g, e); }
  if (g !== gen) return;
  const ag = Object.entries(d.agencies);
  PAGE.innerHTML = `<div class="grid">
    ${intro(`<b>What the US government is doing about foreign influence, spying and sanctions</b>: arrests, guilty pleas, sanctions and new rules, from official press releases. Below are the latest releases from each agency.`)}
    ${panel("Arrests, charges, sanctions & reports (last 30 days)", itemList(d.enforcement, { summ: true }), { cls: "c7", scroll: true, maxh: 640, src: "Justice Dept, FBI, State, White House, Defense, GAO" })}
    ${panel("New federal rules & notices", `<ul class="news iw">${d.fedreg.map((x) => `<li><span class="tm">${esc((x.date || "").slice(5))}</span><span class="tx">${link(x.url, x.title)}<small>${esc(x.agency)} &middot; ${esc(x.type)}${x.abstract ? " &middot; " + esc(x.abstract) : ""}</small></span></li>`).join("")}</ul>`, { cls: "c5", scroll: true, maxh: 640, src: "federalregister.gov" })}
    ${ag.map(([n, items]) => panel(esc(n), itemList(items), { cls: "c4", scroll: true, maxh: 340 })).join("")}
    ${panel("Disinformation research (EUvsDisinfo, DFRLab)", itemList(d.research, { summ: true }), { cls: "c12", scroll: true, maxh: 420 })}
    </div>`;
  setStatus("ok", `${d.enforcement.length} enforcement items`);
}

/* ================================================================== WHO PROFITS: shared bits */
const PCOL = { D: "#60a5fa", R: "#f87171", I: "#c084fc" };
const PNAME = { D: "Democrat", R: "Republican", I: "Independent" };
const seat = (sd) => { const m = /^([A-Z]{2})0*(\d*)$/.exec(sd || ""); return m ? `${m[1]}-${m[2] && m[2] !== "0" ? m[2] : "AL"}` : sd || ""; };
const partyTag = (p, sd) => `<span class="stag" style="--c:${PCOL[p] || "#a3a3a3"}" title="${PNAME[p] || "party unknown"}">${esc(p || "?")} &middot; ${esc(seat(sd))}</span>`;
const kd = (v) => (v < 1000 ? "$" + fmt(v, 0) : v < 1e6 ? "$" + Math.round(v / 1e3) + "K" : "$" + Math.round(v / 1e5) / 10 + "M");
const range = (lo, hi) => (lo == null ? "--" : hi == null ? `over ${kd(lo)}` : lo === hi ? money(lo) : `${kd(lo)}&ndash;${kd(hi)}`);
const txTag = (tx) => (tx === "buy" ? `<b class="up">BUY</b>` : tx.startsWith("sell") ? `<b class="down">SELL${tx.includes("partial") ? "<small> part</small>" : ""}</b>` : `<b class="muted">${esc(tx.toUpperCase())}</b>`);
const OWN = { self: "", spouse: "spouse", joint: "joint", child: "child" };
function companyName(asset) {
  let s = String(asset || "").split(/\s+-\s+/)[0].replace(/\(.*?\)/g, " ");
  for (let i = 0; i < 3; i++) s = s.replace(/[,\s]+(Inc\.?|Incorporated|Corporation|Corp\.?|Company|Co\.?|Ltd\.?|Limited|plc|N\.V\.|S\.A\.|SE|AG|Holdings?|Group|New|Class [A-C]|Common Stock|Ordinary Shares|ADR|American Depositary Shares?)\s*$/i, "");
  return s.replace(/^The\s+/i, "").trim();
}
function awardTable(rows) {
  if (!rows.length) return `<div class="note">None.</div>`;
  return `<table class="t"><thead><tr><th>Company</th><th class="l">Agency</th><th>Contract value</th><th>Start</th><th class="l">What for</th></tr></thead><tbody>${rows.map((a) => `<tr>
    <td class="nm wrap">${a.url ? link(a.url, titleCase(a.recipient)) : esc(titleCase(a.recipient))}</td>
    <td class="nm wrap small">${esc(a.agency || "")}${a.sub && a.sub !== a.agency ? `<div class="muted">${esc(a.sub)}</div>` : ""}</td>
    <td>${money(a.amount)}</td><td class="nm">${esc(a.start || "")}</td><td class="descr small">${esc(a.descr || "")}</td></tr>`).join("")}</tbody></table>`;
}
function contractsBlock(d, o = {}) {
  if (d.error) return errBox(d.error);
  if (!d.recipients || !d.recipients.length) return `<div class="note">No federal contracts found for companies named like "${esc(d.q)}" in the last ${d.years_back} years.</div>`;
  const names = d.recipients.slice(0, 5).map((r) => esc(titleCase(r.name))).join(", ") + (d.recipients.length > 5 ? "..." : "");
  return `<div class="note"><b>${money(d.total)}</b> of federal contract money went to companies named like "<b>${esc(d.q)}</b>" in the last ${d.years_back} years.
      <span class="muted small">Matched: ${names}. The search matches any company with those words in its name, so check the names.</span></div>
    ${o.compact ? "" : `<div class="grid2"><div><div class="sub-h">By government fiscal year (Oct&ndash;Sep)</div><div class="chart-box short"><canvas id="${o.chart}"></canvas></div></div>
      <div><div class="sub-h">Which agencies pay them</div><table class="t"><tbody>${d.agencies.map((a) => `<tr><td class="nm wrap">${esc(a.name)}</td><td>${money(a.amount)}</td></tr>`).join("")}</tbody></table></div></div>`}
    <div class="sub-h">Biggest contracts</div>${awardTable(d.awards.slice(0, o.compact ? 6 : 30))}
    ${d.errors && d.errors.length ? `<div class="note small amber">${esc(d.errors[0])}</div>` : ""}`;
}
function yearChart(id, d) {
  if (!d.years || !d.years.length || !$("#" + id)) return;
  bars(id, d.years.map((y) => "FY" + y.fy), [{ label: "Contract money", data: d.years.map((y) => y.amount), backgroundColor: "#2dd4bf" }], { legend: false, fmt: money, yfmt: (v) => "$" + big(v) });
}
const ADD_EMAIL = `<span class="amber">To see what they bought and sold, add your email under HOW IT WORKS &gt; Settings.</span> The SEC asks apps that download its filings to include one.`;
function insiderBlock(d, o = {}) {
  if (d.error && !d.found) return errBox(d.error);
  if (!d.found) return `<div class="note">No SEC-registered company matches "${esc(d.q)}".</div>`;
  const filings = `<table class="t"><tbody>${d.filings.slice(0, o.compact ? 8 : 40).map((f) => `<tr><td>${esc(f.filed)}</td><td class="nm wrap">${esc(f.owner)}</td><td>${link(f.url, "Form " + f.form)}</td></tr>`).join("")}</tbody></table>`;
  const head = `<b>${esc(d.name)}</b>${d.ticker ? ` (${esc(d.ticker)})` : ""}: ${plural(d.filings.length, "insider report")} in the last 12 months.`;
  if (!d.contact) return `<div class="note">${head} ${ADD_EMAIL}</div>${filings}`;
  if (d.error) return `<div class="note">${head}</div>${errBox(d.error)}${filings}`;
  if (!d.trades.length) return `<div class="note">${head} None of them were open-market buys or sales (they were grants, option exercises, tax withholding or gifts).</div>${filings}`;
  return `<div class="note">${head} Insiders <b class="up">bought ${money(d.bought)}</b> and <b class="down">sold ${money(d.sold)}</b> on the open market${d.sold ? ` (${money(d.planned_sold)} of the sales were pre-scheduled under a 10b5-1 trading plan)` : ""}.</div>
    <table class="t"><thead><tr><th>Insider</th><th>Role</th><th>Bought</th><th>Sold</th></tr></thead><tbody>${d.people.slice(0, 12).map((p) => `<tr><td class="nm wrap">${esc(p.owner)}</td><td class="nm wrap small">${esc(p.rel)}</td><td class="up">${p.buy ? money(p.buy) : ""}</td><td class="down">${p.sell ? money(p.sell) : ""}</td></tr>`).join("")}</tbody></table>
    <div class="sub-h">Each trade</div>${insiderTable(d.trades.slice(0, o.compact ? 10 : 40), { company: false })}`;
}
function insiderTable(rows, o = {}) {
  if (!rows.length) return `<div class="note">None in this window.</div>`;
  return `<table class="t"><thead><tr><th>Traded</th>${o.company === false ? "" : "<th class=\"l\">Company</th>"}<th class="l">Insider</th><th></th><th>Value</th><th>Avg price</th><th>Their stake</th><th></th></tr></thead><tbody>${rows.map((t) => `<tr>
    <td class="nm">${esc(t.last)}</td>
    ${o.company === false ? "" : `<td class="nm wrap"><a href="#" data-co="${esc(t.ticker || t.issuer)}">${t.ticker ? `<b>${esc(t.ticker)}</b> ` : ""}${esc(titleCase(t.issuer))}</a></td>`}
    <td class="nm wrap">${esc(titleCase(t.owner))}<div class="muted small">${esc(t.rel)}</div></td>
    <td>${txTag(t.side)}</td><td>${money(t.value)}</td><td>${t.price ? "$" + fmt(t.price, 2) : "--"}</td>
    <td class="small">${isNum(t.pct) ? `${t.side === "buy" ? "+" : "&minus;"}${fmt(t.pct, t.pct < 10 ? 1 : 0)}%` : ""}</td>
    <td class="nm small">${t.plan ? `<span class="flag f-dim" title="Pre-scheduled under a Rule 10b5-1 trading plan: decided months earlier, so a weaker signal">PLANNED</span> ` : ""}${link(t.url, "filing")}</td></tr>`).join("")}</tbody></table>`;
}
const progText = (st, what) => `<span class="amber">&#8635; Reading new ${what}${st.todo ? `: ${st.done} of ${st.todo}` : "..."}</span>`;
function progress(st, what) {
  if (!st || !st.busy) return "";
  return `<div class="c12 intro" id="iw-prog">${progText(st, what)} <span class="muted">You can keep using the page - new results appear when you choose.</span></div>`;
}
/* While a background download runs, only the progress line updates (no page rebuild = no flicker, no scroll jump).
   When it finishes, offer a button instead of reloading under the user. */
function pollWhileBusy(g, st, url, what, count) {
  if (!st || !st.busy || !url) return;
  const base = count;
  const tick = () => setTimeout(async () => {
    if (g !== gen) return;
    const d = await soft(api(url));
    if (g !== gen) return;
    const box = $("#iw-prog");
    if (!box) return;
    if (d.error) { tick(); return; }
    const n = d.buys ? d.buys.length + d.sells.length : arr(d.trades).length;
    const extra = n > base ? ` <b>${fmt(n - base, 0)} new trades found so far.</b>` : "";
    if (d.status && d.status.busy) {
      box.innerHTML = `${progText(d.status, what)}${extra} <span class="muted">New results appear when you choose.</span>${n > base ? ` <button class="btn sm more" id="iw-show">SHOW THEM NOW</button>` : ""}`;
      tick();
    } else {
      box.innerHTML = `<span class="up">&#10003; Finished reading ${what}.</span>${extra} <button class="btn sm more" id="iw-show">SHOW UPDATED RESULTS</button>`;
    }
    if ($("#iw-show")) $("#iw-show").onclick = () => softRefresh();
  }, 10000);
  tick();
}

/* ================================================================== CONGRESS TRADES */
let CG = null;
async function congress(g) {
  loading("Loading House members' stock trades (the first run reads about 150 reports, roughly a minute)...");
  setStatus("busy", "Loading Congress trades...");
  let d;
  try { d = await api(`/api/iw/congress?days=${IW.cgDays}`); } catch (e) { return fail(g, e); }
  if (g !== gen) return;
  CG = d;
  const q = (IW.cgQ || "").trim().toLowerCase();
  const stockish = (t) => ["ST", "OP", "EF"].includes(t.atype);
  const list = d.trades.filter((t) => (IW.cgKind === "all" || stockish(t))
    && (IW.cgSide === "all" || (IW.cgSide === "buy" ? t.tx === "buy" : t.tx.startsWith("sell")))
    && (IW.cgParty === "all" || t.party === IW.cgParty)
    && (!q || `${t.member} ${t.ticker} ${t.asset}`.toLowerCase().includes(q)));
  const late = d.trades.filter((t) => t.late);
  const lateBy = {};
  late.forEach((t) => { (lateBy[t.member] = lateBy[t.member] || { n: 0, max: 0, party: t.party, sd: t.sd }).n++; lateBy[t.member].max = Math.max(lateBy[t.member].max, t.late); });
  const top = d.tickers[0];
  const MAXROWS = 400;
  const rows = list.slice(0, MAXROWS).map((t) => `<tr>
      <td class="nm">${esc(t.filed)}</td>
      <td class="nm wrap"><a href="#" data-m="${esc(t.member)}">${esc(t.member)}</a> ${partyTag(t.party, t.sd)}</td>
      <td class="nm wrap">${t.ticker ? `<a href="#" data-t="${esc(t.ticker)}" data-a="${esc(t.asset)}"><b>${esc(t.ticker)}</b></a> ` : ""}${esc(t.asset)}
        <div class="muted small">${esc(t.kind)}${OWN[t.owner] ? " &middot; owned by " + OWN[t.owner] : ""}${t.descr && !t.descr.startsWith("account:") ? " &middot; " + esc(t.descr.split(" | ")[0]) : ""}</div></td>
      <td>${txTag(t.tx)}</td><td class="nm">${range(t.lo, t.hi)}</td><td class="nm">${esc(t.tdate)}</td>
      <td class="nm small">${t.late ? `<span class="flag f-amber" title="Reported ${t.late} days after the trade. The STOCK Act allows 45.">LATE: ${t.late} DAYS</span> ` : ""}${link(t.url, "report")}</td></tr>`).join("");
  PAGE.innerHTML = `<div class="grid">
    ${intro(`<b>Members of the House must report stock trades over $1,000 within 45 days</b> (the STOCK Act), including trades by their spouse and children. Amounts are only given as ranges. Click a <b>ticker</b> to see everyone in Congress who traded it, plus that company's government contracts and its own executives' trades. Click a <b>name</b> to see just their trades. <span class="muted">The Senate keeps its reports behind a terms-of-use page, so it isn't included.</span>`)}
    ${progress(d.status, "House reports")}
    <div class="c12 hidden" id="c-detail"></div>
    ${panel("Show", `<div class="iwbar">
        ${segHTML("cg-d", [[30, "30 DAYS"], [90, "90 DAYS"], [180, "6 MONTHS"]], IW.cgDays)}
        ${segHTML("cg-s", [["all", "BUYS & SELLS"], ["buy", "BUYS"], ["sell", "SELLS"]], IW.cgSide)}
        ${segHTML("cg-p", [["all", "BOTH PARTIES"], ["D", "DEMOCRATS"], ["R", "REPUBLICANS"]], IW.cgParty)}
        ${segHTML("cg-k", [["stocks", "STOCKS & OPTIONS"], ["all", "EVERYTHING (BONDS, FUNDS...)"]], IW.cgKind)}
        <input id="cg-q" class="inp wide" style="width:220px" placeholder="member, ticker or company..." value="${esc(IW.cgQ)}"><button class="btn sm" id="cg-go">FILTER</button>
        ${IW.cgQ ? `<button class="btn sm" id="cg-clr">&times; CLEAR</button>` : ""}</div>`, { cls: "c12", flush: false })}
    <div class="c12 kpis">
      <div class="kpi"><span>Trades reported</span><b>${fmt(d.trades.length, 0)}</b><small>in ${d.reports} reports over ${d.days} days</small></div>
      <div class="kpi"><span>Members trading</span><b>${fmt(d.members.length, 0)}</b><small>${d.members.filter((m) => m.party === "D").length} Democrats &middot; ${d.members.filter((m) => m.party === "R").length} Republicans</small></div>
      <div class="kpi"><span>Reported late</span><b class="${late.length ? "amber" : ""}">${fmt(late.length, 0)}</b><small>trades by ${plural(Object.keys(lateBy).length, "member")}</small></div>
      <div class="kpi"><span>Most widely traded</span><b>${top ? esc(top.ticker) : "--"}</b><small>${top ? `${plural(top.members, "member")} (${top.dem} D, ${top.rep} R)` : ""}</small></div>
    </div>
    ${panel(`Trades${q ? ` matching "${esc(IW.cgQ)}"` : ""} (${fmt(list.length, 0)})`, `<table class="t"><thead><tr><th>Reported</th><th class="l">Member</th><th class="l">What</th><th></th><th>Amount</th><th>Traded on</th><th></th></tr></thead><tbody>${rows || `<tr><td colspan="7" class="note">No trades match.</td></tr>`}</tbody></table>${list.length > MAXROWS ? `<div class="note small">Showing the newest ${MAXROWS}. Use the filters to narrow it down.</div>` : ""}`, { cls: "c8", scroll: true, maxh: 1100 })}
    <div class="c4 stack">
      ${panel("Stocks traded by the most members", `<table class="t"><thead><tr><th>Stock</th><th>Members</th><th>Buys</th><th>Sells</th></tr></thead><tbody>${d.tickers.slice(0, 25).map((t) => `<tr class="click" data-t="${esc(t.ticker)}" data-a="${esc(t.asset)}"><td class="nm"><b>${esc(t.ticker)}</b> <span class="muted small">${esc(companyName(t.asset))}</span></td><td class="nm">${t.members} <span class="small" style="color:${PCOL.D}">${t.dem}D</span> <span class="small" style="color:${PCOL.R}">${t.rep}R</span></td><td class="up">${t.buys}</td><td class="down">${t.sells}</td></tr>`).join("")}</tbody></table>`, { scroll: true, maxh: 520 })}
      ${panel("Most active traders", `<table class="t"><thead><tr><th>Member</th><th>Trades</th><th>Late</th></tr></thead><tbody>${d.members.slice(0, 25).map((m) => `<tr class="click" data-m="${esc(m.member)}"><td class="nm wrap">${esc(m.member)} ${partyTag(m.party, m.sd)}<div class="muted small">${m.committees.slice(0, 3).map(esc).join(" &middot; ")}</div></td><td>${m.n}<div class="small"><span class="up">${m.buys} buy</span> <span class="down">${m.sells} sell</span></div></td><td class="${m.late ? "amber" : "muted"}">${m.late || ""}</td></tr>`).join("")}</tbody></table><div class="note small">Grey text: the member's House committees. Worth noticing when someone trades companies their committee oversees.</div>`, { scroll: true, maxh: 560 })}
    </div>
    ${panel("Reported late (more than 45 days after the trade)", Object.keys(lateBy).length ? `<table class="t"><thead><tr><th>Member</th><th>Late trades</th><th>Longest delay</th></tr></thead><tbody>${Object.entries(lateBy).sort((a, b) => b[1].n - a[1].n).map(([m, v]) => `<tr class="click" data-m="${esc(m)}"><td class="nm">${esc(m)} ${partyTag(v.party, v.sd)}</td><td>${v.n}</td><td>${v.max} days</td></tr>`).join("")}</tbody></table><div class="note small">Late reports usually bring a $200 fine. Repeated lateness hides trades from the public for months.</div>` : `<div class="note">No late reports in this window.</div>`, { cls: "c6", scroll: true, maxh: 420 })}
    ${panel(`Paper reports (${d.paper.length})`, d.paper.length ? `<div class="note small">These were filed on paper and scanned, so the app can't read them. Open the PDF to see the trades.</div><table class="t"><tbody>${d.paper.map((p) => `<tr><td>${esc(p.filed)}</td><td class="nm">${esc(p.member)} <span class="muted">${esc(seat(p.sd))}</span></td><td>${link(p.url, "PDF")}</td></tr>`).join("")}</tbody></table>` : `<div class="note">None.</div>`, { cls: "c6", scroll: true, maxh: 420 })}
    </div>`;
  bindSeg("cg-d", (v) => { IW.cgDays = +v; save(); render(); });
  bindSeg("cg-s", (v) => { IW.cgSide = v; save(); render(); });
  bindSeg("cg-p", (v) => { IW.cgParty = v; save(); render(); });
  bindSeg("cg-k", (v) => { IW.cgKind = v; save(); render(); });
  const filt = () => { IW.cgQ = $("#cg-q").value.trim(); save(); render(); };
  $("#cg-go").onclick = filt;
  $("#cg-q").onkeydown = (e) => { if (e.key === "Enter") filt(); };
  if ($("#cg-clr")) $("#cg-clr").onclick = () => { IW.cgQ = ""; save(); render(); };
  $$("[data-m]").forEach((el) => (el.onclick = (e) => { e.preventDefault(); IW.cgQ = el.dataset.m; save(); render(); }));
  $$("[data-t]").forEach((el) => (el.onclick = (e) => { e.preventDefault(); tickerDetail(g, el.dataset.t, el.dataset.a); }));
  if (!SOFT && /^[A-Z.]{1,6}$/.test(IW.cgQ || "") && d.tickers.find((t) => t.ticker === IW.cgQ)) tickerDetail(g, IW.cgQ, d.tickers.find((t) => t.ticker === IW.cgQ).asset);
  setStatus("ok", `${fmt(list.length, 0)} trades`);
  pollWhileBusy(g, d.status, `/api/iw/congress?days=${IW.cgDays}`, "House reports", d.trades.length);
}

async function tickerDetail(g, tk, asset) {
  const box = $("#c-detail");
  if (!box) return;
  const co = companyName(asset) || tk;
  const rows = (CG ? CG.trades : []).filter((t) => t.ticker === tk);
  box.classList.remove("hidden");
  box.innerHTML = panel(`<b>${esc(tk)}</b> &middot; ${esc(asset || "")}`, `<div class="grid2">
      <div><div class="sub-h">Members of Congress who traded it (${rows.length})</div>
        <table class="t"><tbody>${rows.map((t) => `<tr><td class="nm">${esc(t.tdate)}</td><td class="nm">${esc(t.member)} ${partyTag(t.party, t.sd)}</td><td>${txTag(t.tx)}</td><td class="nm">${range(t.lo, t.hi)}</td><td>${t.late ? `<span class="flag f-amber">LATE</span>` : ""}</td></tr>`).join("")}</tbody></table>
        <div class="sub-h">The company's own executives (SEC Form 4, last 12 months)</div><div id="cd-ins"><div class="loading">Loading SEC filings...</div></div></div>
      <div><div class="sub-h">Federal contracts to "${esc(co)}" (last 5 years)</div><div id="cd-con"><div class="loading">Loading USAspending.gov...</div></div></div></div>`,
    { tools: `<button class="btn sm" id="cd-x">&times; CLOSE</button>` });
  box.scrollIntoView({ behavior: "smooth", block: "start" });
  $("#cd-x").onclick = () => { box.classList.add("hidden"); box.innerHTML = ""; };
  const [c, i] = await Promise.all([soft(api(`/api/iw/contracts_search?q=${enc(co)}`)), soft(api(`/api/iw/insider_company?q=${enc(tk)}`))]);
  if (g !== gen || !$("#cd-con")) return;
  $("#cd-con").innerHTML = contractsBlock(c, { compact: true }) + `<div class="btnrow"><button class="btn sm more" id="cd-more">All contracts for ${esc(co)} &rarr;</button></div>`;
  $("#cd-ins").innerHTML = insiderBlock(i, { compact: true }) +`<div class="btnrow"><button class="btn sm more" id="cd-ins-more">Open in INSIDER TRADES &rarr;</button></div>`;
  $("#cd-more").onclick = () => go("contracts", co);
  $("#cd-ins-more").onclick = () => go("insiders", tk);
}

/* ================================================================== INSIDER TRADES */
async function insiders(g) {
  loading("Loading company insider trades from the SEC...");
  setStatus("busy", "Loading insider trades...");
  let d;
  try { d = await api(`/api/iw/insiders?days=${IW.inDays}`); } catch (e) { return fail(g, e); }
  if (g !== gen) return;
  const totB = d.buys.reduce((a, t) => a + t.value, 0), totS = d.sells.reduce((a, t) => a + t.value, 0);
  PAGE.innerHTML = `<div class="grid">
    ${intro(`<b>Company executives, directors and big shareholders must report trades in their own company's stock within 2 business days</b> (SEC Form 4). The trades people watch are <b>open-market buys</b>: insiders sell for many reasons (taxes, a house, diversifying), but they usually buy for one. A buy that grows their stake a lot, or <b>several insiders buying at once</b>, stands out most.`)}
    ${progress(d.status, "SEC filings")}
    ${!d.contact ? `<div class="c12 intro">${ADD_EMAIL}
       <div class="iwbar" style="margin-top:6px"><input id="in-mail" class="inp wide" style="width:280px;text-transform:none" placeholder="your email"><button class="btn sm primary" id="in-save">SAVE</button>
       <span class="muted small">Saved on this PC and sent only to sec.gov, in the request header.</span></div></div>` : ""}
    ${panel("Look up a company", `<div class="iwbar"><input id="in-q" class="inp wide" style="width:260px" placeholder="ticker or company, e.g. TSLA or Lockheed" value="${esc(IW.inQ)}"><button class="btn sm primary" id="in-go">LOOK UP</button>
        ${["TSLA", "NVDA", "PLTR", "LMT", "META"].map((t) => `<button class="btn sm sug" data-co="${t}">${t}</button>`).join("")}</div><div id="in-res"></div>`, { cls: "c12", flush: false })}
    ${d.contact ? `
    ${panel("Show", `<div class="iwbar"><span class="muted small">reported in the last:</span>${segHTML("in-d", [[3, "3 DAYS"], [7, "WEEK"], [14, "2 WEEKS"], [30, "MONTH"]], IW.inDays)}
        <span class="muted small">${fmt(d.parsed, 0)} of ${fmt(d.filings, 0)} reports read${d.pending ? ` &middot; ${fmt(d.pending, 0)} still to read` : ""}</span></div>`, { cls: "c12", flush: false })}
    <div class="c12 kpis">
      <div class="kpi"><span>Insider buys</span><b class="up">${fmt(d.buys.length, 0)}</b><small>${money(totB)} in total</small></div>
      <div class="kpi"><span>Insider sales</span><b class="down">${fmt(d.sells.length, 0)}</b><small>${money(totS)} in total</small></div>
      <div class="kpi"><span>Companies with several buyers</span><b>${fmt(d.clusters.length, 0)}</b><small>2+ insiders buying</small></div>
      <div class="kpi"><span>Sales that were pre-planned</span><b>${d.sells.length ? fmt((100 * d.sells.filter((t) => t.plan).length) / d.sells.length, 0) + "%" : "--"}</b><small>10b5-1 trading plans</small></div>
    </div>
    ${panel("Biggest insider buys", insiderTable(d.buys.slice(0, 60)), { cls: "c7", scroll: true, maxh: 760, src: "open-market purchases (code P)" })}
    ${panel("Several insiders buying the same company", d.clusters.length ? `<table class="t"><thead><tr><th>Company</th><th>Buyers</th><th>Total</th></tr></thead><tbody>${d.clusters.map((c) => `<tr><td class="nm wrap"><a href="#" data-co="${esc(c.ticker || c.issuer)}">${c.ticker ? `<b>${esc(c.ticker)}</b> ` : ""}${esc(titleCase(c.issuer))}</a><div class="muted small">${c.people.map((p) => esc(titleCase(p))).join("<br>")}</div></td><td>${c.insiders}</td><td class="up">${money(c.value)}</td></tr>`).join("")}</tbody></table>` : `<div class="note">None in this window.</div>`, { cls: "c5", scroll: true, maxh: 760 })}
    ${panel("Biggest insider sales", insiderTable(d.sells.slice(0, 60)), { cls: "c12", scroll: true, maxh: 620, src: "PLANNED = scheduled months ahead under a 10b5-1 plan" })}` : `
    ${panel(`Newest insider reports (${fmt(d.filings, 0)} in the last ${d.days} days)`, `<table class="t"><thead><tr><th>Reported</th><th class="l">Company</th><th class="l">Insider</th><th></th></tr></thead><tbody>${d.recent.slice(0, 150).map((r) => `<tr><td class="nm">${esc(r.filed)}</td><td class="nm wrap"><a href="#" data-co="${esc(r.issuer)}">${esc(titleCase(r.issuer))}</a></td><td class="nm wrap">${esc(titleCase(r.owner))}</td><td>${link(r.url, "filing")}</td></tr>`).join("")}</tbody></table>`, { cls: "c12", scroll: true, maxh: 700 })}`}
    </div>`;
  const look = async (v) => {
    v = (v || "").trim();
    if (!v) return;
    IW.inQ = v; save();
    $("#in-q").value = v;
    $("#in-res").innerHTML = `<div class="loading">Looking up ${esc(v)}${d.contact ? " and reading its filings (can take 20 seconds the first time)" : ""}...</div>`;
    const r = await soft(api(`/api/iw/insider_company?q=${enc(v)}`));
    if (g !== gen) return;
    $("#in-res").innerHTML = insiderBlock(r) + (r.found ? `<div class="btnrow"><button class="btn sm more" id="in-con">Federal contracts for ${esc(companyName(r.name))} &rarr;</button></div>` : "");
    if ($("#in-con")) $("#in-con").onclick = () => go("contracts", companyName(r.name));
  };
  $("#in-go").onclick = () => look($("#in-q").value);
  $("#in-q").onkeydown = (e) => { if (e.key === "Enter") look($("#in-q").value); };
  $$("[data-co]").forEach((el) => (el.onclick = (e) => { e.preventDefault(); look(el.dataset.co); window.scrollTo({ top: 0, behavior: "smooth" }); }));
  if ($("#in-save")) $("#in-save").onclick = async () => {
    const r = await soft(api(`/api/iw/settings?sec_contact=${enc($("#in-mail").value.trim())}`));
    if (r.error) { $("#in-mail").value = ""; $("#in-mail").placeholder = r.error; return; }
    render();
  };
  if (d.contact) bindSeg("in-d", (v) => { IW.inDays = +v; save(); render(); });
  if (IW.inQ && !SOFT) look(IW.inQ);
  setStatus("ok", `${fmt(d.filings, 0)} insider reports`);
  pollWhileBusy(g, d.status, `/api/iw/insiders?days=${IW.inDays}`, "SEC filings", d.buys.length + d.sells.length);
}

/* ================================================================== GOV CONTRACTS */
async function contracts(g) {
  loading("Loading federal contracts from USAspending.gov...");
  setStatus("busy", "Loading contracts...");
  let d;
  try { d = await api("/api/iw/contracts"); } catch (e) { return fail(g, e); }
  if (g !== gen) return;
  const top = (d.top || []).slice(0, 20);
  const musk = d.musk || [];
  PAGE.innerHTML = `<div class="grid">
    ${intro(`<b>Where federal contract money goes</b>, from USAspending.gov, the government's official spending database. Look up any company to see how much it gets, from which agencies, and for what. Contract values are the total committed to each contract, which can be spent over many years.`)}
    ${panel("Look up a company", `<div class="iwbar"><input id="k-q" class="inp wide" style="width:280px" placeholder="company name, e.g. Palantir" value="${esc(IW.conQ)}"><button class="btn sm primary" id="k-go">LOOK UP</button>
        ${["SpaceX", "Palantir", "Anduril", "Lockheed Martin", "Booz Allen", "Microsoft", "Amazon"].map((n) => `<button class="btn sm sug" data-k="${esc(n === "SpaceX" ? "Space Exploration Technologies" : n)}">${esc(n)}</button>`).join("")}</div>
        <div id="k-res"></div>`, { cls: "c12", flush: false })}
    ${panel("Elon Musk's companies", `<table class="t"><thead><tr><th>Company</th><th>Last 12 months</th><th>Last 5 years</th></tr></thead><tbody>${musk.map((m) => `<tr class="click" data-k="${esc(m.names[0] || m.company)}"><td class="nm wrap"><b>${esc(m.company)}</b><div class="muted small">${m.names.length ? m.names.map((n) => esc(titleCase(n))).join(", ") : "no federal contracts on record"}</div></td><td>${m.year ? money(m.year) : "--"}</td><td>${m.five ? money(m.five) : "--"}</td></tr>`).join("")}</tbody></table>
       <div class="note small">Money newly committed in each period. SpaceX's contracts are mostly NASA (crew and cargo to the space station, the Moon lander) and the Pentagon (launches, Starshield satellites). Starlink service bought through resellers may not show under SpaceX.</div>`, { cls: "c5", src: "click a row for details" })}
    ${panel("Biggest new contracts (last 30 days)", awardTable((d.new || []).slice(0, 25)), { cls: "c7", scroll: true, maxh: 560, src: "$25M and up" })}
    ${panel("Biggest contractors (last 90 days)", `<div class="chart-box xtall"><canvas id="k-top"></canvas></div><div class="note small">Click a bar to look the company up.</div>`, { cls: "c6", flush: false, src: "money committed" })}
    ${panel("Which agencies are spending (last 90 days)", `<div class="chart-box xtall"><canvas id="k-ag"></canvas></div>`, { cls: "c6", flush: false })}
    ${d.errors && d.errors.length ? `<div class="c12">${errBox(d.errors.join("; "))}</div>` : ""}
    </div>`;
  if (top.length) {
    bars("k-top", top.map((r) => titleCase(r.name).slice(0, 34)), [{ label: "Contract money", data: top.map((r) => r.amount), backgroundColor: "#2dd4bf" }], { horizontal: true, legend: false, fmt: money, yfmt: (v) => "$" + big(v) });
    const ch = charts["k-top"];
    if (ch) ch.options.onClick = (e, el) => { if (el && el.length) look(companyName(titleCase(top[el[0].index].name))); };
  }
  const ag = (d.agencies || []).slice(0, 12);
  if (ag.length) bars("k-ag", ag.map((r) => r.name.replace(/^Department of (the )?/, "")), [{ label: "Contract money", data: ag.map((r) => r.amount), backgroundColor: "#5cb3ff" }], { horizontal: true, legend: false, fmt: money, yfmt: (v) => "$" + big(v) });
  async function look(v) {
    v = (v || "").trim();
    if (v.length < 2) return;
    IW.conQ = v; save();
    $("#k-q").value = v;
    $("#k-res").innerHTML = `<div class="loading">Searching USAspending.gov for ${esc(v)}...</div>`;
    const r = await soft(api(`/api/iw/contracts_search?q=${enc(v)}`));
    if (g !== gen) return;
    $("#k-res").innerHTML = contractsBlock(r, { chart: "k-yr" });
    yearChart("k-yr", r);
  }
  $("#k-go").onclick = () => look($("#k-q").value);
  $("#k-q").onkeydown = (e) => { if (e.key === "Enter") look($("#k-q").value); };
  $$("[data-k]").forEach((el) => (el.onclick = () => { look(el.dataset.k); window.scrollTo({ top: 0, behavior: "smooth" }); }));
  if (IW.conQ) look(IW.conQ);
  setStatus("ok", "Contracts");
}

/* ================================================================== ABOUT */
async function about(g) {
  loading("Loading sources...");
  let d, st;
  try { [d, st] = await Promise.all([api("/api/iw/status"), api("/api/iw/settings")]); } catch (e) { return fail(g, e); }
  if (g !== gen) return;
  const byG = {};
  d.sources.forEach((s) => { (byG[s.grp] = byG[s.grp] || []).push(s); });
  PAGE.innerHTML = `<div class="grid">
    ${panel("How it works", `<div class="note">
      <p><b>What this app can show:</b> who publishes what, and when; which stories state media push or avoid; whose wording spreads where; how often state media amplify a given person; and documented money: FARA foreign-agent registrations, lobbying disclosures and FEC political donations.</p>
      <p><b>What it cannot show:</b> secret funding. Overlapping narratives are <b>not evidence</b> that anyone is paid or coordinated. Domestic voices often reach the same conclusions independently, and state media frequently amplify real Americans <i>because</i> those Americans already say things useful to them. Treat the narrative tabs as leads to investigate, and the MONEY tab and court records as the evidence.</p>
      <p><b>Even-handed by design:</b> the same tests apply to every outlet and every person. US government-funded broadcasters are labelled as such, and the donor suggestions on PEOPLE cover both parties.</p>
      <p><b>History:</b> feeds are fetched every 15 minutes while any Market Terminal app is open, and kept for ${120} days in a local archive on this PC. Trend views get better the longer it runs.</p></div>`, { cls: "c7" })}
    ${panel("Settings", `<div class="note">
      <p><b>FEC API key</b> (optional, free from <a href="https://api.data.gov/signup/" target="_blank" rel="noopener">api.data.gov/signup</a>). Without one, donation lookups share the public DEMO_KEY, which allows only a few lookups per hour. The key is saved on this PC only and sent only to api.open.fec.gov.</p>
      <div class="iwbar"><input id="a-key" class="inp wide" style="width:300px;text-transform:none" placeholder="${st.fec_key_set ? "saved: " + esc(st.fec_key_hint) : "paste your api.data.gov key"}"><button class="btn sm primary" id="a-save">SAVE KEY</button>${st.fec_key_set ? `<button class="btn sm" id="a-clear">REMOVE</button>` : ""}</div>
      <p><b>Email for SEC requests</b> (needed for INSIDER TRADES details). The SEC asks apps that download its filings to say who is asking, so this email goes in the header of requests to sec.gov only. It is saved on this PC.</p>
      <div class="iwbar"><input id="a-sec" class="inp wide" style="width:300px;text-transform:none" placeholder="your email" value="${esc(st.sec_contact || "")}"><button class="btn sm primary" id="a-secs">SAVE EMAIL</button>${st.sec_contact ? `<button class="btn sm" id="a-secc">REMOVE</button>` : ""}<span id="a-secm" class="small amber"></span></div>
      <p>${archText(d.archive)}</p></div>`, { cls: "c5" })}
    ${Object.entries(d.groups).map(([k, label]) => panel(`${esc(label)} (${(byG[k] || []).length})`, `<table class="t"><thead><tr><th>Outlet</th><th>Country</th><th>Ownership / funding</th><th>Archived</th><th>Latest</th><th>Status</th></tr></thead><tbody>${(byG[k] || []).map((s) => `<tr>
        <td class="nm">${link(s.url, s.name)}</td><td>${esc(s.cc)}</td><td class="nm wrap small">${esc(s.note)}</td><td>${fmt(s.archived, 0)}</td><td class="muted">${s.latest ? ago(s.latest) : "--"}</td>
        <td class="nm small">${s.ok === true ? "<span class='up'>OK</span>" : s.ok === false ? `<span class="down" title="${esc(s.err)}">FAIL</span>` : "<span class='muted'>pending</span>"}</td></tr>`).join("")}</tbody></table>`, { cls: "c6" })).join("")}
    ${panel("Money data sources", `<div class="note">
      <p><b>FARA</b>: US Department of Justice bulk data (efile.fara.gov): registrants, foreign principals, individual short-form agents, and every filed document as a PDF link. Refreshed daily.</p>
      <p><b>Lobbying</b>: Lobbying Disclosure Act filings through the lda.gov API.</p>
      <p><b>FEC</b>: itemized individual contributions through the OpenFEC API. The app shows the 100 largest per name and you should check employer and city to confirm the person; names can collide. Itemized records only include contributions over $200.</p>
      <p><b>Federal Register</b>: rules and notices mentioning foreign malign influence, FARA, foreign adversaries or disinformation.</p>
      <p><b>Congress trades</b>: House members' Periodic Transaction Reports from the Clerk of the House (disclosures-clerk.house.gov). The app reads each e-filed PDF once and keeps the trades on this PC; scanned paper reports are linked instead. Party and committees come from the public congress-legislators dataset. "Late" means reported more than 45 days after the trade. The Senate's reports sit behind a terms-of-use page, so they aren't collected.</p>
      <p><b>Insider trades</b>: SEC Form 4 filings. The list comes from EDGAR full-text search; buy/sell details come from each filing's XML once you add an email in Settings. Requests are kept under 5 per second, well inside the SEC's limit.</p>
      <p><b>Federal contracts</b>: the USAspending.gov API, the Treasury's official record of federal spending. Contract amounts are money committed, which can be paid out over years. Name searches match any company with those words in its name.</p></div>`, { cls: "c12" })}
    </div>`;
  $("#a-save").onclick = async () => { const v = $("#a-key").value.trim(); if (!v) return; await soft(api(`/api/iw/settings?fec_key=${enc(v)}`)); render(); };
  if ($("#a-clear")) $("#a-clear").onclick = async () => { await soft(api(`/api/iw/settings?fec_key=`)); render(); };
  $("#a-secs").onclick = async () => { const r = await soft(api(`/api/iw/settings?sec_contact=${enc($("#a-sec").value.trim())}`)); if (r.error) $("#a-secm").textContent = r.error; else render(); };
  if ($("#a-secc")) $("#a-secc").onclick = async () => { await soft(api(`/api/iw/settings?sec_contact=`)); render(); };
  setStatus("ok", "Sources");
}

render();
setInterval(() => { if (IW.tab === "wire") softRefresh(); }, 15 * 60 * 1000);

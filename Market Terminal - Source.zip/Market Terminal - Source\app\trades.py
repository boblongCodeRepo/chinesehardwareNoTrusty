"""Influence Watch - "who profits": public records of money moving around power.

  * Congress stock trades: House members' STOCK Act Periodic Transaction Reports (disclosures-clerk.house.gov).
    The Clerk publishes a yearly index (XML) and one PDF per report; e-filed PDFs contain text that we parse into
    trades. Paper (scanned) reports are listed with a link only. Party/committees: unitedstates/congress-legislators.
    (Senate reports sit behind a terms-of-use page on efdsearch.senate.gov, so they are not collected automatically.)
  * Corporate insider trades: SEC Form 4. The filing list comes from EDGAR full-text search (efts.sec.gov). The
    trade details (buy/sell, shares, price) are in each filing's XML on www.sec.gov, and the SEC asks automated tools
    to identify themselves with a contact email - so details load only after the user enters one in Settings.
  * Federal contracts: USAspending.gov API (no key).

Everything is cached in a local SQLite file; filings never change once published, so each is fetched only once.
"""
from __future__ import annotations

import io
import json
import os
import re
import sqlite3
import threading
import time
import xml.etree.ElementTree as ET
import zipfile
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor
from datetime import date, datetime, timedelta
from pathlib import Path

import requests

DATA_DIR = Path(os.environ.get("MT_DATA_DIR") or Path(os.environ.get("LOCALAPPDATA", Path.home())) / "MarketTerminal")
WDIR = DATA_DIR / "influence"
WDIR.mkdir(parents=True, exist_ok=True)
DB = WDIR / "money.db"
SETTINGS = WDIR / "settings.json"

H = requests.Session()
H.headers.update({"User-Agent": "MarketTerminal/1.0 (Influence Watch; local desktop research app)"})
HOUSE_DAYS = 200      # how far back House reports are collected
F4_INDEX_DAYS = 4     # days of Form 4 filings indexed on each sync
F4_KEEP_DAYS = 45


# ------------------------------------------------------------------ small helpers
_DBL = threading.RLock()
_CON = None


def _con():
    global _CON
    if _CON is None:
        c = sqlite3.connect(DB, timeout=30, check_same_thread=False)
        c.execute("PRAGMA journal_mode=WAL")
        c.executescript("""
        CREATE TABLE IF NOT EXISTS h_filing(doc TEXT PRIMARY KEY, year INT, name TEXT, sd TEXT, filed TEXT, kind TEXT, ntx INT, at REAL);
        CREATE TABLE IF NOT EXISTS h_tx(doc TEXT, i INT, owner TEXT, asset TEXT, ticker TEXT, atype TEXT, tx TEXT,
            tdate TEXT, ndate TEXT, lo INT, hi INT, descr TEXT, PRIMARY KEY(doc, i));
        CREATE TABLE IF NOT EXISTS f4(adsh TEXT PRIMARY KEY, fname TEXT, filed TEXT, form TEXT, issuer_cik TEXT, issuer TEXT,
            owner TEXT, parsed INT DEFAULT 0, ticker TEXT, rel TEXT, plan INT DEFAULT 0, err TEXT);
        CREATE TABLE IF NOT EXISTS f4_tx(adsh TEXT, i INT, code TEXT, tdate TEXT, shares REAL, price REAL, ad TEXT,
            after REAL, direct TEXT, security TEXT, PRIMARY KEY(adsh, i));
        CREATE INDEX IF NOT EXISTS f4_filed ON f4(filed);
        CREATE INDEX IF NOT EXISTS f4_issuer ON f4(issuer_cik);
        """)
        _CON = c
    return _CON


def _reset_db(err):
    """A long-lived connection can be left reporting 'database disk image is malformed' (e.g. after another
    process touched the file) even when the file is fine. Reopen; if a fresh connection is also broken, the cache
    really is damaged - move it aside and start a new one (everything in it is re-downloadable)."""
    global _CON
    with _DBL:
        try:
            if _CON is not None:
                _CON.close()
        except Exception:  # noqa: BLE001
            pass
        _CON = None
        try:
            c = sqlite3.connect(DB, timeout=30)
            ok = c.execute("PRAGMA quick_check").fetchone()[0] == "ok"
            c.close()
        except sqlite3.DatabaseError:
            ok = False
        if not ok:
            stamp = time.strftime("%Y%m%d-%H%M%S")
            for suf in ("", "-wal", "-shm"):
                p = Path(str(DB) + suf)
                if p.exists():
                    try:
                        p.replace(Path(str(DB) + f".broken-{stamp}{suf}"))
                    except OSError:
                        pass
            for st in (FS, HS):  # force a fresh sync
                st["last"] = 0.0
        print(f"money.db: {err} - reopened{'' if ok else ' (file was damaged; rebuilt)'}")


def _db_retry(fn):
    try:
        with _DBL:
            return fn(_con())
    except sqlite3.DatabaseError as e:
        if "malformed" not in str(e) and "not a database" not in str(e):
            raise
        _reset_db(e)
        with _DBL:
            return fn(_con())


def _q(sql, args=()):
    return _db_retry(lambda c: c.execute(sql, args).fetchall())


def _x(sql, args=(), many=False):
    def run(c):
        (c.executemany if many else c.execute)(sql, args)
        c.commit()
    return _db_retry(run)


_MEMO, _MLOCKS, _MG = {}, {}, threading.Lock()


def _memo(key, ttl, fn):
    hit = _MEMO.get(key)
    if hit and time.time() - hit[0] < ttl:
        return hit[1]
    with _MG:
        lock = _MLOCKS.setdefault(key, threading.Lock())
    with lock:
        hit = _MEMO.get(key)
        if hit and time.time() - hit[0] < ttl:
            return hit[1]
        v = fn()
        _MEMO[key] = (time.time(), v)
        return v


def _iso(mdy):
    try:
        return datetime.strptime(mdy.strip(), "%m/%d/%Y").date().isoformat()
    except Exception:  # noqa: BLE001
        return ""


def _days(a, b):
    try:
        return (date.fromisoformat(b) - date.fromisoformat(a)).days
    except Exception:  # noqa: BLE001
        return None


def _settings():
    try:
        return json.loads(SETTINGS.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return {}


def sec_contact():
    c = (_settings().get("sec_contact") or "").strip()
    return c if re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", c) else ""


# ================================================================== CONGRESS (House PTRs)
def _house_index(year):
    def load():
        r = H.get(f"https://disclosures-clerk.house.gov/public_disc/financial-pdfs/{year}FD.zip", timeout=60)
        if r.status_code == 404:
            return []
        r.raise_for_status()
        z = zipfile.ZipFile(io.BytesIO(r.content))
        root = ET.fromstring(z.read(f"{year}FD.xml"))
        out = []
        for m in root:
            d = {c.tag: (c.text or "").strip() for c in m}
            if d.get("FilingType") == "P" and d.get("DocID"):
                d["filed"] = _iso(d.get("FilingDate", ""))
                d["year"] = year
                out.append(d)
        return out
    return _memo(("hidx", year), 3 * 3600, load)


def ptr_url(year, doc):
    return f"https://disclosures-clerk.house.gov/public_disc/ptr-pdfs/{year}/{doc}.pdf"


_LABEL = re.compile(r"^(?:[A-Z] ){0,3}[A-Z]:\s")
_PTR_TX = re.compile(r"\[(?P<atype>[A-Z]{2})\]\s*(?P<tx>P|S \(partial\)|S|E)\s+(?P<d1>\d{1,2}/\d{1,2}/\d{4})\s+"
                     r"(?P<d2>\d{1,2}/\d{1,2}/\d{4})\s+(?P<amt>Over \$[\d,]+|\$[\d,]+(?:\s*-\s*\$[\d,]+)?)")
_HDR = re.compile(r"ID\s+Owner\s+Asset\s+Transaction\s+Type\s+Date\s+Notification\s+Date\s+Amount\s+Cap\.\s+Gains\s+>\s+\$200\?")
_TICK = re.compile(r"\(([A-Z][A-Z0-9.\-/]{0,7})\)")
OWNER = {"SP": "spouse", "JT": "joint", "DC": "child"}


def _amount(s):
    nums = [int(x.replace(",", "")) for x in re.findall(r"\$([\d,]+)", s)]
    if not nums:
        return None, None
    if s.startswith("Over"):
        return nums[0], None
    return nums[0], (nums[1] if len(nums) > 1 else nums[0])


def _clean_asset(a):
    a = re.sub(r"\s+", " ", a).strip()
    owner = "self"
    m = re.match(r"^(SP|JT|DC)\s+", a)
    if m:
        owner, a = OWNER[m.group(1)], a[m.end():]
    tk = _TICK.findall(a)
    ticker = tk[-1] if tk else ""
    name = _TICK.sub("", a) if ticker else a
    name = re.sub(r"\s*-?\s*(?:Class [A-C] )?(?:Common|Ordinary|Capital) (?:Stock|Shares)\b.*$", "", name, flags=re.I)
    name = re.sub(r"\s+", " ", name).strip(" -,")
    return owner, name[:140], ticker


def parse_ptr(text):
    """Text of an e-filed House Periodic Transaction Report -> list of trades (None if the layout isn't recognised)."""
    t = text.replace("\x00", "")
    hdr = re.search(r"Gains\s*>\s*\$200\?", t)
    if not hdr:
        return None
    body = t[hdr.end():]
    end = re.search(r"\n\s*\* For the complete list|\n\s*I\s+[VP]\s+[DO]\s*\n", body)
    body = _HDR.sub("\n", body[:end.start()] if end else body)
    parts, after_long_label = [], False
    for line in body.split("\n"):
        ln = line.strip()
        if not ln or re.match(r"Filing ID #|Page \d+ of \d+", ln):
            continue
        if _LABEL.match(ln):
            parts.append("\x01" + ln + "\x02")
            after_long_label = len(ln) >= 90 and ln[:2] in ("D:", "C:")
            continue
        if (after_long_label and not _PTR_TX.search(ln) and not re.search(r"\[[A-Z]{2}\]|\([A-Z][A-Z0-9.]{0,6}\)", ln)
                and not re.match(r"(SP|JT|DC)\s", ln) and (ln[:1].islower() or ln[:1].isdigit())):
            parts[-1] = parts[-1][:-1] + " " + ln + "\x02"   # wrapped description line
            after_long_label = len(ln) >= 90
            continue
        after_long_label = False
        parts.append(ln)
    s = " ".join(parts)
    out, pos = [], 0

    def labels(seg, tx):
        for lab in re.findall("\x01(.*?)\x02", seg):
            k, _, v = lab.partition(":")
            k = k.replace(" ", "")
            if k == "D":
                tx["descr"] = (tx.get("descr", "") + " " + v.strip()).strip()[:300]
            elif k == "SO":
                tx["account"] = v.strip()[:120]

    for m in _PTR_TX.finditer(s):
        seg = s[pos:m.start()]
        if out:
            labels(seg, out[-1])
        asset = seg.rsplit("\x02", 1)[-1]
        owner, name, ticker = _clean_asset(asset)
        lo, hi = _amount(m.group("amt"))
        out.append({"owner": owner, "asset": name, "ticker": ticker, "atype": m.group("atype"),
                    "tx": {"P": "buy", "S": "sell", "S (partial)": "sell (partial)", "E": "exchange"}[m.group("tx")],
                    "tdate": _iso(m.group("d1")), "ndate": _iso(m.group("d2")), "lo": lo, "hi": hi})
        pos = m.end()
    if out:
        labels(s[pos:], out[-1])
    return out


def _ptr_text(b):
    import pypdf  # local import keeps app start-up fast
    return "\n".join((p.extract_text() or "") for p in pypdf.PdfReader(io.BytesIO(b)).pages)


HS = {"busy": False, "done": 0, "todo": 0, "last": 0.0, "err": "", "lock": threading.Lock()}


def _house_fetch(f):
    doc, year = f["DocID"], f["year"]
    name = " ".join(x for x in (f.get("First"), f.get("Last"), f.get("Suffix")) if x)
    row = [doc, year, name, f.get("StateDst", ""), f["filed"]]
    if not doc.startswith("2"):        # scanned paper report: no text to read
        _x("INSERT OR REPLACE INTO h_filing VALUES(?,?,?,?,?,?,?,?)", row + ["paper", 0, time.time()])
        return
    try:
        r = H.get(ptr_url(year, doc), timeout=45)
        r.raise_for_status()
        txs = parse_ptr(_ptr_text(r.content))
    except Exception:  # noqa: BLE001 - retry on the next sync
        return
    if txs is None:
        _x("INSERT OR REPLACE INTO h_filing VALUES(?,?,?,?,?,?,?,?)", row + ["unreadable", 0, time.time()])
        return
    def write(c):
        c.execute("DELETE FROM h_tx WHERE doc=?", (doc,))
        c.executemany("INSERT INTO h_tx VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                      [(doc, i, t["owner"], t["asset"], t["ticker"], t["atype"], t["tx"], t["tdate"], t["ndate"],
                        t["lo"], t["hi"], (t.get("descr", "") + (" | account: " + t["account"] if t.get("account") else "")).strip(" |"))
                       for i, t in enumerate(txs)])
        c.execute("INSERT OR REPLACE INTO h_filing VALUES(?,?,?,?,?,?,?,?)", row + ["e-filed", len(txs), time.time()])
        c.commit()
    _db_retry(write)
    HS["done"] += 1


def _house_sync():
    if not HS["lock"].acquire(blocking=False):
        return
    HS["busy"], HS["err"] = True, ""
    try:
        today = date.today()
        cutoff = (today - timedelta(days=HOUSE_DAYS)).isoformat()
        filings = []
        for y in sorted({today.year, (today - timedelta(days=HOUSE_DAYS)).year}):
            try:
                filings += _house_index(y)
            except Exception as e:  # noqa: BLE001
                HS["err"] = f"House index {y}: {e}"
        known = {r[0] for r in _q("SELECT doc FROM h_filing")}
        todo = [f for f in filings if f["filed"] >= cutoff and f["DocID"] not in known]
        todo.sort(key=lambda f: f["filed"], reverse=True)
        HS["todo"], HS["done"] = len(todo), 0
        with ThreadPoolExecutor(4) as ex:
            list(ex.map(_house_fetch, todo))
        HS["last"] = time.time()
    finally:
        HS["busy"] = False
        HS["lock"].release()


def _kick(state, fn, every):
    if not state["busy"] and time.time() - state["last"] > every:
        state["busy"] = True   # set before the thread starts so callers see "busy" immediately
        threading.Thread(target=lambda: (state.update(busy=False), fn()), daemon=True).start()


def _members():
    """House seat ('TX25') -> name, party, committees (unitedstates/congress-legislators, cached a week)."""
    def load():
        cache = WDIR / "legislators.json"
        try:
            if time.time() - cache.stat().st_mtime < 7 * 86400:
                return json.loads(cache.read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001
            pass
        base = "https://unitedstates.github.io/congress-legislators/"
        try:
            leg = H.get(base + "legislators-current.json", timeout=40).json()
            mem = H.get(base + "committee-membership-current.json", timeout=40).json()
            com = H.get(base + "committees-current.json", timeout=40).json()
        except Exception:  # noqa: BLE001
            try:
                return json.loads(cache.read_text(encoding="utf-8"))
            except Exception:  # noqa: BLE001
                return {}
        cname = {c["thomas_id"]: re.sub(r"^(House |Joint )?Committee on (the )?", "", c["name"]) for c in com}
        bycom = defaultdict(list)
        for cid, people in mem.items():
            if cid in cname:   # full committees only, not subcommittees
                for p in people:
                    bycom[p.get("bioguide")].append(cname[cid] + (f" ({p['title']})" if p.get("title") else ""))
        out = {}
        for p in leg:
            t = p["terms"][-1]
            if t["type"] != "rep":
                continue
            sd = f"{t['state']}{int(t.get('district') or 0):02d}"
            out[sd] = {"name": p["name"].get("official_full") or f"{p['name']['first']} {p['name']['last']}",
                       "last": p["name"]["last"], "party": (t.get("party") or "?")[:1],
                       "committees": bycom.get(p["id"]["bioguide"], [])}
        cache.write_text(json.dumps(out), encoding="utf-8")
        return out
    return _memo(("members",), 6 * 3600, load)


ATYPE = {"ST": "stock", "OP": "option", "EF": "ETF", "MF": "mutual fund", "GS": "government bond", "CS": "corporate bond",
         "OT": "other", "PS": "private stock", "HN": "hedge/private fund", "OI": "private investment", "AB": "asset-backed",
         "CT": "crypto", "RP": "real estate", "PE": "private equity", "FN": "foreign note", "OL": "LLC interest", "IH": "IRA holding",
         "5C": "529 plan", "WU": "whole life insurance", "VA": "variable annuity", "BA": "bank account", "DB": "defined benefit",
         "IC": "investment club", "FA": "farm", "MA": "managed account", "CO": "collectibles", "DS": "deferred stock"}


def _mid(lo, hi):
    if lo is None:
        return 0
    return lo if hi is None else (lo + hi) / 2


def congress(q):
    _kick(HS, _house_sync, 2 * 3600)
    days = max(7, min(int(q.get("days", 90) or 90), HOUSE_DAYS))
    cutoff = (date.today() - timedelta(days=days)).isoformat()
    mem = _members()
    rows = _q("""SELECT t.doc, f.year, f.name, f.sd, f.filed, t.owner, t.asset, t.ticker, t.atype, t.tx, t.tdate, t.ndate,
                        t.lo, t.hi, t.descr FROM h_tx t JOIN h_filing f ON f.doc = t.doc
                 WHERE f.filed >= ? ORDER BY f.filed DESC, t.tdate DESC""", (cutoff,))
    trades = []
    for doc, year, name, sd, filed, owner, asset, ticker, atype, tx, tdate, ndate, lo, hi, descr in rows:
        m = mem.get(sd) or {}
        late = _days(tdate, filed)
        trades.append({"doc": doc, "url": ptr_url(year, doc), "member": m.get("name") or name, "sd": sd, "party": m.get("party", "?"),
                       "owner": owner, "asset": asset, "ticker": ticker, "atype": atype, "kind": ATYPE.get(atype, atype),
                       "tx": tx, "tdate": tdate, "filed": filed, "lo": lo, "hi": hi, "mid": _mid(lo, hi),
                       "late": late if late is not None and late > 45 else 0, "descr": descr or ""})
    tick = defaultdict(lambda: {"buys": 0, "sells": 0, "members": set(), "mid": 0.0, "asset": "", "D": set(), "R": set()})
    for t in trades:
        if not t["ticker"] or t["atype"] not in ("ST", "OP", "EF"):
            continue
        k = tick[t["ticker"]]
        if t["tx"] == "buy":
            k["buys"] += 1
        elif t["tx"].startswith("sell"):
            k["sells"] += 1
        k["members"].add(t["member"])
        if t["party"] in ("D", "R"):
            k[t["party"]].add(t["member"])
        k["mid"] += t["mid"]
        k["asset"] = k["asset"] or t["asset"]
    tickers = sorted(({"ticker": tk, "asset": v["asset"], "buys": v["buys"], "sells": v["sells"], "members": len(v["members"]),
                       "dem": len(v["D"]), "rep": len(v["R"]), "est": v["mid"]} for tk, v in tick.items()),
                     key=lambda x: (-x["members"], -(x["buys"] + x["sells"])))
    mb = defaultdict(lambda: {"n": 0, "buys": 0, "sells": 0, "est": 0.0, "late": 0, "party": "?", "sd": "", "last": ""})
    for t in trades:
        v = mb[t["member"]]
        v["n"] += 1
        v["buys"] += t["tx"] == "buy"
        v["sells"] += t["tx"].startswith("sell")
        v["est"] += t["mid"]
        v["late"] += bool(t["late"])
        v["party"], v["sd"] = t["party"], t["sd"]
        v["last"] = max(v["last"], t["filed"])
    members = sorted(({"member": k, **v, "committees": (mem.get(v["sd"]) or {}).get("committees", [])} for k, v in mb.items()),
                     key=lambda x: -x["n"])
    paper = [{"member": (mem.get(r[2]) or {}).get("name") or r[1], "sd": r[2], "filed": r[3], "url": ptr_url(r[4], r[0])}
             for r in _q("SELECT doc, name, sd, filed, year FROM h_filing WHERE kind != 'e-filed' AND filed >= ? ORDER BY filed DESC", (cutoff,))]
    nfil = _q("SELECT COUNT(*) FROM h_filing WHERE filed >= ?", (cutoff,))[0][0]
    return {"days": days, "trades": trades, "tickers": tickers[:60], "members": members, "paper": paper, "reports": nfil,
            "committees": {m["name"]: m["committees"] for m in mem.values()},
            "status": {"busy": HS["busy"], "done": HS["done"], "todo": HS["todo"], "last": HS["last"], "err": HS["err"]}}


# ================================================================== INSIDERS (SEC Form 4)
EFTS = "https://efts.sec.gov/LATEST/search-index"
_SEC_PACE = threading.Lock()
_SEC_LAST = [0.0]


def _sec_get(url, params=None, timeout=30):
    """All SEC traffic: <= 5 requests/second, identified by the user's contact email when set."""
    c = sec_contact()
    ua = f"MarketTerminal InfluenceWatch/1.0 {c}" if c else "MarketTerminal InfluenceWatch/1.0 personal research tool"
    with _SEC_PACE:
        wait = 0.2 - (time.time() - _SEC_LAST[0])
        if wait > 0:
            time.sleep(wait)
        _SEC_LAST[0] = time.time()
    r = requests.get(url, params=params, headers={"User-Agent": ua, "Accept-Encoding": "gzip, deflate"}, timeout=timeout)
    if r.status_code == 403:
        raise RuntimeError("SEC refused the request (403). Check the contact email in HOW IT WORKS > Settings.")
    r.raise_for_status()
    return r


def _hit_row(h):
    s = h["_source"]
    adsh, _, fname = h["_id"].partition(":")
    ciks, names = s.get("ciks") or [], s.get("display_names") or []
    locs = s.get("biz_locations") or []
    inc = s.get("inc_states") or []
    # the issuer is the entity with a business location / state of incorporation; insiders (people) have neither
    iss = next((i for i in range(len(ciks)) if (i < len(locs) and locs[i]) or (i < len(inc) and inc[i])), len(ciks) - 1)
    clean = [re.sub(r"\s*\(CIK \d+\)\s*$", "", n).strip() for n in names]
    issuer = clean[iss] if 0 <= iss < len(clean) else ""
    tk = re.search(r"\(([A-Z0-9.\-, ]+)\)\s*$", issuer)
    owners = [n for i, n in enumerate(clean) if i != iss]
    return {"adsh": adsh, "fname": fname, "filed": s.get("file_date", ""), "form": s.get("form", "4"),
            "issuer_cik": (ciks[iss] if 0 <= iss < len(ciks) else "").lstrip("0"),
            "issuer": re.sub(r"\s*\([A-Z0-9.\-, ]+\)\s*$", "", issuer), "ticker": tk.group(1).split(",")[0].strip() if tk else "",
            "owner": "; ".join(owners)}


def _efts(params, max_pages=25):
    rows, start = [], 0
    while True:
        j = _sec_get(EFTS, params={**params, "from": start}).json()
        hits = j.get("hits", {}).get("hits", [])
        rows += [_hit_row(h) for h in hits]
        total = j.get("hits", {}).get("total", {}).get("value", 0)
        start += len(hits)
        if not hits or start >= total or start >= max_pages * 100:
            return rows, total


def _store_index(rows):
    _x("""INSERT OR IGNORE INTO f4(adsh, fname, filed, form, issuer_cik, issuer, owner, ticker) VALUES(?,?,?,?,?,?,?,?)""",
       [(r["adsh"], r["fname"], r["filed"], r["form"], r["issuer_cik"], r["issuer"], r["owner"], r["ticker"]) for r in rows], many=True)


def f4_url(cik, adsh):
    return f"https://www.sec.gov/Archives/edgar/data/{cik}/{adsh.replace('-', '')}/{adsh}-index.htm"


def _v(el, path):
    x = el.find(path)
    if x is None:
        return ""
    v = x.find("value")
    return ((v.text if v is not None else x.text) or "").strip()


def _num(s):
    try:
        return float(s.replace(",", ""))
    except Exception:  # noqa: BLE001
        return None


def parse_f4(xml_bytes):
    root = ET.fromstring(xml_bytes)
    owners = root.findall("reportingOwner")
    names = [_v(o, "reportingOwnerId/rptOwnerName") for o in owners]
    rel = []
    if owners:
        r = owners[0].find("reportingOwnerRelationship")
        yes = lambda tag: r is not None and _v(r, tag).lower() in ("1", "true")  # noqa: E731
        if yes("isOfficer"):
            rel.append(_v(r, "officerTitle") or "Officer")
        if yes("isDirector"):
            rel.append("Director")
        if yes("isTenPercentOwner"):
            rel.append("10% owner")
        if yes("isOther"):
            rel.append(_v(r, "otherText") or "Other")
    foot = " ".join((f.text or "") for f in root.iter("footnote"))
    plan = _v(root, "aff10b5One").lower() in ("1", "true") or bool(re.search(r"10b5-?1", foot, re.I))
    txs = []
    for t in root.findall("nonDerivativeTable/nonDerivativeTransaction"):
        txs.append({"code": _v(t, "transactionCoding/transactionCode"), "tdate": _v(t, "transactionDate")[:10],
                    "shares": _num(_v(t, "transactionAmounts/transactionShares")),
                    "price": _num(_v(t, "transactionAmounts/transactionPricePerShare")),
                    "ad": _v(t, "transactionAmounts/transactionAcquiredDisposedCode"),
                    "after": _num(_v(t, "postTransactionAmounts/sharesOwnedFollowingTransaction")),
                    "direct": _v(t, "ownershipNature/directOrIndirectOwnership"), "security": _v(t, "securityTitle")[:80]})
    return {"issuer": _v(root, "issuer/issuerName"), "ticker": _v(root, "issuer/issuerTradingSymbol").upper(),
            "owner": "; ".join(n for n in names if n), "rel": ", ".join(rel), "plan": plan, "txs": txs}


def _f4_fetch(adsh, fname, cik):
    try:
        r = _sec_get(f"https://www.sec.gov/Archives/edgar/data/{cik}/{adsh.replace('-', '')}/{fname}")
        p = parse_f4(r.content)
    except Exception as e:  # noqa: BLE001
        msg = str(e)[:200]
        _x("UPDATE f4 SET parsed=-1, err=? WHERE adsh=?", (msg, adsh))
        if "403" in msg:
            raise
        return
    def write(c):
        c.execute("DELETE FROM f4_tx WHERE adsh=?", (adsh,))
        c.executemany("INSERT INTO f4_tx VALUES(?,?,?,?,?,?,?,?,?,?)",
                      [(adsh, i, t["code"], t["tdate"], t["shares"], t["price"], t["ad"], t["after"], t["direct"], t["security"])
                       for i, t in enumerate(p["txs"])])
        c.execute("""UPDATE f4 SET parsed=1, err=NULL, rel=?, plan=?, owner=COALESCE(NULLIF(?, ''), owner),
                     ticker=COALESCE(NULLIF(?, ''), ticker), issuer=COALESCE(NULLIF(?, ''), issuer) WHERE adsh=?""",
                  (p["rel"], int(p["plan"]), p["owner"], p["ticker"], p["issuer"], adsh))
        c.commit()
    _db_retry(write)


FS ={"busy": False, "done": 0, "todo": 0, "last": 0.0, "err": "", "indexed": 0, "lock": threading.Lock()}


def _f4_details(rows):
    """Fetch XML for (adsh, fname, cik) rows, newest first; stops early on a 403."""
    FS["todo"], FS["done"] = len(rows), 0
    for adsh, fname, cik in rows:
        try:
            _f4_fetch(adsh, fname, cik)
        except Exception as e:  # noqa: BLE001
            FS["err"] = str(e)
            if "403" in str(e):  # SEC refused us: stop; anything else, skip this filing and keep going
                return
        FS["done"] += 1


def _f4_sync():
    if not FS["lock"].acquire(blocking=False):
        return
    FS["busy"], FS["err"] = True, ""
    try:
        end = date.today()
        start = end - timedelta(days=F4_INDEX_DAYS)
        try:
            rows, total = _efts({"forms": "4", "dateRange": "custom", "startdt": start.isoformat(), "enddt": end.isoformat()}, max_pages=40)
            _store_index(rows)
            FS["indexed"] = total
        except Exception as e:  # noqa: BLE001
            FS["err"] = f"SEC filing list: {e}"
        if sec_contact():
            todo = _q("SELECT adsh, fname, issuer_cik FROM f4 WHERE parsed=0 AND filed >= ? ORDER BY filed DESC",
                      ((end - timedelta(days=F4_INDEX_DAYS)).isoformat(),))
            _f4_details(todo)
        FS["last"] = time.time()
    finally:
        FS["busy"] = False
        FS["lock"].release()


CODES = {"P": "open-market buy", "S": "open-market sale", "A": "award/grant", "M": "option exercise", "F": "tax withholding",
         "G": "gift", "D": "returned to company", "C": "conversion", "X": "option exercise", "J": "other", "W": "inheritance"}


def _f4_rows(where, args):
    """Parsed Form 4 filings + their trades, summarised per filing (one row per filing and buy/sell side)."""
    rows = _q(f"""SELECT f.adsh, f.filed, f.issuer_cik, f.issuer, f.ticker, f.owner, f.rel, f.plan,
                        t.code, t.tdate, t.shares, t.price, t.after
                 FROM f4 f JOIN f4_tx t ON t.adsh = f.adsh WHERE f.parsed = 1 AND t.code IN ('P','S') AND {where}""", args)
    agg = {}
    for adsh, filed, cik, issuer, ticker, owner, rel, plan, code, tdate, shares, price, after in rows:
        k = (adsh, code)
        a = agg.setdefault(k, {"adsh": adsh, "url": f4_url(cik, adsh), "filed": filed, "cik": cik, "issuer": issuer,
                               "ticker": ticker, "owner": owner, "rel": rel or "", "plan": bool(plan),
                               "side": "buy" if code == "P" else "sell", "shares": 0.0, "value": 0.0, "after": None,
                               "first": tdate, "last": tdate})
        a["shares"] += shares or 0
        a["value"] += (shares or 0) * (price or 0)
        a["after"] = after if after is not None else a["after"]
        a["first"], a["last"] = min(a["first"], tdate or a["first"]), max(a["last"], tdate or a["last"])
    out = list(agg.values())
    for a in out:
        a["price"] = a["value"] / a["shares"] if a["shares"] else None
        before = (a["after"] or 0) - a["shares"] if a["side"] == "buy" else (a["after"] or 0) + a["shares"]
        a["pct"] = (100 * a["shares"] / before) if before and before > 0 else None   # % change in their holding
    return out


def insiders(q):
    _kick(FS, _f4_sync, 30 * 60)
    days = max(1, min(int(q.get("days", 7) or 7), F4_KEEP_DAYS))
    cutoff = (date.today() - timedelta(days=days)).isoformat()
    contact = bool(sec_contact())
    trades = _f4_rows("f.filed >= ?", (cutoff,)) if contact else []
    buys = sorted((t for t in trades if t["side"] == "buy"), key=lambda t: -t["value"])
    sells = sorted((t for t in trades if t["side"] == "sell"), key=lambda t: -t["value"])
    grp = defaultdict(list)
    for t in buys:
        grp[t["cik"]].append(t)
    clusters = sorted(({"issuer": v[0]["issuer"], "ticker": v[0]["ticker"], "cik": k, "insiders": len({t["owner"] for t in v}),
                        "value": sum(t["value"] for t in v), "people": sorted({f"{t['owner']} ({t['rel']})" if t["rel"] else t["owner"] for t in v}),
                        "last": max(t["filed"] for t in v)} for k, v in grp.items() if len({t["owner"] for t in v}) >= 2),
                      key=lambda c: (-c["insiders"], -c["value"]))
    recent = [{"adsh": r[0], "filed": r[1], "issuer": r[2], "ticker": r[3], "owner": r[4], "url": f4_url(r[5], r[0]), "form": r[6]}
              for r in _q("SELECT adsh, filed, issuer, ticker, owner, issuer_cik, form FROM f4 WHERE filed >= ? ORDER BY filed DESC, adsh DESC LIMIT 300", (cutoff,))]
    counts = dict(_q("SELECT parsed, COUNT(*) FROM f4 WHERE filed >= ? GROUP BY parsed", (cutoff,)))
    return {"days": days, "contact": contact, "buys": buys[:150], "sells": sells[:150], "clusters": clusters[:40], "recent": recent,
            "filings": sum(counts.values()), "parsed": counts.get(1, 0), "pending": counts.get(0, 0),
            "status": {k: FS[k] for k in ("busy", "done", "todo", "last", "err", "indexed")}}


def _entity(qs):
    """Company name or ticker -> (cik, name, ticker) via EDGAR's company search box."""
    j = _sec_get(EFTS, params={"keysTyped": qs}).json()
    hits = j.get("hits", {}).get("hits", [])
    if not hits:
        return None
    s = hits[0]["_source"]
    return {"cik": hits[0]["_id"], "name": re.sub(r"\s*\([A-Z0-9.\-, ]+\)\s*$", "", s.get("entity", "")), "ticker": (s.get("tickers") or "").split(",")[0]}


def insider_company(q):
    name = (q.get("q") or "").strip()
    if not name:
        return {"error": "Type a company name or ticker"}

    def load():
        e = _entity(name)
        if not e:
            return {"found": False, "q": name}
        start = (date.today() - timedelta(days=365)).isoformat()
        rows, total = _efts({"forms": "4", "ciks": e["cik"].zfill(10), "dateRange": "custom", "startdt": start,
                             "enddt": date.today().isoformat()}, max_pages=3)
        rows = [r for r in rows if r["issuer_cik"] == e["cik"].lstrip("0")] or rows
        _store_index(rows)
        return {"found": True, **e, "total": total}
    try:
        e = _memo(("ent", name.lower()), 3600, load)
    except Exception as ex:  # noqa: BLE001
        return {"error": str(ex)}
    if not e.get("found"):
        return {"found": False, "q": name}
    cik = e["cik"].lstrip("0")
    contact = bool(sec_contact())
    if contact:
        todo = _q("SELECT adsh, fname, issuer_cik FROM f4 WHERE issuer_cik=? AND parsed=0 ORDER BY filed DESC LIMIT 80", (cik,))
        if todo:
            for adsh, fname, c in todo:
                try:
                    _f4_fetch(adsh, fname, c)
                except Exception as ex:  # noqa: BLE001
                    return {"found": True, **e, "contact": contact, "error": str(ex), "trades": [], "filings": []}
    start = (date.today() - timedelta(days=365)).isoformat()
    trades = sorted(_f4_rows("f.issuer_cik = ? AND f.filed >= ?", (cik, start)), key=lambda t: t["last"], reverse=True) if contact else []
    filings = [{"filed": r[0], "owner": r[1], "url": f4_url(cik, r[2]), "form": r[3]}
               for r in _q("SELECT filed, owner, adsh, form FROM f4 WHERE issuer_cik=? AND filed >= ? ORDER BY filed DESC", (cik, start))]
    who = defaultdict(lambda: {"buy": 0.0, "sell": 0.0, "rel": ""})
    for t in trades:
        who[t["owner"]][t["side"]] += t["value"]
        who[t["owner"]]["rel"] = who[t["owner"]]["rel"] or t["rel"]
    return {"found": True, **e, "contact": contact, "trades": trades, "filings": filings,
            "bought": sum(t["value"] for t in trades if t["side"] == "buy"), "sold": sum(t["value"] for t in trades if t["side"] == "sell"),
            "planned_sold": sum(t["value"] for t in trades if t["side"] == "sell" and t["plan"]),
            "people": sorted(({"owner": k, **v} for k, v in who.items()), key=lambda x: -(x["buy"] + x["sell"]))}


# ================================================================== FEDERAL CONTRACTS (USAspending.gov)
USA = "https://api.usaspending.gov/api/v2"
CONTRACT_TYPES = ["A", "B", "C", "D"]
# (label, USAspending search text, regex the recipient name must match - search text alone also returns unrelated
#  firms such as "Tesla Laboratories" or "Mack Boring & Parts")
MUSK = [("SpaceX (incl. Starlink)", "Space Exploration Technologies", r"^SPACE EXPLORATION TECHNOLOGIES|^STARLINK (SERVICES|USA)"),
        ("Tesla", "Tesla", r"^TESLA,? INC\b|^TESLA MOTORS|^TESLA \(THAILAND\)|^MAXWELL TECHNOLOGIES"),
        ("xAI", "X.AI", r"^X\.?AI\b"), ("The Boring Company", "Boring Company", r"^(THE )?BORING COMPANY"),
        ("Neuralink", "Neuralink", r"^NEURALINK")]


def _usa(path, body):
    r = H.post(USA + path, json=body, timeout=60)
    if not r.ok:
        try:
            msg = r.json().get("detail") or r.text[:200]
        except Exception:  # noqa: BLE001
            msg = r.text[:200]
        raise RuntimeError(f"USAspending: {msg}")
    return r.json()


def _period(days):
    end = date.today()
    return [{"start_date": max(date(2007, 10, 1), end - timedelta(days=days)).isoformat(), "end_date": end.isoformat()}]


_AWARD_FIELDS = ["Award ID", "Recipient Name", "Award Amount", "Total Outlays", "Awarding Agency", "Awarding Sub Agency",
                 "Start Date", "End Date", "Description", "generated_internal_id"]


def _award(x):
    d = re.sub(r"^IGF::\w+::IGF\s*", "", x.get("Description") or "").strip()
    return {"id": x.get("Award ID"), "recipient": x.get("Recipient Name"), "amount": x.get("Award Amount"),
            "outlays": x.get("Total Outlays"), "agency": x.get("Awarding Agency"), "sub": x.get("Awarding Sub Agency"),
            "start": x.get("Start Date"), "end": x.get("End Date"), "descr": (d[:260] + "...") if len(d) > 260 else d,
            "url": f"https://www.usaspending.gov/award/{x.get('generated_internal_id')}" if x.get("generated_internal_id") else ""}


def _recipients(text, days, limit=10):
    f = {"time_period": _period(days), "award_type_codes": CONTRACT_TYPES}
    if text:
        f["recipient_search_text"] = [text]
    j = _usa("/search/spending_by_category/recipient/", {"filters": f, "limit": limit, "page": 1})
    return [{"name": r.get("name"), "amount": r.get("amount") or 0} for r in j.get("results", [])]


def contracts(q):
    def load():
        out = {"errors": []}
        jobs = {
            "top": lambda: _recipients("", 90, 25),
            "new": lambda: [_award(x) for x in _usa("/search/spending_by_award/", {
                "filters": {"time_period": [{**_period(30)[0], "date_type": "new_awards_only"}], "award_type_codes": CONTRACT_TYPES,
                            "award_amounts": [{"lower_bound": 25_000_000}]},
                "fields": _AWARD_FIELDS, "sort": "Award Amount", "order": "desc", "limit": 40, "page": 1}).get("results", [])],
            "agencies": lambda: [{"name": r.get("name"), "amount": r.get("amount") or 0} for r in _usa(
                "/search/spending_by_category/awarding_agency/", {"filters": {"time_period": _period(90), "award_type_codes": CONTRACT_TYPES},
                                                                   "limit": 15, "page": 1}).get("results", [])],
        }
        for label, term, rx in MUSK:
            keep = re.compile(rx)
            jobs["musk:" + label] = (lambda term=term, keep=keep: tuple(
                [r for r in _recipients(term, days, 25) if keep.search(r["name"] or "")] for days in (365, 365 * 5)))
        with ThreadPoolExecutor(6) as ex:
            futs = {k: ex.submit(fn) for k, fn in jobs.items()}
        musk = []
        for k, f in futs.items():
            try:
                v = f.result()
            except Exception as e:  # noqa: BLE001
                out["errors"].append(f"{k}: {e}")
                continue
            if k.startswith("musk:"):
                y1, y5 = v
                musk.append({"company": k[5:], "names": sorted({r["name"].rstrip(".") for r in y5}), "year": sum(r["amount"] for r in y1),
                             "five": sum(r["amount"] for r in y5)})
            else:
                out[k] = v
        order = [m[0] for m in MUSK]
        out["musk"] = sorted(musk, key=lambda m: order.index(m["company"]))
        out["asof"] = time.time()
        return out
    return _memo(("contracts",), 6 * 3600, load)


def contracts_search(q):
    name = (q.get("q") or "").strip()
    if len(name) < 2:
        return {"error": "Type a company name"}
    years = max(1, min(int(q.get("years", 5) or 5), 15))

    def load():
        f = {"time_period": _period(365 * years), "award_type_codes": CONTRACT_TYPES, "recipient_search_text": [name]}
        jobs = {
            "recipients": lambda: _recipients(name, 365 * years, 10),
            "awards": lambda: [_award(x) for x in _usa("/search/spending_by_award/", {
                "filters": f, "fields": _AWARD_FIELDS, "sort": "Award Amount", "order": "desc", "limit": 30, "page": 1}).get("results", [])],
            "agencies": lambda: [{"name": r.get("name"), "amount": r.get("amount") or 0} for r in _usa(
                "/search/spending_by_category/awarding_agency/", {"filters": f, "limit": 10, "page": 1}).get("results", [])],
            "years": lambda: [{"fy": r["time_period"].get("fiscal_year"), "amount": r.get("aggregated_amount") or 0} for r in _usa(
                "/search/spending_over_time/", {"group": "fiscal_year", "filters": f}).get("results", [])],
        }
        out = {"q": name, "years_back": years, "errors": []}
        with ThreadPoolExecutor(4) as ex:
            futs = {k: ex.submit(fn) for k, fn in jobs.items()}
        for k, fu in futs.items():
            try:
                out[k] = fu.result()
            except Exception as e:  # noqa: BLE001
                out[k] = []
                out["errors"].append(str(e))
        out["total"] = sum(r["amount"] for r in out.get("recipients", []))
        out["link"] = "https://www.usaspending.gov/search"
        return out
    return _memo(("csearch", name.lower(), years), 6 * 3600, load)


# ================================================================== briefing helpers
def highlights(q):
    """Small summary for the TODAY tab (never blocks on slow syncs)."""
    out = {}
    try:
        c = congress({"days": 30})
        big = sorted((t for t in c["trades"] if t["atype"] in ("ST", "OP", "EF") and t["ticker"]), key=lambda t: (-t["mid"], t["filed"]))
        seen, pick = set(), []
        for t in big:   # each member's single biggest trade, so one busy trader doesn't fill the list
            if t["member"] not in seen:
                seen.add(t["member"])
                pick.append(t)
        out["congress"] = {"trades": pick[:6], "n": len(c["trades"]), "members": len(c["members"]),
                           "late": sum(1 for t in c["trades"] if t["late"]), "busy": c["status"]["busy"]}
    except Exception as e:  # noqa: BLE001
        out["congress"] = {"error": str(e)}
    try:
        i = insiders({"days": 7})
        out["insiders"] = {"buys": i["buys"][:5], "clusters": i["clusters"][:3], "contact": i["contact"], "filings": i["filings"]}
    except Exception as e:  # noqa: BLE001
        out["insiders"] = {"error": str(e)}
    hit = _MEMO.get(("contracts",))
    if hit:
        out["contracts"] = {"new": hit[1].get("new", [])[:5]}
    else:
        threading.Thread(target=lambda: contracts({}), daemon=True).start()
        out["contracts"] = {"loading": True}
    return out

/* Auction Finder - police, government-surplus and local auctions, ranked for what might be interesting */
"use strict";
const PAGE = $("#page");
const SOURCES = ["PropertyRoom", "GSA", "Public Surplus", "HiBid"];
const AS = Object.assign({ tab: "cars", q: "", srcs: SOURCES.slice(), states: "", maxp: "", within: "any", minScore: 0, hideRisk: false,
  sort: "score", view: "cards" }, store("auc.state") || {});
const saveA = () => store("auc.state", AS);
{ const t = location.hash.replace(/^#\/?/, ""); if (t) AS.tab = t; }
let gen = 0, timer = null, LAST = null;

function go(tab) { AS.tab = tab; saveA(); render(); }
$("#tabs").onclick = (e) => { const b = e.target.closest("button[data-tab]"); if (b) go(b.dataset.tab); };
const cmd = $("#cmd");
const submit = () => { AS.q = cmd.value.trim(); saveA(); go("search"); };
cmd.onkeydown = (e) => { if (e.key === "Enter") submit(); };
$(".cmd-go").onclick = submit;
cmd.value = AS.q || "";

function render() {
  gen++;
  clearInterval(timer);
  $$("#tabs button").forEach((b) => b.classList.toggle("active", b.dataset.tab === AS.tab));
  if (AS.tab === "watch") return watching(gen);
  if (AS.tab === "about") return about();
  return results(gen);
}

/* ------------------------------------------------------------------ helpers */
const safeUrl = (u) => (/^https:\/\//i.test(u || "") ? u : "#");
const usd = (v) => (isNum(v) ? "$" + (v >= 1000 ? fmt(v, 0) : fmt(v, v % 1 ? 2 : 0)) : "--");
function left(ends) {
  if (!ends) return "";
  const s = ends - Date.now() / 1000;
  if (s <= 0) return "ended";
  if (s < 3600) return Math.round(s / 60) + "m";
  if (s < 86400) return fmt(s / 3600, 0) + "h " + Math.round((s % 3600) / 60) + "m";
  return Math.floor(s / 86400) + "d " + Math.round((s % 86400) / 3600) + "h";
}
const SRC_C = { PropertyRoom: "#5cb3ff", GSA: "#34d27b", "Public Surplus": "#2dd4bf", HiBid: "#ffa028" };
const srcTag = (s) => `<span class="stag" style="--c:${SRC_C[s] || "#8b8b92"}">${esc(s)}</span>`;
const scoreCls = (s) => (s >= 75 ? "sc-hi" : s >= 60 ? "sc-md" : "sc-lo");
const watchMap = () => store("auc.watch") || {};
function toggleWatch(it) {
  const w = watchMap();
  if (w[it.id]) delete w[it.id]; else w[it.id] = { ...it, saved: Date.now() / 1000 };
  store("auc.watch", w);
}
function card(it, isNew, w) {
  const loc = [it.city, it.state].filter(Boolean).join(", ");
  return `<div class="acard ${it.risk.length ? "risky" : ""}">
    <a class="aimg" href="${esc(safeUrl(it.url))}" target="_blank" rel="noopener">${it.img ? `<img loading="lazy" src="${esc(safeUrl(it.img))}" alt="" referrerpolicy="no-referrer">` : `<span class="muted">no photo</span>`}</a>
    <div class="abody">
      <div class="atop"><span class="ascore ${scoreCls(it.score)}" title="Interest score (0-100)">${it.score}</span>${srcTag(it.src)}${isNew ? `<span class="stag" style="--c:#f472b6">NEW</span>` : ""}
        <button class="star ${w[it.id] ? "on" : ""}" data-star="${esc(it.id)}" title="Watch this lot">&#9733;</button></div>
      <a class="atitle" href="${esc(safeUrl(it.url))}" target="_blank" rel="noopener">${esc(it.title)}</a>
      <div class="ameta"><b>${usd(it.price)}</b>${it.bids != null ? ` &middot; ${it.bids} bid${it.bids === 1 ? "" : "s"}` : ""}${it.buynow ? ` &middot; buy now ${usd(it.buynow)}` : ""}
        ${it.ends ? ` &middot; <span class="${it.ends - Date.now() / 1000 < 86400 ? "amber" : ""}">${left(it.ends)} left</span>` : ""}</div>
      <div class="ameta muted">${esc(loc || "location on listing")} &middot; ${esc(it.seller || "")}</div>
      <div class="atags">${it.why.map((x) => `<span class="why">${esc(x)}</span>`).join("")}${it.risk.map((x) => `<span class="risk">${esc(x)}</span>`).join("")}</div>
      ${it.snip ? `<div class="asnip">${esc(it.snip)}</div>` : ""}
    </div></div>`;
}
function rowHTML(it, isNew, w) {
  return `<tr><td><span class="ascore ${scoreCls(it.score)}">${it.score}</span></td><td>${srcTag(it.src)}</td>
    <td class="l wrap"><a href="${esc(safeUrl(it.url))}" target="_blank" rel="noopener">${esc(it.title)}</a>${isNew ? ` <span class="stag" style="--c:#f472b6">NEW</span>` : ""}
      <div class="atags">${it.why.map((x) => `<span class="why">${esc(x)}</span>`).join("")}${it.risk.map((x) => `<span class="risk">${esc(x)}</span>`).join("")}</div></td>
    <td><b>${usd(it.price)}</b></td><td>${it.bids ?? "--"}</td><td class="${it.ends && it.ends - Date.now() / 1000 < 86400 ? "amber" : ""}">${left(it.ends)}</td>
    <td>${esc(it.state || "")}</td><td><button class="star ${w[it.id] ? "on" : ""}" data-star="${esc(it.id)}">&#9733;</button></td></tr>`;
}
function bindStars(items) {
  const byId = Object.fromEntries(items.map((i) => [i.id, i]));
  $$("[data-star]").forEach((b) => (b.onclick = (e) => {
    e.preventDefault();
    const it = byId[b.dataset.star] || watchMap()[b.dataset.star];
    if (it) { toggleWatch(it); b.classList.toggle("on"); }
  }));
}

/* ================================================================== RESULTS (category tabs + search) */
async function results(g) {
  const isSearch = AS.tab === "search";
  if (isSearch && !AS.q) {
    PAGE.innerHTML = `<div class="grid">${panel("Search every auction site", `<div class="desc note" style="padding:12px">Type what you're after in the box at the top (e.g. <b>corvette</b>, <b>macbook pro</b>, <b>sterling silver</b>, <b>morgan dollar</b>, <b>snap-on</b>) and press Enter.
      It searches PropertyRoom (police), GSA (federal surplus), Public Surplus (city / county / school) and HiBid (local and estate auctioneers) at once.</div>`, { cls: "c12" })}</div>`;
    return;
  }
  const what = isSearch ? `"${AS.q}"` : $(`#tabs button[data-tab="${AS.tab}"]`).textContent.trim();
  setStatus("busy", "Searching 4 auction sites...");
  PAGE.innerHTML = `<div class="loading">Searching PropertyRoom, GSA Auctions, Public Surplus and HiBid for ${esc(what)}...</div>`;
  const qs = isSearch ? `q=${enc(AS.q)}` : `profile=${enc(AS.tab)}`;
  const d = await soft(api(`/api/auc/search?${qs}&sources=${enc(AS.srcs.join(","))}`));
  if (g !== gen) return;
  if (d.error) { PAGE.innerHTML = errBox(d.error); setStatus("err", "Error"); return; }
  LAST = d;
  /* NEW since last visit to this tab */
  const seenKey = "auc.seen." + (isSearch ? "q:" + AS.q.toLowerCase() : AS.tab);
  const seen = new Set(store(seenKey) || []);
  const firstVisit = !seen.size;
  store(seenKey, d.items.map((i) => i.id).slice(0, 3000));
  const isNew = (it) => !firstVisit && !seen.has(it.id);
  const okSrc = Object.entries(d.status).map(([s, st]) => `<span class="chip" title="${esc(st.error || "")}">${srcTag(s)} ${st.ok ? `${st.n} lots` : `<span class="down">failed</span>`}</span>`).join(" ");
  const stateOpts = d.states.slice(0, 60).map(([s, n]) => `${s} (${n})`).join(", ");
  PAGE.innerHTML = `<div class="grid">
    ${panel(`${esc(what)} <span class="muted">${d.total} open lots &middot; ${d.secs}s</span>`, `<div class="aucbar">
        <span class="srcs">${SOURCES.map((s) => `<label><input type="checkbox" data-src="${esc(s)}" ${AS.srcs.includes(s) ? "checked" : ""}> ${esc(s)}</label>`).join("")}</span>
        <label>States <input id="f-st" class="inp" value="${esc(AS.states)}" placeholder="e.g. TX,OK" title="Comma-separated 2-letter codes. Found: ${esc(stateOpts)}" spellcheck="false"></label>
        <label>Max price <input id="f-mp" class="inp" value="${esc(AS.maxp)}" placeholder="$" size="7"></label>
        <label>Ends within <select id="f-w">${[["any", "any time"], ["6", "6 hours"], ["24", "24 hours"], ["72", "3 days"], ["168", "7 days"]].map(([v, l]) => `<option value="${v}" ${AS.within === v ? "selected" : ""}>${l}</option>`).join("")}</select></label>
        <label>Min score <select id="f-ms">${[0, 50, 60, 70, 80].map((v) => `<option value="${v}" ${+AS.minScore === v ? "selected" : ""}>${v || "any"}</option>`).join("")}</select></label>
        <label class="cb"><input type="checkbox" id="f-hr" ${AS.hideRisk ? "checked" : ""}> hide risky</label>
        <label>Sort <select id="f-so">${[["score", "Most interesting"], ["ending", "Ending soonest"], ["price", "Lowest price"], ["bids", "Fewest bids"], ["new", "New since last visit"]].map(([v, l]) => `<option value="${v}" ${AS.sort === v ? "selected" : ""}>${l}</option>`).join("")}</select></label>
        ${segHTML("f-v", [["cards", "CARDS"], ["table", "TABLE"]], AS.view)}
        <button class="btn sm" id="csv">CSV</button>
      </div><div class="aucbar small">${okSrc}</div>
      <div id="kpis"></div>`, { cls: "c12" })}
    <section class="panel c12"><div class="pb flush" id="res"></div></section>
  </div>`;
  setStatus("ok", `${d.total} lots · ${new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}`);
  const draw = () => {
    const sts = AS.states.toUpperCase().split(/[\s,]+/).filter(Boolean);
    const maxp = parseFloat(String(AS.maxp).replace(/[$,]/g, ""));
    const within = AS.within === "any" ? null : +AS.within * 3600;
    const now = Date.now() / 1000;
    let v = d.items.filter((it) => (!sts.length || sts.includes((it.state || "").toUpperCase())) && (!isFinite(maxp) || !isNum(it.price) || it.price <= maxp) &&
      (!within || (it.ends && it.ends - now <= within)) && it.score >= +AS.minScore && (!AS.hideRisk || !it.risk.length));
    const key = { score: (a, b) => b.score - a.score, ending: (a, b) => (a.ends || 9e12) - (b.ends || 9e12), price: (a, b) => (a.price ?? 9e12) - (b.price ?? 9e12),
      bids: (a, b) => (a.bids ?? 9e9) - (b.bids ?? 9e9) || b.score - a.score, new: (a, b) => isNew(b) - isNew(a) || b.score - a.score }[AS.sort];
    v.sort(key);
    const n24 = v.filter((i) => i.ends && i.ends - now < 86400).length;
    $("#kpis").innerHTML = `<div class="kpis small">
      <div class="kpi"><span>Showing</span><b>${v.length}</b><small>of ${d.total} open lots</small></div>
      <div class="kpi"><span>Top picks (score &ge; 70)</span><b class="up">${v.filter((i) => i.score >= 70).length}</b></div>
      <div class="kpi"><span>Ending within 24h</span><b class="${n24 ? "amber" : ""}">${n24}</b></div>
      <div class="kpi"><span>No bids yet</span><b>${v.filter((i) => i.bids === 0).length}</b></div>
      <div class="kpi"><span>New since last visit</span><b>${firstVisit ? "--" : v.filter(isNew).length}</b><small>${firstVisit ? "first visit to this tab" : ""}</small></div>
      <div class="kpi"><span>Flagged risky</span><b class="${v.some((i) => i.risk.length) ? "down" : ""}">${v.filter((i) => i.risk.length).length}</b></div></div>`;
    const w = watchMap();
    const shown = v.slice(0, 300);
    $("#res").innerHTML = !v.length ? `<div class="loading">Nothing matches these filters</div>` :
      AS.view === "table" ? `<table class="t"><thead><tr><th>Score</th><th>Site</th><th class="l">Lot</th><th>Price</th><th>Bids</th><th>Left</th><th>State</th><th></th></tr></thead>
        <tbody>${shown.map((it) => rowHTML(it, isNew(it), w)).join("")}</tbody></table>`
      : `<div class="agrid">${shown.map((it) => card(it, isNew(it), w)).join("")}</div>`;
    if (v.length > 300) $("#res").insertAdjacentHTML("beforeend", `<div class="note">Showing the first 300 of ${v.length} - narrow with the filters above.</div>`);
    bindStars(d.items);
  };
  const set = (k, val) => { AS[k] = val; saveA(); draw(); };
  $$("[data-src]").forEach((c) => (c.onchange = () => { AS.srcs = $$("[data-src]").filter((x) => x.checked).map((x) => x.dataset.src); if (!AS.srcs.length) AS.srcs = SOURCES.slice(); saveA(); render(); }));
  $("#f-st").onchange = (e) => set("states", e.target.value.trim());
  $("#f-mp").onchange = (e) => set("maxp", e.target.value.trim());
  $("#f-w").onchange = (e) => set("within", e.target.value);
  $("#f-ms").onchange = (e) => set("minScore", +e.target.value);
  $("#f-hr").onchange = (e) => set("hideRisk", e.target.checked);
  $("#f-so").onchange = (e) => set("sort", e.target.value);
  bindSeg("f-v", (val) => set("view", val));
  $("#csv").onclick = () => downloadCSV(`auctions-${AS.tab}-${new Date().toISOString().slice(0, 10)}.csv`, [
    ["Score", "Site", "Title", "Price", "Bids", "Ends", "City", "State", "Seller", "Why", "Risks", "URL"],
    ...d.items.map((i) => [i.score, i.src, i.title, i.price, i.bids, i.ends ? new Date(i.ends * 1000).toISOString() : "", i.city, i.state, i.seller, i.why.join("; "), i.risk.join("; "), i.url])]);
  draw();
}

/* ================================================================== WATCHING */
function watching() {
  const w = watchMap();
  const items = Object.values(w).sort((a, b) => (a.ends || 9e12) - (b.ends || 9e12));
  const now = Date.now() / 1000;
  PAGE.innerHTML = `<div class="grid">${panel(`Lots you're watching <span class="muted">${items.length}</span>`,
    items.length ? `<div class="note">Price and bids are as of when you starred the lot - open the listing for the live price. Ended lots can be removed with the star.</div>
      <div class="agrid">${items.map((it) => card({ ...it, why: it.why || [], risk: (it.ends && it.ends < now ? ["ENDED"] : []).concat(it.risk || []) }, false, w)).join("")}</div>`
      : `<div class="loading">Nothing yet - press &#9733; on any lot to keep it here.</div>`, { cls: "c12" })}</div>`;
  bindStars(items);
}

/* ================================================================== HOW */
function about() {
  PAGE.innerHTML = `<div class="grid">
    ${panel("Where the lots come from", `<div class="desc note" style="padding:10px 12px"><ul class="insights">
      <li>${srcTag("PropertyRoom")} <b>Police auctions.</b> Over 4,000 police departments and sheriffs sell seized, recovered and unclaimed property here: jewelry, watches, electronics, bikes, tools and vehicles.</li>
      <li>${srcTag("GSA")} <b>US federal government.</b> GSA Auctions sells surplus and seized property from federal agencies (Customs &amp; Border Protection, DoD, VA...): pickups, sedans, computers, generators, even aircraft. Uses your free api.data.gov key from Influence Watch if you saved one, else the shared demo key.</li>
      <li>${srcTag("Public Surplus")} <b>Cities, counties, schools, police.</b> Local-government surplus: fleet vehicles, police cars, IT equipment, furniture, tools.</li>
      <li>${srcTag("HiBid")} <b>Local auction houses.</b> Thousands of estate, consignment, police and municipal auctioneers. The best source for antiques and collectibles.</li></ul></div>`, { cls: "c6" })}
    ${panel("How the interest score works", `<div class="desc note" style="padding:10px 12px"><p>Every lot starts at 35 and moves up or down. Every reason is shown on the lot, so you can judge it yourself.</p><ul class="insights">
      <li><span class="why">Valuable</span> sought-after words for the category: Toyota / F-150 / 4x4 / low miles; MacBook Pro / RTX / iPhone 15; sterling / 14k / signed / first edition / Victorian; Rolex / platinum / PCGS; Snap-on / Milwaukee / Kubota. A word in the title counts double.</li>
      <li><span class="why">No bids yet, ends soon</span> or <span class="why">Few bids</span>: less competition near the close is where bargains come from.</li>
      <li><span class="why">Bid vs estimate</span>: the current bid is under half the auctioneer's own low estimate (HiBid). Estimates are set by the seller, so treat them with care.</li>
      <li><span class="why">Classic</span> (pre-1985) or <span class="why">Late model</span> vehicles, and mileage under 100k.</li>
      <li><span class="risk">Risk</span> words knock points off: for parts, salvage, no title, does not run, untested, iCloud/BIOS locked, plated, overlay, replica, cubic zirconia. So do <span class="risk">accessories</span> that only mention a valuable item ("case for MacBook").</li></ul>
      <p class="muted">This is a shortlist, not an appraisal. Always read the listing, check buyer's premium, pickup location and title status, and inspect in person where you can.</p></div>`, { cls: "c6" })}
  </div>`;
}

render();

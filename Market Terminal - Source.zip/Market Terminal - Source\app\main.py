"""Market Terminal - launcher + local API server.

Double-click the built MarketTerminal.exe (or run `python app/main.py`).
Starts a local server on 127.0.0.1 and opens the terminal in a chromeless
Edge/Chrome app window. Closing the window shuts the server down.
"""
from __future__ import annotations

import json
import math
import mimetypes
import os
import socket
import subprocess
import sys
import threading
import time
import urllib.request
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

APP_NAME = "MarketTerminal"
PORT = 8765
for _i, _a in enumerate(sys.argv):  # --port N (dev/testing alongside an installed copy)
    if _a == "--port" and _i + 1 < len(sys.argv):
        PORT = int(sys.argv[_i + 1])

def _data_dir():
    """Portable mode: if a 'MarketTerminal-data' folder sits next to the exe, keep everything there
    (watchlist, portfolios, alerts, caches travel with the USB stick). Otherwise use %LOCALAPPDATA%."""
    if getattr(sys, "frozen", False):
        local = Path(sys.executable).resolve().parent / "MarketTerminal-data"
        if local.is_dir():
            return local
    if sys.platform == "win32":
        return Path(os.environ.get("LOCALAPPDATA", Path.home())) / APP_NAME
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / APP_NAME
    return Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share")) / APP_NAME


DATA_DIR = _data_dir()
DATA_DIR.mkdir(parents=True, exist_ok=True)
os.environ["MT_DATA_DIR"] = str(DATA_DIR)  # read by data.py / apps.py

# Windowed (no-console) builds have no stdout/stderr; send output to a log file.
if sys.stdout is None or sys.stderr is None:
    _log = open(DATA_DIR / "log.txt", "a", encoding="utf-8", buffering=1)
    sys.stdout = sys.stdout or _log
    sys.stderr = sys.stderr or _log

BASE = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
STATIC = BASE / "static"

LAST_PING = time.time()

# Heavy imports (pandas / yfinance) load in the background so the window appears instantly.
_MODS = {}
_READY = threading.Event()


def _load_data():
    import data as d  # noqa: PLC0415
    import research as r  # noqa: PLC0415
    import apps as a  # noqa: PLC0415
    import watch as w  # noqa: PLC0415
    import trades as t  # noqa: PLC0415
    import auctions as au  # noqa: PLC0415
    _MODS.update(data=d, research=r, apps=a, watch=w, trades=t, auctions=au)
    _READY.set()


def _load_device():
    """Device Watch is light (psutil + sqlite) and starts its collector as soon as the server is up."""
    try:
        import device as dv  # noqa: PLC0415
        _MODS["device"] = dv
        dv.start_collector()
    except Exception:  # noqa: BLE001
        import traceback
        traceback.print_exc()
    finally:
        _DEV_READY.set()


_DEV_READY = threading.Event()


class _Lazy:
    def __init__(self, mod):
        self._mod = mod

    def __getattr__(self, name):
        ev = _DEV_READY if self._mod == "device" else _READY
        if not ev.wait(120) or self._mod not in _MODS:
            raise RuntimeError(f"{self._mod} module failed to load")
        return getattr(_MODS[self._mod], name)


data = _Lazy("data")
research = _Lazy("research")
apps = _Lazy("apps")
watch = _Lazy("watch")
trades = _Lazy("trades")
device = _Lazy("device")
auctions = _Lazy("auctions")

# The apps served by this one local server: name -> url path
APPS = {"terminal": "/", "lab": "/lab/", "signal": "/signal/", "watch": "/watch/", "device": "/device/", "auctions": "/auctions/"}


_SV = [0.0, ""]


def _static_version():
    """Fingerprint of the page files (newest mtime), so open windows can reload themselves after an update."""
    if time.time() - _SV[0] > 10:
        try:
            _SV[1] = str(int(max(f.stat().st_mtime for f in STATIC.rglob("*") if f.suffix in (".js", ".css", ".html"))))
        except ValueError:
            _SV[1] = ""
        _SV[0] = time.time()
    return _SV[1]


def _syms(s):
    return [x.strip().upper() for x in (s or "").split(",") if x.strip()]


def _clean(o):
    if isinstance(o, float):
        return None if (math.isnan(o) or math.isinf(o)) else o
    if isinstance(o, dict):
        return {k: _clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_clean(v) for v in o]
    return o


ROUTES = {
    "/api/overview": lambda q: data.page_overview(),
    "/api/equities": lambda q: data.page_equities(),
    "/api/govt": lambda q: data.page_govt(),
    "/api/corp": lambda q: data.page_corp(),
    "/api/private": lambda q: data.page_private(),
    "/api/econ": lambda q: data.page_econ(),
    "/api/news": lambda q: data.news(q.get("topic", "top")),
    "/api/security": lambda q: data.security(q["symbol"], q.get("range", "1Y")),
    "/api/quotes": lambda q: data.quotes([s.strip().upper() for s in q["symbols"].split(",") if s.strip()][:60]),
    "/api/fred": lambda q: data.fred_chart(q["id"], q.get("tf", "lvl"), float(q.get("years", 10))),
    "/api/search": lambda q: data.search(q["q"]),
    # security functions
    "/api/gp": lambda q: research.gp(q["symbol"], q.get("range", "1Y")),
    "/api/fa": lambda q: research.fa(q["symbol"], q.get("period", "annual")),
    "/api/ern": lambda q: research.ern(q["symbol"]),
    "/api/anr": lambda q: research.anr(q["symbol"]),
    "/api/omon": lambda q: research.options(q["symbol"], q.get("exp")),
    "/api/hds": lambda q: research.hds(q["symbol"]),
    "/api/dvd": lambda q: research.dvd(q["symbol"]),
    "/api/rv": lambda q: research.rv(q["symbol"], q.get("extra", "")),
    # global tools
    "/api/comp": lambda q: research.comp(_syms(q["symbols"]), q.get("range", "1Y")),
    "/api/cal": lambda q: research.calendar(int(q.get("days", 14))),
    "/api/next_earnings": lambda q: research.next_earnings(_syms(q["symbols"])),
    "/api/eqs": lambda q: research.eqs(q),
    "/api/ext": lambda q: research.ext_page(q.get("watch", "")),
    "/api/ext_quotes": lambda q: research.ext_quotes(_syms(q["symbols"])),
    "/api/ext_chart": lambda q: research.ext_chart(q["symbol"]),
    "/api/ping": lambda q: {"ok": True, "app": APP_NAME, "v": _static_version()},
    # Portfolio Lab
    "/api/lab/backtest": lambda q: apps.lab_backtest(q),
    # Signal Monitor
    "/api/sig/overview": lambda q: apps.signal_overview(q["symbol"], q.get("title") or None),
    "/api/sig/news": lambda q: apps.news_sentiment(q.get("name", ""), q.get("symbol", "")),
    "/api/sig/hn": lambda q: apps.hn_mentions(q["q"]),
    "/api/sig/gdelt": lambda q: apps.gdelt(q["q"]),
    "/api/sig/scan1": lambda q: apps.scan_one(q["symbol"]),
    "/api/sig/scanpx": lambda q: apps.scan_prices(_syms(q["symbols"])),
    "/api/sig/universes": lambda q: apps.universes(),
    "/api/sig/settings": lambda q: apps.set_settings(q["contact"]) if "contact" in q else {"contact": apps.get_settings().get("contact", ""), "cooldown": apps.wiki_cooldown()},
    # Influence Watch
    "/api/iw/wire": lambda q: watch.wire(q),
    "/api/iw/stories": lambda q: watch.stories(q),
    "/api/iw/framing": lambda q: watch.framing(q),
    "/api/iw/echoes": lambda q: watch.echoes(q),
    "/api/iw/profile": lambda q: watch.profile(q),
    "/api/iw/person": lambda q: watch.person(q),
    "/api/iw/fec": lambda q: watch.fec(q),
    "/api/iw/lda_country": lambda q: watch.lda_country(q),
    "/api/iw/lda_client": lambda q: watch.lda_client(q),
    "/api/iw/fara_summary": lambda q: watch.fara_summary(q),
    "/api/iw/fara_country": lambda q: watch.fara_country(q),
    "/api/iw/fara_search": lambda q: watch.fara_search(q),
    "/api/iw/gov": lambda q: watch.gov(q),
    "/api/iw/status": lambda q: watch.status(q),
    "/api/iw/settings": lambda q: watch.settings(q),
    "/api/iw/refresh": lambda q: watch.refresh(),
    "/api/iw/congress": lambda q: trades.congress(q),
    "/api/iw/insiders": lambda q: trades.insiders(q),
    "/api/iw/insider_company": lambda q: trades.insider_company(q),
    "/api/iw/contracts": lambda q: trades.contracts(q),
    "/api/iw/contracts_search": lambda q: trades.contracts_search(q),
    "/api/iw/money_highlights": lambda q: trades.highlights(q),
    # Device Watch
    "/api/dev/status": lambda q: device.status(q),
    "/api/dev/live": lambda q: device.live(q),
    "/api/dev/history": lambda q: device.history(q),
    "/api/dev/traffic": lambda q: device.traffic(q),
    "/api/dev/dns": lambda q: device.dns(q),
    "/api/dev/events": lambda q: device.events(q),
    "/api/dev/listening": lambda q: device.listening(q),
    "/api/dev/audit": lambda q: device.audit(q),
    "/api/dev/block": lambda q: device.block(q),
    "/api/dev/always_on": lambda q: device.set_always_on(q),
    "/api/dev/clear": lambda q: device.clear(q),
    # Auction Finder
    "/api/auc/profiles": lambda q: auctions.profiles(q),
    "/api/auc/search": lambda q: auctions.search(q),
}


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):  # quiet
        pass

    def _send(self, code, body: bytes, ctype):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):  # noqa: N802
        global LAST_PING
        u = urlparse(self.path)
        if u.path.startswith("/api/"):
            LAST_PING = time.time()
            q = {k: v[0] for k, v in parse_qs(u.query).items()}
            fn = ROUTES.get(u.path)
            if not fn:
                return self._send(404, b'{"error":"not found"}', "application/json")
            try:
                res = fn(q)
                code = 200
            except Exception as e:  # noqa: BLE001
                res, code = {"error": f"{type(e).__name__}: {e}"}, 500
            body = json.dumps(_clean(res), allow_nan=False).encode()
            return self._send(code, body, "application/json")
        if u.path.rstrip("/") in ("/lab", "/signal", "/watch", "/device", "/auctions") and not u.path.endswith("/"):
            self.send_response(301)
            self.send_header("Location", u.path + "/")
            self.end_headers()
            return None
        rel = u.path.lstrip("/")
        if not rel or rel.endswith("/"):
            rel += "index.html"
        f = (STATIC / rel).resolve()
        if STATIC.resolve() not in f.parents or not f.is_file():
            return self._send(404, b"not found", "text/plain")
        ctype = mimetypes.guess_type(str(f))[0] or "application/octet-stream"
        return self._send(200, f.read_bytes(), ctype)


def already_running():
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{PORT}/api/ping", timeout=2) as r:
            return APP_NAME in r.read().decode()
    except Exception:  # noqa: BLE001
        return False


def find_browser():
    """A Chromium browser that supports --app windows (Edge, Chrome, Brave, Chromium). Safari/Firefox can't do
    chromeless app windows, so without one of these the app opens in the default browser instead."""
    cands = []
    if sys.platform == "win32":
        for root in (os.environ.get("ProgramFiles(x86)"), os.environ.get("ProgramFiles"),
                     os.environ.get("LOCALAPPDATA")):
            if root:
                cands += [Path(root) / "Microsoft/Edge/Application/msedge.exe",
                          Path(root) / "Google/Chrome/Application/chrome.exe"]
    elif sys.platform == "darwin":
        for root in (Path("/Applications"), Path.home() / "Applications"):
            cands += [root / "Google Chrome.app/Contents/MacOS/Google Chrome",
                      root / "Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
                      root / "Brave Browser.app/Contents/MacOS/Brave Browser",
                      root / "Chromium.app/Contents/MacOS/Chromium"]
    else:
        import shutil  # noqa: PLC0415
        cands += [Path(p) for p in (shutil.which(n) for n in ("google-chrome", "chromium", "chromium-browser",
                                                               "microsoft-edge", "brave-browser")) if p]
    for c in cands:
        if c.is_file():
            return str(c)
    return None


def open_window(url):
    """Returns a Popen to wait on, or None if we fell back to the default browser."""
    exe = find_browser()
    if not exe:
        webbrowser.open(url)
        return None
    prof = DATA_DIR / "window-profile"
    args = [exe, f"--app={url}", f"--user-data-dir={prof}", "--window-size=1600,950",
            "--no-first-run", "--no-default-browser-check", "--disable-features=Translate"]
    return subprocess.Popen(args)


def which_app():
    """--app terminal|lab|signal, or inferred from the exe name (e.g. a copy renamed PortfolioLab.exe)."""
    for i, a in enumerate(sys.argv):
        if a == "--app" and i + 1 < len(sys.argv):
            return sys.argv[i + 1].lower()
        if a.startswith("--app="):
            return a.split("=", 1)[1].lower()
    exe = Path(sys.argv[0]).stem.lower()
    if "lab" in exe or "portfolio" in exe:
        return "lab"
    if "signal" in exe:
        return "signal"
    if "device" in exe:
        return "device"
    if "auction" in exe:
        return "auctions"
    if "influence" in exe or "watch" in exe:
        return "watch"
    return "terminal"


def main():
    url = f"http://127.0.0.1:{PORT}" + APPS.get(which_app(), "/")
    collect = "--collect" in sys.argv  # Device Watch always-on: headless server + network logger, never exits
    if already_running():
        if "--server" in sys.argv or collect:
            print(f"Port {PORT} is already in use by another Market Terminal - use --port to pick another")
            return
        open_window(url)
        return
    srv = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    srv.daemon_threads = True
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    threading.Thread(target=_load_device, daemon=True).start()
    threading.Thread(target=_load_data, daemon=True).start()
    if "--server" in sys.argv or collect:  # dev mode / always-on collector: just serve
        print(f"Serving on {url}")
        try:
            while True:
                time.sleep(3600)
        except KeyboardInterrupt:
            return
    proc = open_window(url)
    if proc is not None:
        proc.wait()
    # Every app window pings /api/ping every 20s. Keep serving while any window is open
    # (Terminal, Portfolio Lab and Signal Monitor share this server); stop ~1 min after the last closes.
    grace = time.time() + 45
    while time.time() < grace or time.time() - LAST_PING < 60:
        time.sleep(5)
    srv.shutdown()


if __name__ == "__main__":
    try:
        socket.setdefaulttimeout(30)
        main()
    except Exception as e:  # noqa: BLE001
        import traceback
        (DATA_DIR / "crash.txt").write_text(traceback.format_exc(), encoding="utf-8")
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(0, f"Market Terminal failed to start:\n{e}", APP_NAME, 0x10)
        except Exception:  # noqa: BLE001
            pass

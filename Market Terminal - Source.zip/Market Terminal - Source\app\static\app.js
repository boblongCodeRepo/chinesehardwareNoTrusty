/* Market Terminal front-end */
"use strict";

const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const PAGE = $("#page");
const state = { page: "mkts", sym: null, fn: "des", range: "1Y", newsTopic: "top", timer: null, gen: 0,
  faPer: "annual", optExp: null, optWin: 15, comp: null, compRange: "1Y", calDays: 14, calCap: 1e10, calRegion: "US", eqsSort: null };
const charts = {};

/* ------------------------------------------------------------------ utils */
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const isNum = (v) => typeof v === "number" && isFinite(v);
const cls = (v) => (!isNum(v) || v === 0 ? "" : v > 0 ? "up" : "down");
const sign = (v) => (v > 0 ? "+" : "");

function fmt(v, d = 2) {
  if (!isNum(v)) return "--";
  return v.toLocaleString("en-US", { minimumFractionDigits: d, maximumFractionDigits: d });
}
function pxDigits(sym, v) {
  if (!isNum(v)) return 2;
  if (sym && sym.endsWith("=X") && Math.abs(v) < 20) return 4;
  if (Math.abs(v) < 1) return 4;
  return 2;
}
const pct = (v, d = 2) => (isNum(v) ? `${sign(v)}${fmt(v, d)}%` : "--");
const bp = (v) => (isNum(v) ? `${sign(v)}${fmt(v, 0)}` : "--");
function big(v) {
  if (!isNum(v)) return "--";
  const a = Math.abs(v);
  if (a >= 1e12) return fmt(v / 1e12, 2) + "T";
  if (a >= 1e9) return fmt(v / 1e9, 2) + "B";
  if (a >= 1e6) return fmt(v / 1e6, 2) + "M";
  if (a >= 1e3) return fmt(v / 1e3, 1) + "K";
  return fmt(v, 0);
}
const chgPct = (a, b) => (isNum(a) && isNum(b) && b !== 0 ? (a / b - 1) * 100 : null);
function ago(ts) {
  if (!ts) return "";
  const s = Date.now() / 1000 - ts;
  if (s < 3600) return Math.max(1, Math.round(s / 60)) + "m";
  if (s < 86400) return Math.round(s / 3600) + "h";
  return Math.round(s / 86400) + "d";
}

async function api(path) {
  const r = await fetch(path);
  const j = await r.json();
  if (!r.ok || (j && j.error && Object.keys(j).length === 1)) throw new Error(j.error || r.statusText);
  return j;
}

function setStatus(kind, text) {
  $("#status").className = kind;
  $("#status-text").textContent = text;
}

/* ------------------------------------------------------------------ small visuals */
function spark(vals, w = 80, h = 20) {
  const v = (vals || []).filter(isNum);
  if (v.length < 2) return "";
  const mn = Math.min(...v), mx = Math.max(...v), rg = mx - mn || 1;
  const pts = v.map((y, i) => `${((i / (v.length - 1)) * w).toFixed(1)},${(h - 2 - ((y - mn) / rg) * (h - 4)).toFixed(1)}`).join(" ");
  const col = v[v.length - 1] >= v[0] ? "var(--up)" : "var(--down)";
  return `<svg width="${w}" height="${h}" viewBox="0 0 ${w} ${h}"><polyline fill="none" stroke="${col}" stroke-width="1.2" points="${pts}"/></svg>`;
}
function rangeBar(lo, hi, v) {
  if (!isNum(lo) || !isNum(hi) || !isNum(v) || hi === lo) return "";
  const p = Math.max(0, Math.min(100, ((v - lo) / (hi - lo)) * 100));
  return `<span class="rng" title="52w: ${fmt(lo)} - ${fmt(hi)}"><span style="left:calc(${p}% - 1px)"></span></span>`;
}
function heatColor(p) {
  if (!isNum(p)) return "#222";
  const a = Math.min(1, Math.abs(p) / 3);
  return p >= 0 ? `rgba(30,170,90,${0.2 + a * 0.75})` : `rgba(220,50,50,${0.2 + a * 0.75})`;
}

function panel(title, body, opts = {}) {
  return `<section class="panel ${opts.cls || ""}" ${opts.id ? `id="${opts.id}"` : ""}>
    <div class="ph"><h3>${title}</h3>${opts.tools || ""}<span class="src">${opts.src || ""}</span></div>
    <div class="pb ${opts.flush === false ? "" : "flush"} ${opts.scroll ? "scroll" : ""}" ${opts.maxh ? `style="max-height:${opts.maxh}px"` : ""}>${body}</div>
  </section>`;
}
const errBox = (e) => `<div class="err-box">&#9888; ${esc(e && e.message ? e.message : e)}</div>`;

/* ------------------------------------------------------------------ quote tables */
function quoteTable(g, opts = {}) {
  if (!g || !g.rows) return errBox("no data");
  const yld = g.kind === "yld";
  const full = !!opts.full;
  const showChg = full || yld; // compact price tables skip the absolute change to fit
  let h = `<table class="t"><thead><tr><th>${esc(opts.label || "Security")}</th><th>${yld ? "Yield" : "Last"}</th>
    ${showChg ? `<th>${yld ? "Chg bp" : "Chg"}</th>` : ""}${yld ? "" : "<th>%Chg</th>"}
    ${full ? `<th>${yld ? "1W bp" : "1W%"}</th>` : ""}${full || yld ? `<th>${yld ? "1M bp" : "1M%"}</th>` : ""}<th>${yld ? "YTD bp" : "YTD%"}</th>
    ${full ? `<th>${yld ? "1Y bp" : "1Y%"}</th><th>52W Range</th>` : ""}<th>3M</th></tr></thead><tbody>`;
  for (const r of g.rows) {
    if (r.missing) {
      h += `<tr><td class="nm">${esc(r.name)}<span class="sym">${esc(r.sym)}</span></td><td colspan="9" class="muted">unavailable</td></tr>`;
      continue;
    }
    const d = pxDigits(r.sym, r.last);
    const c = r.last - r.prev;
    const p = chgPct(r.last, r.prev);
    const delta = (base) => (yld ? (isNum(base) ? (r.last - base) * 100 : null) : chgPct(r.last, base));
    const show = (v) => (yld ? bp(v) : pct(v));
    h += `<tr class="click" data-sym="${esc(r.sym)}">
      <td class="nm" title="${esc(r.name)} (${esc(r.sym)}) as of ${esc(r.asof)}">${esc(r.name)}<span class="sym">${esc(r.sym)}</span></td>
      <td class="last">${yld ? fmt(r.last, 3) + "%" : fmt(r.last, d)}</td>
      ${showChg ? `<td class="${cls(c)}">${yld ? bp(c * 100) : sign(c) + fmt(c, d)}</td>` : ""}
      ${yld ? "" : `<td><span class="pill ${cls(p)}">${pct(p)}</span></td>`}
      ${full ? `<td class="${cls(delta(r.w1))}">${show(delta(r.w1))}</td>` : ""}
      ${full || yld ? `<td class="${cls(delta(r.m1))}">${show(delta(r.m1))}</td>` : ""}
      <td class="${cls(delta(r.ytd))}">${show(delta(r.ytd))}</td>
      ${full ? `<td class="${cls(delta(r.y1))}">${show(delta(r.y1))}</td><td>${rangeBar(r.lo52, r.hi52, r.last)}</td>` : ""}
      <td class="spk">${spark(r.spark, full ? 80 : 64)}</td></tr>`;
  }
  return h + "</tbody></table>";
}

function groupsPanels(groups, opts = {}) {
  if (!Array.isArray(groups)) return panel("Quotes", errBox(groups && groups.error), { cls: "c12" });
  return groups.map((g) => panel(g.title, quoteTable(g, opts), { cls: opts.cls || "c6", src: "Yahoo Finance" })).join("");
}

function newsList(items, max = 40) {
  if (!Array.isArray(items) || !items.length) return `<div class="loading">No headlines available</div>`;
  return `<ul class="news">${items.slice(0, max).map((n) => `<li><span class="tm">${ago(n.ts)}</span>
    <span><a href="${esc(n.link)}" target="_blank" rel="noopener">${esc(n.title)}</a> <span class="so">${esc(n.source)}</span></span></li>`).join("")}</ul>`;
}

async function newsPanel(elId, topic, max = 25) {
  const el = document.getElementById(elId);
  if (!el) return;
  try {
    const items = await api(`/api/news?topic=${topic}`);
    if (document.getElementById(elId)) document.getElementById(elId).innerHTML = newsList(items, max);
  } catch (e) {
    el.innerHTML = errBox(e);
  }
}

/* ------------------------------------------------------------------ charts */
Chart.defaults.color = "#8b8b92";
Chart.defaults.font.family = "Cascadia Mono, Consolas, monospace";
Chart.defaults.font.size = 11;
Chart.defaults.borderColor = "#202024";

const PALETTE = ["#ffa028", "#5cb3ff", "#c084fc", "#34d27b", "#ff5252", "#ffd84a", "#2dd4bf", "#f472b6", "#a3a3a3", "#fb923c"];
const TOOLTIP = { backgroundColor: "#141416", borderColor: "#ffa028", borderWidth: 1, titleColor: "#ffa028" };

function lineChart(id, labels, datasets, opts = {}) {
  const cv = document.getElementById(id);
  if (!cv) return;
  if (charts[id]) charts[id].destroy();
  const palette = opts.palette || ["#ffa028", "#5cb3ff", "#c084fc", "#8b8b92", "#34d27b"];
  charts[id] = new Chart(cv, {
    type: "line",
    data: {
      labels,
      datasets: datasets.map((d, i) => ({
        borderWidth: d.borderWidth || 1.6, pointRadius: d.pointRadius ?? 0, tension: 0.15, spanGaps: true,
        borderColor: d.color || palette[i % palette.length], backgroundColor: d.fill || "transparent",
        fill: !!d.fill, borderDash: d.dash || [], ...d,
      })),
    },
    options: {
      responsive: true, maintainAspectRatio: false, animation: false,
      interaction: { mode: "index", intersect: false },
      plugins: {
        legend: { display: opts.legend ?? datasets.length > 1, labels: { boxWidth: 12, color: "#cfcfcf" } },
        tooltip: { ...TOOLTIP, filter: (c) => !c.dataset.noTip,
          callbacks: { label: (c) => ` ${c.dataset.label || ""}: ${fmt(c.parsed.y, opts.digits ?? 2)}${opts.unit || ""}` } },
      },
      scales: {
        x: { ticks: { maxTicksLimit: opts.xticks || 8, maxRotation: 0 }, grid: { display: false } },
        y: { position: "right", ticks: { callback: (v) => fmt(v, opts.ydigits ?? 2) + (opts.unit || "") },
          ...(opts.yWidth ? { afterFit: (s) => { s.width = opts.yWidth; } } : {}),
          ...(isNum(opts.ymin) ? { min: opts.ymin } : {}), ...(isNum(opts.ymax) ? { max: opts.ymax } : {}) },
      },
    },
  });
}

function barChart(id, labels, values, opts = {}) {
  const cv = document.getElementById(id);
  if (!cv) return;
  if (charts[id]) charts[id].destroy();
  const f = opts.fmt || ((v) => pct(v));
  charts[id] = new Chart(cv, {
    type: "bar",
    data: { labels, datasets: [{ data: values, backgroundColor: opts.color || values.map((v) => (v >= 0 ? "#1faa5a" : "#dc3232")) }] },
    options: {
      indexAxis: "y", responsive: true, maintainAspectRatio: false, animation: false,
      plugins: { legend: { display: false }, tooltip: { ...TOOLTIP, callbacks: { label: (c) => ` ${f(c.parsed.x)}` } } },
      scales: { y: { grid: { display: false }, ticks: { autoSkip: false, color: "#cfcfcf" } },
        x: { ticks: { callback: (v) => v + "%" } } },
    },
  });
}

/* vertical bars; datasets may include {type:"line"} overlays */
function vbar(id, labels, datasets, opts = {}) {
  const cv = document.getElementById(id);
  if (!cv) return;
  if (charts[id]) charts[id].destroy();
  const f = opts.fmt || ((v) => fmt(v, 2));
  charts[id] = new Chart(cv, {
    type: "bar",
    data: { labels, datasets: datasets.map((d) => ({ borderWidth: 0, ...(d.type === "line" ? { pointRadius: 0, tension: 0.15, borderWidth: 1.4 } : {}), ...d })) },
    options: {
      responsive: true, maintainAspectRatio: false, animation: false, interaction: { mode: "index", intersect: false },
      plugins: {
        legend: { display: opts.legend ?? datasets.length > 1, labels: { boxWidth: 12, color: "#cfcfcf" } },
        tooltip: { ...TOOLTIP, callbacks: { label: (c) => ` ${c.dataset.label || ""}: ${f(c.parsed.y)}` } },
      },
      scales: {
        x: { stacked: !!opts.stacked, grid: { display: false }, display: opts.xaxis ?? true, ticks: { maxRotation: 0, autoSkip: true, maxTicksLimit: opts.xticks || 14 } },
        y: { stacked: !!opts.stacked, position: "right", ticks: { maxTicksLimit: opts.yticks || 8, callback: (v) => (opts.yfmt || f)(v) },
          ...(opts.yWidth ? { afterFit: (s) => { s.width = opts.yWidth; } } : {}) },
      },
    },
  });
}

/* labelled scatter (RV) */
function scatterChart(id, pts, o) {
  const cv = document.getElementById(id);
  if (!cv) return;
  if (charts[id]) charts[id].destroy();
  charts[id] = new Chart(cv, {
    type: "scatter",
    data: { datasets: [{ data: pts, pointRadius: pts.map((p) => (p.hl ? 6 : 4)), pointHoverRadius: 7,
      backgroundColor: pts.map((p) => (p.hl ? "#ffa028" : "#5cb3ff")) }] },
    options: {
      responsive: true, maintainAspectRatio: false, animation: false,
      plugins: { legend: { display: false },
        tooltip: { ...TOOLTIP, callbacks: { label: (c) => ` ${c.raw.s}: ${o.xl} ${fmt(c.raw.x, 1)}${o.xu || ""} | ${o.yl} ${fmt(c.raw.y, 1)}${o.yu || ""}` } } },
      scales: { x: { title: { display: true, text: o.xl + (o.xu ? ` (${o.xu})` : "") } },
        y: { position: "right", title: { display: true, text: o.yl + (o.yu ? ` (${o.yu})` : "") } } },
    },
    plugins: [{ id: "lbl", afterDatasetsDraw(ch) {
      const ctx = ch.ctx;
      ctx.save(); ctx.font = "10px Cascadia Mono, Consolas, monospace";
      ch.getDatasetMeta(0).data.forEach((el, i) => {
        const r = ch.data.datasets[0].data[i];
        ctx.fillStyle = r.hl ? "#ffa028" : "#cfcfcf";
        ctx.fillText(r.s, el.x + 7, el.y - 5);
      });
      ctx.restore();
    } }],
  });
}

function volChart(id, labels, vols, closes, yWidth) {
  const cv = document.getElementById(id);
  if (!cv) return;
  if (charts[id]) charts[id].destroy();
  const col = closes.map((c, i) => (i && isNum(c) && isNum(closes[i - 1]) && c < closes[i - 1] ? "rgba(255,82,82,.55)" : "rgba(52,210,123,.55)"));
  charts[id] = new Chart(cv, {
    type: "bar",
    data: { labels, datasets: [{ label: "Volume", data: vols, backgroundColor: col, barPercentage: 1, categoryPercentage: 1 }] },
    options: {
      responsive: true, maintainAspectRatio: false, animation: false, interaction: { mode: "index", intersect: false },
      plugins: { legend: { display: false }, tooltip: { ...TOOLTIP, callbacks: { label: (c) => ` Volume: ${big(c.parsed.y)}` } } },
      scales: { x: { display: false }, y: { position: "right", ticks: { maxTicksLimit: 3, callback: (v) => big(v) },
        ...(yWidth ? { afterFit: (s) => { s.width = yWidth; } } : {}) } },
    },
  });
}

function downloadCSV(name, rows) {
  const csv = rows.map((r) => r.map((v) => {
    const s = v === null || v === undefined ? "" : String(v);
    return /[",\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  }).join(",")).join("\r\n");
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
  a.download = name;
  document.body.appendChild(a); a.click(); a.remove();
}

/* FRED history panel shared by GOVT / CORP / PRIV / ECON */
function fredPanelHTML(id, title, height = "") {
  return panel(`<span id="${id}-title">${esc(title)}</span>`,
    `<div class="chart-box ${height}"><canvas id="${id}-cv"></canvas></div>`,
    { id, src: "FRED", tools: `<span class="seg" id="${id}-yrs">${[1, 2, 5, 10].map((y) => `<button data-y="${y}">${y}Y</button>`).join("")}</span>` });
}
const fredState = {};
async function loadFred(id, sid, tf, name, unit, years) {
  fredState[id] = { sid, tf, name, unit, years: years || fredState[id]?.years || 5 };
  const st = fredState[id];
  const t = document.getElementById(`${id}-title`);
  if (t) t.textContent = `${name} - history`;
  $$(`#${id}-yrs button`).forEach((b) => b.classList.toggle("on", +b.dataset.y === st.years));
  try {
    const d = await api(`/api/fred?id=${sid}&tf=${tf}&years=${st.years}`);
    let vals = d.values;
    if (sid === "WALCL") vals = vals.map((v) => (isNum(v) ? v / 1000 : v));
    if (unit === "bp") vals = vals.map((v) => (isNum(v) ? v * 100 : v));
    lineChart(`${id}-cv`, d.labels, [{ label: name, data: vals, fill: "rgba(255,160,40,.08)" }],
      { unit: unit === "%" ? "%" : unit === "bp" ? "bp" : "", digits: unit === "bp" ? 0 : 2, ydigits: unit === "bp" ? 0 : 2 });
  } catch (e) {
    const box = document.querySelector(`#${id} .chart-box`);
    if (box) box.innerHTML = errBox(e);
  }
}
function bindFredYears(id) {
  $$(`#${id}-yrs button`).forEach((b) => (b.onclick = () => {
    const s = fredState[id];
    if (s) loadFred(id, s.sid, s.tf, s.name, s.unit, +b.dataset.y);
  }));
}

/* ------------------------------------------------------------------ watchlist */
const WL_KEY = "mt.watchlist";
function getWL() {
  try { const v = JSON.parse(localStorage.getItem(WL_KEY)); if (Array.isArray(v)) return v; } catch (e) { /* ignore */ }
  return ["AAPL", "MSFT", "NVDA", "SPY", "TLT", "GLD", "HYG"];
}
function setWL(v) { try { localStorage.setItem(WL_KEY, JSON.stringify(v)); } catch (e) { /* ignore */ } }

async function renderWatchlist() {
  const el = document.getElementById("wl-body");
  if (!el) return;
  const wl = getWL();
  if (!wl.length) { el.innerHTML = `<div class="loading">Add tickers below</div>`; return; }
  try {
    const q = await api(`/api/quotes?symbols=${encodeURIComponent(wl.join(","))}`);
    let h = `<table class="t"><thead><tr><th>Ticker</th><th>Last</th><th>%Chg</th><th>1M%</th><th>YTD%</th><th>3M</th><th></th></tr></thead><tbody>`;
    for (const s of wl) {
      const r = q[s];
      if (!r) { h += `<tr><td><span class="amber">${esc(s)}</span></td><td colspan="5" class="muted">no data</td><td><button class="x" data-rm="${esc(s)}">&times;</button></td></tr>`; continue; }
      const p = chgPct(r.last, r.prev);
      h += `<tr class="click" data-sym="${esc(s)}"><td><span class="amber">${esc(s)}</span></td><td class="last">${fmt(r.last, pxDigits(s, r.last))}</td>
        <td><span class="pill ${cls(p)}">${pct(p)}</span></td><td class="${cls(chgPct(r.last, r.m1))}">${pct(chgPct(r.last, r.m1))}</td>
        <td class="${cls(chgPct(r.last, r.ytd))}">${pct(chgPct(r.last, r.ytd))}</td><td class="spk">${spark(r.spark)}</td>
        <td><button class="x" data-rm="${esc(s)}" title="Remove">&times;</button></td></tr>`;
    }
    el.innerHTML = h + "</tbody></table>";
    $$("[data-rm]", el).forEach((b) => (b.onclick = (ev) => {
      ev.stopPropagation();
      setWL(getWL().filter((x) => x !== b.dataset.rm));
      renderWatchlist();
    }));
  } catch (e) { el.innerHTML = errBox(e); }
}
function watchlistPanel(cls = "c4") {
  return panel("My Watchlist", `<div id="wl-body"><div class="loading">Loading...</div></div>
    <div class="wl-add"><input id="wl-in" placeholder="Add ticker e.g. AMD" spellcheck="false"><button id="wl-btn">+ ADD</button></div>`,
    { cls, src: "saved locally" });
}
function bindWatchlist() {
  const add = () => {
    const v = ($("#wl-in").value || "").trim().toUpperCase();
    if (!v) return;
    const wl = getWL();
    if (!wl.includes(v)) wl.push(v);
    setWL(wl);
    $("#wl-in").value = "";
    renderWatchlist();
  };
  if ($("#wl-btn")) { $("#wl-btn").onclick = add; $("#wl-in").onkeydown = (e) => { if (e.key === "Enter") add(); }; }
  renderWatchlist();
}

/* ------------------------------------------------------------------ pages */
const pages = {};

pages.mkts = async (gen) => {
  PAGE.innerHTML = `<div class="loading">Loading market overview...</div>`;
  const [ov, econ] = await Promise.allSettled([api("/api/overview"), api("/api/econ")]);
  if (gen !== state.gen) return;
  if (ov.status === "rejected") { PAGE.innerHTML = errBox(ov.reason); return; }
  const G = ov.value.groups;
  updateTape(G);
  const byTitle = (t) => (Array.isArray(G) ? G.find((g) => g.title === t) : null);
  let snap = errBox("macro data unavailable");
  if (econ.status === "fulfilled") {
    const o = econ.value.outlook;
    const pick = ["Real GDP Growth (QoQ SAAR)", "Atlanta Fed GDPNow", "CPI YoY", "Core PCE YoY (Fed target 2%)", "Unemployment Rate", "Nonfarm Payrolls (MoM, k)", "Effective Fed Funds"];
    const rows = econ.value.indicators.filter((r) => pick.includes(r.name));
    snap = `<div class="regime ${o.regime_status}">${esc(o.regime)}</div>` + econTable(rows, false);
  }
  PAGE.innerHTML = `<div class="grid">
    <div class="c8 stack">
      <div class="grid">
        ${panel("US Equity Indices", quoteTable(byTitle("US Equity Indices")), { cls: "c6", src: "Yahoo Finance" })}
        ${panel("US Treasury Yields", quoteTable(byTitle("US Treasury Yields")), { cls: "c6", src: "Yahoo Finance" })}
        ${panel("Global Equity Indices", quoteTable(byTitle("Global Equity Indices")), { cls: "c6", src: "Yahoo Finance" })}
        ${panel("Commodities", quoteTable(byTitle("Commodities")), { cls: "c6", src: "Yahoo Finance" })}
        ${panel("Currencies", quoteTable(byTitle("Currencies")), { cls: "c6", src: "Yahoo Finance" })}
        ${panel("Crypto", quoteTable(byTitle("Crypto")), { cls: "c6", src: "Yahoo Finance" })}
        ${panel("S&amp;P 500 - 1 Year", `<div class="chart-box short"><canvas id="spx-cv"></canvas></div>`, { cls: "c12", src: "Yahoo Finance" })}
      </div>
    </div>
    <div class="c4 stack">
      ${panel("Macro Snapshot &amp; Outlook", snap, { src: "FRED", tools: `<a href="#/econ" class="muted" style="font-size:11px">more &rsaquo;</a>` })}
      ${watchlistPanel("")}
      ${panel("Top Headlines", `<div id="mkts-news"><div class="loading">Loading...</div></div>`, { scroll: true, maxh: 520, src: "CNBC / MarketWatch / Yahoo / Google" })}
    </div>
  </div>`;
  bindWatchlist();
  newsPanel("mkts-news", "top", 30);
  api("/api/security?symbol=^GSPC&range=1Y").then((d) => {
    if (gen !== state.gen) return;
    lineChart("spx-cv", d.history.labels, [{ label: "S&P 500", data: d.history.close, fill: "rgba(255,160,40,.08)" }]);
  }).catch(() => {});
};

pages.eqty = async (gen) => {
  PAGE.innerHTML = `<div class="loading">Loading equities...</div>`;
  const d = await api("/api/equities");
  if (gen !== state.gen) return;
  const G = Array.isArray(d.groups) ? d.groups : [];
  const sectors = G.find((g) => g.title === "S&P Sectors");
  const heat = sectors ? `<div class="heat">${sectors.rows.filter((r) => !r.missing).map((r) => {
    const p = chgPct(r.last, r.prev);
    return `<div data-sym="${esc(r.sym)}" style="background:${heatColor(p)}"><b>${esc(r.name)}</b><span>${pct(p)}</span><small>${esc(r.sym)} &middot; YTD ${pct(chgPct(r.last, r.ytd), 1)}</small></div>`;
  }).join("")}</div>` : "";
  const mv = d.movers && !d.movers.error ? d.movers : {};
  const moverTable = (m) => {
    if (!m || !m.rows || !m.rows.length) return `<div class="loading">${esc((m && m.error) || "unavailable")}</div>`;
    return `<table class="t"><thead><tr><th>Symbol</th><th>Last</th><th>%Chg</th><th>Volume</th><th>Mkt Cap</th></tr></thead><tbody>${m.rows.map((r) => `
      <tr class="click" data-sym="${esc(r.sym)}"><td class="nm" title="${esc(r.name)}"><span class="amber">${esc(r.sym)}</span> <span class="muted">${esc((r.name || "").slice(0, 22))}</span></td>
      <td class="last">${fmt(r.last)}</td><td><span class="pill ${cls(r.chg)}">${pct(r.chg)}</span></td><td>${big(r.vol)}</td><td>${big(r.mcap)}</td></tr>`).join("")}</tbody></table>`;
  };
  const g = (t) => G.find((x) => x.title === t);
  PAGE.innerHTML = `<div class="grid">
    ${panel("Sector Heat Map - Today", heat, { cls: "c7", src: "SPDR sector ETFs" })}
    ${panel("Sector Performance - YTD", `<div class="chart-box short"><canvas id="sec-cv"></canvas></div>`, { cls: "c5" })}
    ${panel("Broad Market &amp; Factors", quoteTable(g("Broad Market & Factors"), { full: true }), { cls: "c6", src: "Yahoo Finance" })}
    ${panel("S&amp;P Sectors", quoteTable(g("S&P Sectors"), { full: true }), { cls: "c6", src: "Yahoo Finance" })}
    ${panel("Mega Caps", quoteTable(g("Mega Caps"), { full: true }), { cls: "c6", src: "Yahoo Finance" })}
    ${panel("International Equity", quoteTable(g("International Equity"), { full: true }), { cls: "c6", src: "Yahoo Finance" })}
    ${panel(mv.day_gainers?.title || "Top Gainers", moverTable(mv.day_gainers), { cls: "c4", src: "Yahoo screener" })}
    ${panel(mv.day_losers?.title || "Top Losers", moverTable(mv.day_losers), { cls: "c4", src: "Yahoo screener" })}
    ${panel(mv.most_actives?.title || "Most Active", moverTable(mv.most_actives), { cls: "c4", src: "Yahoo screener" })}
    ${watchlistPanel("c5")}
    ${panel("Equity Market News", `<div id="eq-news"><div class="loading">Loading...</div></div>`, { cls: "c7", scroll: true, maxh: 420 })}
  </div>`;
  if (sectors) {
    const rows = sectors.rows.filter((r) => !r.missing).map((r) => [r.name, chgPct(r.last, r.ytd)]).sort((a, b) => b[1] - a[1]);
    barChart("sec-cv", rows.map((r) => r[0]), rows.map((r) => +r[1].toFixed(2)));
  }
  bindWatchlist();
  newsPanel("eq-news", "equities", 40);
};

pages.govt = async (gen) => {
  PAGE.innerHTML = `<div class="loading">Loading Treasury &amp; rates data...</div>`;
  const d = await api("/api/govt");
  if (gen !== state.gen) return;
  const tenorT = `<table class="t"><thead><tr><th>Tenor</th><th>Yield</th><th>1D bp</th><th>1W bp</th><th>1M bp</th><th>1Y bp</th><th>3M</th></tr></thead><tbody>${
    d.tenors.map((r) => `<tr class="click" data-fred="${r.id}" data-name="${esc(r.name)} Yield" data-unit="%"><td class="nm">${esc(r.name)}</td>
      <td class="last">${fmt(r.value, 2)}%</td><td class="${cls(r.d1)}">${bp(r.d1)}</td><td class="${cls(r.w1)}">${bp(r.w1)}</td>
      <td class="${cls(r.m1)}">${bp(r.m1)}</td><td class="${cls(r.y1)}">${bp(r.y1)}</td><td class="spk">${spark(r.spark)}</td></tr>`).join("")}</tbody></table>`;
  const lvlTable = (rows, label) => `<table class="t"><thead><tr><th>${label}</th><th>Latest</th><th>Prior</th><th>1Y Ago</th><th>As Of</th><th>Trend</th></tr></thead><tbody>${
    rows.map((r) => `<tr class="click" data-fred="${r.id}" data-name="${esc(r.name)}" data-unit="${r.unit}"><td class="nm">${esc(r.name)}</td>
      <td class="last">${fmt(r.value, 2)}${r.unit}</td><td>${fmt(r.prev, 2)}${r.unit}</td><td>${fmt(r.yago, 2)}${r.unit}</td>
      <td class="muted">${esc(r.date)}</td><td class="spk">${spark(r.spark)}</td></tr>`).join("")}</tbody></table>`;
  const c = d.curve;
  const s2 = c.now[c.tenors.indexOf("2Y")], s10 = c.now[c.tenors.indexOf("10Y")], s3m = c.now[c.tenors.indexOf("3M")];
  PAGE.innerHTML = `<div class="grid">
    ${panel(`US Treasury Yield Curve <span class="muted">(${esc(c.date || "")})</span>`, `<div class="chart-box tall"><canvas id="curve-cv"></canvas></div>
      <div class="note">2s10s: <b>${bp(isNum(s10) && isNum(s2) ? (s10 - s2) * 100 : null)} bp</b> &nbsp; 3m10y: <b>${bp(isNum(s10) && isNum(s3m) ? (s10 - s3m) * 100 : null)} bp</b> &nbsp;
      ${isNum(s10) && isNum(s3m) && s10 < s3m ? "Curve is <b>inverted</b> at the front end." : "Curve is <b>positively sloped</b> (10Y above 3M)."}</div>`, { cls: "c7", src: "US Treasury via FRED" })}
    ${panel("Treasury Yields by Tenor", tenorT, { cls: "c5", src: "FRED H.15" })}
    ${fredPanelHTML("govt-hist", "10-Year Treasury")}
    ${panel("Policy, Spreads &amp; Inflation Expectations", lvlTable(d.rates, "Rate"), { cls: "c6", src: "FRED" })}
    ${panel("Global 10Y Government Yields (monthly)", lvlTable(d.global, "Country"), { cls: "c6", src: "OECD via FRED" })}
    ${groupsPanels(d.etfs, { cls: "c6", full: true })}
    ${panel("Rates &amp; Bond Market News", `<div id="govt-news"><div class="loading">Loading...</div></div>`, { cls: "c12", scroll: true, maxh: 400 })}
  </div>`;
  $("#govt-hist").classList.add("c6");
  lineChart("curve-cv", c.tenors, [
    { label: "Current", data: c.now, pointRadius: 3, borderWidth: 2.2 },
    { label: "1 Week Ago", data: c.w1, color: "#5cb3ff", dash: [4, 3] },
    { label: "1 Month Ago", data: c.m1, color: "#c084fc", dash: [4, 3] },
    { label: "1 Year Ago", data: c.y1, color: "#6b6b72", dash: [2, 3] },
  ], { unit: "%", xticks: 12 });
  bindFredYears("govt-hist");
  loadFred("govt-hist", "DGS10", "lvl", "10-Year Treasury Yield", "%", 5);
  newsPanel("govt-news", "govt", 40);
};

pages.corp = async (gen) => {
  PAGE.innerHTML = `<div class="loading">Loading corporate credit data...</div>`;
  const d = await api("/api/corp");
  if (gen !== state.gen) return;
  const oas = d.credit.filter((r) => r.kind === "oas"), ylds = d.credit.filter((r) => r.kind === "yield");
  const yrs = Math.round((d.credit[0] && d.credit[0].pct_years) || 3);
  const ctable = (rows, isY) => `<table class="t"><thead><tr><th>Index (ICE BofA)</th><th>${isY ? "Yield" : "OAS bp"}</th><th>1D</th><th>1W</th><th>1M</th><th>1Y</th>
    <th title="Percentile of current level vs. available history (~${yrs} years on FRED; 0 = lowest)">${yrs}Y %ile</th><th>6M</th></tr></thead><tbody>${rows.map((r) => {
      const ctrend = (v) => `<td class="${isY ? cls(v) : cls(-v)}">${bp(v)}</td>`; // wider spreads = red
      return `<tr class="click" data-fred="${r.id}" data-name="${esc(r.name)}" data-unit="${isY ? "%" : "bp"}">
      <td class="nm">${esc(r.name)}</td><td class="last">${isY ? fmt(r.value, 2) + "%" : fmt(r.value * 100, 0)}</td>
      ${ctrend(r.d1)}${ctrend(r.w1)}${ctrend(r.m1)}${ctrend(r.y1)}
      <td>${isNum(r.pct5y) ? `<span class="pill ${r.pct5y > 70 ? "down" : r.pct5y < 30 ? "up" : ""}">${fmt(r.pct5y, 0)}</span>` : "--"}</td>
      <td class="spk">${spark(r.spark)}</td></tr>`;
    }).join("")}</tbody></table>`;
  const hy = oas.find((r) => r.id === "BAMLH0A0HYM2"), ig = oas.find((r) => r.id === "BAMLC0A0CM");
  const read = hy && ig ? `<div class="note">IG spreads at <b>${fmt(ig.value * 100, 0)} bp</b> and HY at <b>${fmt(hy.value * 100, 0)} bp</b>.
    HY OAS is in the <b>${fmt(hy.pct5y, 0)}th</b> percentile of its ~${yrs}-year range -
    ${hy.pct5y < 25 ? "spreads are tight vs. recent history: investors are being paid little for credit risk; strong risk appetite." :
      hy.pct5y > 75 ? "spreads are wide vs. recent history: credit is pricing in more default risk than usual lately." :
      "spreads are mid-range relative to recent history."}
    Spread changes are shown in bp; <span class="up">green</span> = tightening, <span class="down">red</span> = widening.</div>` : "";
  PAGE.innerHTML = `<div class="grid">
    ${panel("Corporate Option-Adjusted Spreads", ctable(oas, false) + read, { cls: "c7", src: "ICE BofA via FRED" })}
    <div class="c5 stack">
      ${panel("Corporate Effective Yields", ctable(ylds, true), { src: "ICE BofA via FRED" })}
      ${fredPanelHTML("corp-hist", "High Yield OAS")}
    </div>
    ${groupsPanels(d.etfs, { cls: "c7", full: true })}
    ${panel("Credit Market News", `<div id="corp-news"><div class="loading">Loading...</div></div>`, { cls: "c5", scroll: true, maxh: 430 })}
  </div>`;
  bindFredYears("corp-hist");
  loadFred("corp-hist", "BAMLH0A0HYM2", "lvl", "High Yield OAS", "bp", 2);
  newsPanel("corp-news", "credit", 40);
};

pages.priv = async (gen) => {
  PAGE.innerHTML = `<div class="loading">Loading private markets data...</div>`;
  const d = await api("/api/private");
  if (gen !== state.gen) return;
  const G = Array.isArray(d.groups) ? d.groups : [];
  const macroT = `<table class="t"><thead><tr><th>Indicator</th><th>Latest</th><th>Prior</th><th>1Y Ago</th><th>As Of</th><th>Trend</th></tr></thead><tbody>${
    d.macro.map((r) => `<tr class="click" data-fred="${r.id}" data-tf="${r.tf}" data-name="${esc(r.name)}" data-unit="${r.unit}"><td class="nm">${esc(r.name)}</td>
      <td class="last">${fmt(r.value, 2)}${r.unit}</td><td>${fmt(r.prev, 2)}${r.unit}</td><td>${fmt(r.yago, 2)}${r.unit}</td>
      <td class="muted">${esc(r.date)}</td><td class="spk">${spark(r.spark)}</td></tr>`).join("")}</tbody></table>`;
  const g = (t) => G.find((x) => x.title === t);
  PAGE.innerHTML = `<div class="grid">
    ${panel("About Private Markets Data", `<div class="note">Private equity, private credit and venture assets have no public daily prices.
      This page tracks them through <b>listed proxies</b>: the alternative-asset managers that run the funds (fundraising/AUM sentiment),
      <b>BDCs</b> (publicly traded private-credit lenders - their price vs. NAV and yields reflect direct-lending health),
      listed PE / IPO ETFs (exit-market conditions), plus <b>bank lending standards</b> (tighter bank credit pushes borrowers to private credit)
      and live deal / fundraising news.</div>`, { cls: "c12" })}
    ${panel("Alternative Asset Managers", quoteTable(g("Alternative Asset Managers"), { full: true }), { cls: "c6", src: "Yahoo Finance" })}
    ${panel("Private Credit / BDCs", quoteTable(g("Private Credit / BDCs"), { full: true }), { cls: "c6", src: "Yahoo Finance" })}
    ${panel("Listed PE / Exit Market Proxies", quoteTable(g("Listed PE / Exit Market Proxies"), { full: true }), { cls: "c6", src: "Yahoo Finance" })}
    ${panel("Credit Conditions (Private Credit Backdrop)", macroT, { cls: "c6", src: "Fed SLOOS / FRED" })}
    ${fredPanelHTML("priv-hist", "Banks Tightening C&I Loans")}
    ${panel("PE / Private Credit / VC Deal Flow &amp; News", `<div id="priv-news"><div class="loading">Loading...</div></div>`, { cls: "c6", scroll: true, maxh: 520, src: "Crunchbase / Google News" })}
  </div>`;
  $("#priv-hist").classList.add("c6");
  bindFredYears("priv-hist");
  loadFred("priv-hist", "DRTSCILM", "lvl", "Net % of Banks Tightening C&I Loans", "%", 10);
  newsPanel("priv-news", "private", 50);
};

function econFmt(v, unit) {
  if (!isNum(v)) return "--";
  if (unit === "%") return fmt(v, 2) + "%";
  if (unit === "k") return fmt(v, 0) + "k";
  if (unit === "$bn") return "$" + fmt(v, 0);
  return Math.abs(v) >= 1000 ? fmt(v, 0) : fmt(v, 2);
}
function econTable(rows, withCats = true) {
  let h = `<table class="t"><thead><tr><th>Indicator</th><th>Latest</th><th>Prior</th><th>1Y Ago</th><th>Period</th>${withCats ? "<th>Trend (3Y)</th>" : ""}</tr></thead><tbody>`;
  let cat = null;
  for (const r of rows) {
    if (withCats && r.cat !== cat) { cat = r.cat; h += `<tr class="cat"><td colspan="6">${esc(cat)}</td></tr>`; }
    if (r.missing) { h += `<tr><td class="nm">${esc(r.name)}</td><td colspan="5" class="muted">unavailable</td></tr>`; continue; }
    const ch = isNum(r.value) && isNum(r.prev) ? r.value - r.prev : null;
    h += `<tr class="click" data-fred="${r.id}" data-tf="${r.tf}" data-name="${esc(r.name)}" data-unit="${r.unit}">
      <td class="nm" title="FRED: ${esc(r.id)}">${esc(r.name)}</td>
      <td class="last">${econFmt(r.value, r.unit)} <span class="${cls(ch)}" style="font-size:10px">${isNum(ch) && ch !== 0 ? (ch > 0 ? "&#9650;" : "&#9660;") : ""}</span></td>
      <td>${econFmt(r.prev, r.unit)}</td><td>${econFmt(r.yago, r.unit)}</td><td class="muted">${esc((r.date || "").slice(0, 7))}</td>
      ${withCats ? `<td class="spk">${spark(r.spark)}</td>` : ""}</tr>`;
  }
  return h + "</tbody></table>";
}

pages.econ = async (gen) => {
  PAGE.innerHTML = `<div class="loading">Loading economic data...</div>`;
  const d = await api("/api/econ");
  if (gen !== state.gen) return;
  const o = d.outlook;
  const sigs = o.signals.map((s) => `<div class="sig"><span class="lamp ${s.status}"></span><span>${esc(s.name)}</span><span class="v">${esc(s.value)}</span><span class="tx">${esc(s.text)}</span></div>`).join("");
  PAGE.innerHTML = `<div class="grid">
    ${panel("Key US Economic Indicators", econTable(d.indicators), { cls: "c7", src: "BEA / BLS / Fed / UMich via FRED" })}
    <div class="c5 stack">
      ${panel("Macro Outlook - Signal Dashboard", `<div class="regime ${o.regime_status}">${esc(o.regime)}
        <div class="muted" style="font-size:11px;font-weight:400;margin-top:3px">${o.greens} of ${o.total} signals supportive, ${o.reds} flashing red</div></div>${sigs}
        <div class="note">Rule-based read of leading/coincident indicators (yield curve, Sahm rule, inflation vs. target, GDPNow nowcast,
        credit spreads, financial conditions, real policy rate, recession-probability model). Not investment advice.</div>`, { src: "computed" })}
      ${fredPanelHTML("econ-hist", "CPI YoY")}
    </div>
    ${panel("Economic Outlook &amp; Forecasts - News", `<div id="econ-news"><div class="loading">Loading...</div></div>`, { cls: "c12", scroll: true, maxh: 460, src: "CNBC / Federal Reserve / IMF / OECD / Google News" })}
  </div>`;
  bindFredYears("econ-hist");
  loadFred("econ-hist", "CPIAUCSL", "yoy", "CPI YoY", "%", 10);
  newsPanel("econ-news", "econ", 50);
};

const TOPICS = [["top", "Top Stories"], ["equities", "Equities"], ["govt", "Rates/Treasuries"], ["credit", "Corporate Credit"], ["private", "Private Markets"], ["econ", "Economy/Outlook"]];
pages.news = async (gen) => {
  PAGE.innerHTML = `<div class="grid">${panel("News Wire",
    `<div id="news-all"><div class="loading">Loading...</div></div>`,
    { cls: "c12", tools: `<span class="seg" id="news-seg">${TOPICS.map(([k, l]) => `<button data-t="${k}" class="${k === state.newsTopic ? "on" : ""}">${l}</button>`).join("")}</span>` })}</div>`;
  $$("#news-seg button").forEach((b) => (b.onclick = () => {
    state.newsTopic = b.dataset.t;
    $$("#news-seg button").forEach((x) => x.classList.toggle("on", x === b));
    $("#news-all").innerHTML = `<div class="loading">Loading...</div>`;
    newsPanel("news-all", state.newsTopic, 60);
  }));
  await newsPanel("news-all", state.newsTopic, 60);
};

pages.help = async () => {
  PAGE.innerHTML = `<div class="grid">${panel("Help - Commands &amp; Shortcuts", `<table class="t help"><tbody>
    <tr><td>F1 / MKTS</td><td>Market overview: indices, yields, commodities, FX, crypto, macro snapshot, watchlist, headlines</td></tr>
    <tr><td>F2 / EQTY</td><td>Equities: sector heat map, factors, mega caps, international, top gainers/losers/actives</td></tr>
    <tr><td>F3 / GOVT</td><td>Treasury yield curve, tenor yields, Fed policy rates, breakevens, global 10Y yields, Treasury ETFs</td></tr>
    <tr><td>F4 / CORP</td><td>Corporate bonds: ICE BofA IG/HY/rating-bucket spreads &amp; yields, credit ETFs, credit news</td></tr>
    <tr><td>F5 / PRIV</td><td>Private markets: alt managers, BDCs/private credit, PE/IPO proxies, bank lending standards, deal news</td></tr>
    <tr><td>F6 / ECON</td><td>Economic indicators (growth, inflation, labor, policy, risk) + macro outlook signal dashboard</td></tr>
    <tr><td>F7 / NEWS</td><td>Aggregated news wire by topic</td></tr>
    <tr><td>EXT</td><td>Pre-market &amp; after-hours: futures, ETFs, mega caps and watchlist in extended hours, extended-hours movers, session-coloured 5-day chart</td></tr>
    <tr><td>COMP</td><td>Compare securities: rebased performance, return/risk stats, correlation matrix. e.g. <b>COMP AAPL MSFT NVDA</b></td></tr>
    <tr><td>EVTS</td><td>Calendars: earnings (by market cap), economic releases by region, IPOs, your watchlist's next earnings</td></tr>
    <tr><td>EQS</td><td>Equity screener: Yahoo preset screens or custom filters (sector, size, P/E, yield, growth, momentum)</td></tr>
    <tr><td>ALRT</td><td>Price alerts with desktop notifications (price above/below, daily % move)</td></tr>
    <tr><td>&lt;TICKER&gt; Enter</td><td>Security page (chart, fundamentals, analyst targets, news). e.g. AAPL, BRK-B, ^GSPC, EURUSD=X, CL=F, BTC-USD</td></tr>
    <tr><td>&lt;TICKER&gt; &lt;FN&gt;</td><td>Jump straight to a security function, e.g. <b>AAPL FA</b>, <b>TSLA OMON</b>, <b>KO DVD</b>. Typing just the function (e.g. <b>ANR</b>) applies it to the current security.</td></tr>
    <tr><td>DES</td><td>Description: overview, chart with studies, key stats, analyst consensus, news</td></tr>
    <tr><td>GP / HP</td><td>Chart with SMA 20/50/200, Bollinger bands, volume, RSI, MACD, technical summary and historical price table (CSV export)</td></tr>
    <tr><td>FA</td><td>Financial analysis: income statement, balance sheet, cash flow, margins and ratios (annual / quarterly)</td></tr>
    <tr><td>ERN / EE</td><td>Earnings history &amp; surprises, next report date, consensus EPS/revenue estimates, estimate revisions</td></tr>
    <tr><td>ANR</td><td>Analyst ratings: consensus, price targets, recommendation trend, upgrades/downgrades</td></tr>
    <tr><td>OMON</td><td>Option monitor: chain by expiry, implied vol, expected move, put/call ratios, max pain, volatility smile, OI by strike</td></tr>
    <tr><td>HDS</td><td>Holders: institutions, mutual funds, insider transactions; fund top holdings and sector weights for ETFs</td></tr>
    <tr><td>DVD</td><td>Dividends: yield, payout, growth rates, increase streak, history, splits</td></tr>
    <tr><td>RV</td><td>Relative value vs industry peers (valuation, margins, growth) with scatter plots; add your own peers</td></tr>
    <tr><td>Type a name</td><td>Autocomplete search (e.g. "apple", "blackstone")</td></tr>
    <tr><td>Click any row</td><td>Opens the security page or loads that data series into the history chart</td></tr>
    <tr><td>/ or Esc</td><td>Focus command line</td></tr>
    <tr><td>Ctrl+R / REFRESH</td><td>Refresh current page (auto-refreshes every 60s)</td></tr>
    </tbody></table>
    <div class="note">Data: Yahoo Finance (prices, quotes, fundamentals), FRED / St. Louis Fed (Treasury, ICE BofA credit indices, BEA, BLS, Fed data),
    RSS from CNBC, MarketWatch, Yahoo Finance, Federal Reserve, Crunchbase News and Google News. Quotes may be delayed ~15 min. For information only - not investment advice.</div>`,
    { cls: "c12" })}</div>`;
};

const STAT_ROWS = [
  ["Market Cap", "marketCap", big], ["Enterprise Value", "enterpriseValue", big], ["P/E (TTM)", "trailingPE", (v) => fmt(v, 1)],
  ["P/E (Fwd)", "forwardPE", (v) => fmt(v, 1)], ["PEG", "pegRatio", (v) => fmt(v, 2)], ["Price/Book", "priceToBook", (v) => fmt(v, 2)],
  ["Price/Sales", "priceToSalesTrailing12Months", (v) => fmt(v, 2)], ["EV/EBITDA", "enterpriseToEbitda", (v) => fmt(v, 1)],
  ["EPS (TTM)", "trailingEps", (v) => fmt(v, 2)], ["EPS (Fwd)", "forwardEps", (v) => fmt(v, 2)],
  ["Dividend Yield", "dividendYield", (v) => fmt(v, 2) + "%"], ["Payout Ratio", "payoutRatio", (v) => fmt(v * 100, 1) + "%"],
  ["Beta", "beta", (v) => fmt(v, 2)], ["52W High", "fiftyTwoWeekHigh", fmt], ["52W Low", "fiftyTwoWeekLow", fmt],
  ["50D Avg", "fiftyDayAverage", fmt], ["200D Avg", "twoHundredDayAverage", fmt], ["Avg Volume", "averageVolume", big],
  ["Shares Out", "sharesOutstanding", big], ["Short % Float", "shortPercentOfFloat", (v) => fmt(v * 100, 2) + "%"],
  ["Revenue (TTM)", "totalRevenue", big], ["Revenue Growth", "revenueGrowth", (v) => pct(v * 100, 1)],
  ["Earnings Growth", "earningsGrowth", (v) => pct(v * 100, 1)], ["Gross Margin", "grossMargins", (v) => fmt(v * 100, 1) + "%"],
  ["Operating Margin", "operatingMargins", (v) => fmt(v * 100, 1) + "%"], ["Profit Margin", "profitMargins", (v) => fmt(v * 100, 1) + "%"],
  ["ROE", "returnOnEquity", (v) => fmt(v * 100, 1) + "%"], ["EBITDA", "ebitda", big], ["Free Cash Flow", "freeCashflow", big],
  ["Total Cash", "totalCash", big], ["Total Debt", "totalDebt", big], ["Debt/Equity", "debtToEquity", (v) => fmt(v, 1)],
  ["Fund AUM", "totalAssets", big], ["Fund Yield", "yield", (v) => fmt(v * 100, 2) + "%"], ["Expense Ratio", "netExpenseRatio", (v) => fmt(v, 2) + "%"],
  ["Category", "category", esc], ["Fund Family", "fundFamily", esc], ["Employees", "fullTimeEmployees", (v) => fmt(v, 0)],
];

/* ================================================================== security functions (DES / GP / FA / ...) */
const enc = encodeURIComponent;
const arr = (x) => (Array.isArray(x) ? x : []);
const lastNum = (a) => { for (let k = (a || []).length - 1; k >= 0; k--) if (isNum(a[k])) return a[k]; return null; };
const fp = (v, d = 1) => (isNum(v) ? fmt(v * 100, d) + "%" : "--"); // fraction -> %
const SEC_FNS = [["des", "DES", "Description"], ["gp", "GP", "Chart"], ["fa", "FA", "Financials"], ["ern", "ERN", "Earnings"],
  ["anr", "ANR", "Analysts"], ["omon", "OMON", "Options"], ["hds", "HDS", "Holders"], ["dvd", "DVD", "Dividends"],
  ["rv", "RV", "Peers"], ["comp", "COMP", "Compare"]];
const SEC_FN_KEYS = SEC_FNS.map((x) => x[0]).filter((k) => k !== "comp");
const GP_RANGES = ["1D", "5D", "1M", "3M", "6M", "YTD", "1Y", "2Y", "5Y", "MAX"];
const SECTOR_ETF = { Technology: "XLK", "Financial Services": "XLF", Healthcare: "XLV", Energy: "XLE", Industrials: "XLI",
  "Consumer Cyclical": "XLY", "Consumer Defensive": "XLP", Utilities: "XLU", "Real Estate": "XLRE",
  "Basic Materials": "XLB", "Communication Services": "XLC" };
const secPages = {};

function secData(sym) { return api(`/api/security?symbol=${enc(sym)}&range=1M`); }
const soft = (p) => p.catch((e) => ({ error: e.message || String(e) }));

function segHTML(id, items, cur) {
  return `<span class="seg" id="${id}">${items.map((x) => {
    const [v, l] = Array.isArray(x) ? x : [x, x];
    return `<button data-v="${esc(v)}" class="${String(v) === String(cur) ? "on" : ""}">${esc(l)}</button>`;
  }).join("")}</span>`;
}
function bindSeg(id, fn) { $$(`#${id} button`).forEach((b) => (b.onclick = () => fn(b.dataset.v))); }

function fmtKind(v, kind) {
  if (!isNum(v)) return "--";
  if (kind === "pct") return fmt(v, 1) + "%";
  if (kind === "x") return fmt(v, 2) + "x";
  if (kind === "eps") return fmt(v, 2);
  return big(v);
}

function secHead(sym, d) {
  const i = d.info || {}, cl = (d.history && d.history.close) || [];
  state.secInfo = i;
  const last = i.regularMarketPrice ?? i.currentPrice ?? lastNum(cl);
  const prev = i.previousClose;
  const ch = isNum(last) && isNum(prev) ? last - prev : null;
  const dg = pxDigits(sym, last);
  const inWL = getWL().includes(sym);
  $("#tab-des-label").textContent = sym;
  return `<section class="panel c12"><div class="des-head">
      <span class="amber" style="font-size:18px">${esc(sym)}</span><span class="nm">${esc(i.longName || i.shortName || sym)}</span>
      <span class="px">${fmt(last, dg)}</span>
      <span class="ch ${cls(ch)}">${isNum(ch) ? sign(ch) + fmt(ch, dg) : ""} (${pct(chgPct(last, prev))})</span>
      <span class="muted">${esc([i.exchange, i.currency, i.quoteType, i.sector, i.industry].filter(Boolean).join(" | "))}</span>
      <span style="margin-left:auto"><button class="btn" id="wl-toggle">${inWL ? "&#10003; IN WATCHLIST" : "+ WATCHLIST"}</button></span>
    </div>
    <div class="fn-strip">${SEC_FNS.map(([k, c, l]) => `<button data-fn="${k}" class="${k === state.fn ? "on" : ""}"><b>${c}</b>${l}</button>`).join("")}</div></section>`;
}
function bindSecHead(sym) {
  $$(".fn-strip button").forEach((b) => (b.onclick = () => (b.dataset.fn === "comp" ? goComp(compDefaults(sym)) : goFn(sym, b.dataset.fn))));
  const w = $("#wl-toggle");
  if (w) w.onclick = () => {
    const wl = getWL();
    setWL(wl.includes(sym) ? wl.filter((x) => x !== sym) : [...wl, sym]);
    w.innerHTML = getWL().includes(sym) ? "&#10003; IN WATCHLIST" : "+ WATCHLIST";
  };
}
function compDefaults(sym) {
  return [...new Set([sym, "SPY", SECTOR_ETF[(state.secInfo || {}).sector]].filter(Boolean))];
}
/* page shell when the function's own data failed */
function secError(sym, d, title, e, note = "") {
  PAGE.innerHTML = `<div class="grid">${secHead(sym, d)}${panel(title, errBox(e) + (note ? `<div class="note">${note}</div>` : ""), { cls: "c12" })}</div>`;
  bindSecHead(sym);
}

/* ---- chart studies */
const STUDY_KEY = "mt.studies";
const STUDIES = [["sma20", "SMA20"], ["sma50", "SMA50"], ["sma200", "SMA200"], ["bb", "BOLL"]];
function getStudies() {
  try { const v = JSON.parse(localStorage.getItem(STUDY_KEY)); if (v && typeof v === "object") return v; } catch (e) { /* ignore */ }
  return { sma50: true, sma200: true };
}
function setStudies(v) { try { localStorage.setItem(STUDY_KEY, JSON.stringify(v)); } catch (e) { /* ignore */ } }
function studyTools() {
  const st = getStudies();
  return `<span class="seg" id="study-seg">${STUDIES.map(([k, l]) => `<button data-k="${k}" class="${st[k] ? "on" : ""}">${l}</button>`).join("")}</span>`;
}
function bindStudies(redraw) {
  $$("#study-seg button").forEach((b) => (b.onclick = () => {
    const st = getStudies();
    st[b.dataset.k] = !st[b.dataset.k];
    setStudies(st);
    b.classList.toggle("on", !!st[b.dataset.k]);
    redraw();
  }));
}
function gpChange(g) {
  const L = lastNum(g.close);
  return chgPct(L, isNum(g.prev_close) ? g.prev_close : (g.close || []).find(isNum));
}
function priceChart(id, g, extra = []) {
  const st = getStudies();
  const up = (gpChange(g) ?? 0) >= 0;
  const ds = [{ label: g.symbol, data: g.close, color: up ? "#34d27b" : "#ff5252", fill: up ? "rgba(52,210,123,.06)" : "rgba(255,82,82,.06)", borderWidth: 1.8 }];
  if (st.sma20) ds.push({ label: "SMA 20", data: g.sma20, color: "#c084fc", borderWidth: 1 });
  if (st.sma50) ds.push({ label: "SMA 50", data: g.sma50, color: "#5cb3ff", borderWidth: 1 });
  if (st.sma200) ds.push({ label: "SMA 200", data: g.sma200, color: "#ffd84a", borderWidth: 1 });
  if (st.bb) ds.push({ label: "Boll Upper", data: g.bbu, color: "#8b8b92", dash: [3, 3], borderWidth: 1 },
    { label: "Boll Lower", data: g.bbl, color: "#8b8b92", dash: [3, 3], borderWidth: 1 });
  if (isNum(g.prev_close)) ds.push({ label: "Prev Close", data: g.labels.map(() => g.prev_close), color: "#55555c", dash: [2, 4], borderWidth: 1 });
  ds.push(...extra);
  const dg = pxDigits(g.symbol, lastNum(g.close));
  lineChart(id, g.labels, ds, { digits: dg, ydigits: dg, xticks: 10, yWidth: 64 });
}

/* ---- DES: description / overview */
secPages.des = async (gen, sym) => {
  const [d, g] = await Promise.all([secData(sym), soft(api(`/api/gp?symbol=${enc(sym)}&range=${state.range}`))]);
  if (gen !== state.gen) return;
  const i = d.info || {};
  const last = i.regularMarketPrice ?? i.currentPrice ?? lastNum(g.close);
  const rngChg = g.error ? null : gpChange(g);
  const stats = STAT_ROWS.filter(([, k]) => i[k] !== undefined && i[k] !== null).map(([l, k, f]) => `<div><span>${l}</span><span>${f(i[k])}</span></div>`).join("");
  const tgt = isNum(i.targetMeanPrice) ? `<div class="kv">
      <div><span>Consensus</span><span class="amber">${esc((i.recommendationKey || "").replace("_", " ").toUpperCase())}</span></div>
      <div><span># Analysts</span><span>${fmt(i.numberOfAnalystOpinions, 0)}</span></div>
      <div><span>Target Mean</span><span>${fmt(i.targetMeanPrice)}</span></div>
      <div><span>Implied Upside</span><span class="${cls(chgPct(i.targetMeanPrice, last))}">${pct(chgPct(i.targetMeanPrice, last), 1)}</span></div>
      <div><span>Target High</span><span>${fmt(i.targetHighPrice)}</span></div><div><span>Target Low</span><span>${fmt(i.targetLowPrice)}</span></div></div>` : "";
  PAGE.innerHTML = `<div class="grid">
    ${secHead(sym, d)}
    ${panel(`Price Chart <span class="${cls(rngChg)}" style="margin-left:8px">${pct(rngChg)} ${state.range === "1D" ? "today" : "over " + state.range}</span>`,
      g.error ? errBox(g.error) : `<div class="chart-box tall"><canvas id="des-cv"></canvas></div><div class="chart-box mini"><canvas id="des-vol"></canvas></div>`,
      { cls: "c8", tools: segHTML("rng-seg", GP_RANGES, state.range) + studyTools() })}
    <div class="c4 stack">
      ${panel("Key Statistics", stats ? `<div class="kv">${stats}</div>` : `<div class="loading">No fundamentals for this instrument</div>`, { scroll: true, maxh: 470, src: "Yahoo Finance" })}
    </div>
    <div class="c6 stack">
      ${tgt ? panel("Analyst Consensus", tgt, { tools: `<a href="#/des/${enc(sym)}/anr" class="muted" style="font-size:11px">ANR &rsaquo;</a>` }) : ""}
      ${i.longBusinessSummary ? panel("Description", `<div class="desc">${esc(i.longBusinessSummary)}</div>${i.website ? `<div class="note"><a href="${esc(i.website)}" target="_blank">${esc(i.website)}</a></div>` : ""}`) : ""}
    </div>
    ${panel(`${esc(sym)} News`, newsList(d.news, 15), { cls: "c6", scroll: true, maxh: 420 })}
  </div>`;
  bindSecHead(sym);
  const draw = () => { if (!g.error) { priceChart("des-cv", g); volChart("des-vol", g.labels, g.volume, g.close, 64); } };
  draw();
  bindStudies(draw);
  bindSeg("rng-seg", (v) => { state.range = v; render(); });
};

/* ---- GP: full chart with studies + HP table */
function techSummary(g) {
  const L = lastNum(g.close), s50 = lastNum(g.sma50), s200 = lastNum(g.sma200), r = lastNum(g.rsi);
  const m = lastNum(g.macd), sg = lastNum(g.signal), bu = lastNum(g.bbu), bl = lastNum(g.bbl);
  const rows = [];
  const add = (k, v, c = "") => rows.push(`<div><span>${k}</span><span class="${c}">${v}</span></div>`);
  if (isNum(s50)) add("Price vs SMA 50", pct(chgPct(L, s50), 1), cls(L - s50));
  if (isNum(s200)) add("Price vs SMA 200", pct(chgPct(L, s200), 1), cls(L - s200));
  if (isNum(s50) && isNum(s200)) add("50 / 200 Day Trend", s50 > s200 ? "Golden cross (bullish)" : "Death cross (bearish)", s50 > s200 ? "up" : "down");
  if (isNum(r)) add("RSI (14)", `${fmt(r, 1)} ${r > 70 ? "- overbought" : r < 30 ? "- oversold" : "- neutral"}`, r > 70 ? "down" : r < 30 ? "up" : "");
  if (isNum(m) && isNum(sg)) add("MACD vs Signal", m > sg ? "Above (bullish momentum)" : "Below (bearish momentum)", m > sg ? "up" : "down");
  if (isNum(bu) && isNum(bl) && bu !== bl) add("Bollinger %B", fmt(((L - bl) / (bu - bl)) * 100, 0) + "%");
  const cl = (g.close || []).filter(isNum);
  if (cl.length) { add("Range High", fmt(Math.max(...cl), pxDigits(g.symbol, L))); add("Range Low", fmt(Math.min(...cl), pxDigits(g.symbol, L))); }
  const v = (g.volume || []).filter(isNum);
  if (v.length > 1) { const avg = v.reduce((a, b) => a + b, 0) / v.length; if (avg) add("Last Volume vs Avg", fmt(v[v.length - 1] / avg, 2) + "x"); }
  return `<div class="kv one">${rows.join("")}</div><div class="note">Mechanical readings of price history - not recommendations.</div>`;
}
function hpRows(g) {
  const out = [];
  for (let k = g.labels.length - 1; k >= 0; k--) out.push([g.labels[k], g.open[k], g.high[k], g.low[k], g.close[k], k ? chgPct(g.close[k], g.close[k - 1]) : null, g.volume[k]]);
  return out;
}
function hpTable(g) {
  const dg = pxDigits(g.symbol, lastNum(g.close));
  return `<table class="t"><thead><tr><th>Date</th><th>Open</th><th>High</th><th>Low</th><th>Close</th><th>%Chg</th><th>Volume</th></tr></thead><tbody>${
    hpRows(g).slice(0, 500).map((r) => `<tr><td class="muted">${esc(r[0])}</td><td>${fmt(r[1], dg)}</td><td>${fmt(r[2], dg)}</td><td>${fmt(r[3], dg)}</td>
      <td class="last">${fmt(r[4], dg)}</td><td class="${cls(r[5])}">${pct(r[5])}</td><td>${big(r[6])}</td></tr>`).join("")}</tbody></table>`;
}
secPages.gp = async (gen, sym) => {
  const [d, g] = await Promise.all([secData(sym), soft(api(`/api/gp?symbol=${enc(sym)}&range=${state.range}`))]);
  if (gen !== state.gen) return;
  if (g.error) return secError(sym, d, "Chart", g.error);
  const rc = gpChange(g);
  PAGE.innerHTML = `<div class="grid">
    ${secHead(sym, d)}
    ${panel(`Price <span class="${cls(rc)}" style="margin-left:8px">${pct(rc)} ${state.range === "1D" ? "today" : "over " + state.range}</span> <span class="muted">${esc(g.interval)} bars</span>`,
      `<div class="chart-box xtall"><canvas id="gp-cv"></canvas></div><div class="chart-box mini"><canvas id="gp-vol"></canvas></div>`,
      { cls: "c12", tools: segHTML("rng-seg", GP_RANGES, state.range) + studyTools(), src: "Yahoo Finance" })}
    ${panel("RSI (14)", `<div class="chart-box short"><canvas id="gp-rsi"></canvas></div>`, { cls: "c4" })}
    ${panel("MACD (12, 26, 9)", `<div class="chart-box short"><canvas id="gp-macd"></canvas></div>`, { cls: "c4" })}
    ${panel("Technical Summary", techSummary(g), { cls: "c4" })}
    ${panel("HP - Historical Prices", hpTable(g), { cls: "c12", scroll: true, maxh: 420, tools: `<button class="btn sm" id="hp-csv">CSV</button>` })}
  </div>`;
  bindSecHead(sym);
  const draw = () => { priceChart("gp-cv", g); volChart("gp-vol", g.labels, g.volume, g.close, 64); };
  draw();
  bindStudies(draw);
  bindSeg("rng-seg", (v) => { state.range = v; render(); });
  const flat = (v, c) => ({ label: String(v), data: g.labels.map(() => v), color: c, dash: [3, 3], borderWidth: 1, noTip: true });
  lineChart("gp-rsi", g.labels, [{ label: "RSI", data: g.rsi, color: "#c084fc" }, flat(70, "#ff5252aa"), flat(30, "#34d27baa")],
    { legend: false, digits: 1, ydigits: 0, xticks: 5, ymin: 0, ymax: 100 });
  vbar("gp-macd", g.labels, [
    { type: "line", label: "MACD", data: g.macd, borderColor: "#5cb3ff" },
    { type: "line", label: "Signal", data: g.signal, borderColor: "#ffa028" },
    { label: "Histogram", data: g.hist, backgroundColor: g.hist.map((v) => (v >= 0 ? "rgba(52,210,123,.6)" : "rgba(255,82,82,.6)")) },
  ], { legend: false, xticks: 5, fmt: (v) => fmt(v, 2) });
  $("#hp-csv").onclick = () => downloadCSV(`${sym}_${state.range}_prices.csv`, [["Date", "Open", "High", "Low", "Close", "PctChg", "Volume"], ...hpRows(g)]);
};

/* ---- FA: financial analysis */
secPages.fa = async (gen, sym) => {
  const per = state.faPer;
  const [d, f] = await Promise.all([secData(sym), soft(api(`/api/fa?symbol=${enc(sym)}&period=${per}`))]);
  if (gen !== state.gen) return;
  const tools = segHTML("fa-per", [["annual", "Annual"], ["quarterly", "Quarterly"]], per);
  if (f.error) {
    secError(sym, d, "Financial Statements", f.error, "Funds, indices, currencies and crypto have no company financial statements.");
    return;
  }
  const lbl = (p) => (per === "annual" ? "FY" + p.slice(0, 4) : p.slice(0, 7));
  const tbl = (key, st) => {
    if (!st || !st.rows.length) return `<div class="loading">Not reported</div>`;
    return `<table class="t"><thead><tr><th>${per === "annual" ? "Fiscal Year" : "Quarter End"}</th>${st.periods.map((p) => `<th>${lbl(p)}</th>`).join("")}<th>Trend</th></tr></thead><tbody>${
      st.rows.map((r, idx) => `<tr class="click" data-fa="${key}:${idx}"><td class="nm" title="${esc(r.name)}">${esc(r.name)}</td>${
        r.values.map((v) => `<td class="${isNum(v) && v < 0 ? "down" : ""}">${fmtKind(v, r.kind)}</td>`).join("")}<td class="spk">${spark(r.values, 70)}</td></tr>`).join("")}</tbody></table>`;
  };
  PAGE.innerHTML = `<div class="grid">
    ${secHead(sym, d)}
    ${panel("Revenue, Operating &amp; Net Income", `<div class="chart-box short"><canvas id="fa-rev"></canvas></div>`, { cls: "c6", tools, src: "Yahoo Finance" })}
    ${panel("Margins", `<div class="chart-box short"><canvas id="fa-mgn"></canvas></div>`, { cls: "c6" })}
    ${panel("Income Statement", tbl("income", f.income), { cls: "c6" })}
    ${panel("Balance Sheet", tbl("balance", f.balance), { cls: "c6" })}
    ${panel("Cash Flow Statement", tbl("cash", f.cash), { cls: "c6" })}
    <div class="c6 stack">
      ${panel("Key Ratios", tbl("ratios", f.ratios))}
      ${panel(`<span id="fa-sel-title">Line Item</span>`, `<div class="chart-box short"><canvas id="fa-sel"></canvas></div><div class="note">Click any line item to chart it.</div>`)}
    </div>
  </div>`;
  bindSecHead(sym);
  bindSeg("fa-per", (v) => { state.faPer = v; render(); });
  const row = (st, name) => ((f[st].rows || []).find((r) => r.name === name) || {}).values;
  const L = f.income.periods.map(lbl);
  vbar("fa-rev", L, [["Revenue", "#5cb3ff"], ["Operating Income", "#ffa028"], ["Net Income", "#34d27b"]]
    .map(([n, c]) => ({ label: n, data: row("income", n), backgroundColor: c })).filter((x) => x.data), { fmt: big });
  const R = f.ratios || { periods: [], rows: [] };
  lineChart("fa-mgn", R.periods.map(lbl), [["Gross Margin", "#5cb3ff"], ["Operating Margin", "#ffa028"], ["Net Margin", "#34d27b"], ["FCF Margin", "#c084fc"]]
    .map(([n, c]) => ({ label: n, data: (R.rows.find((r) => r.name === n) || {}).values, color: c, pointRadius: 3 })).filter((x) => x.data),
  { unit: "%", digits: 1, ydigits: 0 });
  const showSel = (key, idx) => {
    const st = f[key], r = st && st.rows[idx];
    if (!r) return;
    $("#fa-sel-title").textContent = r.name;
    vbar("fa-sel", st.periods.map(lbl), [{ label: r.name, data: r.values, backgroundColor: r.values.map((v) => (v < 0 ? "#dc3232" : "#ffa028")) }],
      { legend: false, fmt: (v) => fmtKind(v, r.kind) });
  };
  const fcf = (f.cash.rows || []).findIndex((r) => r.name === "Free Cash Flow");
  if (fcf >= 0) showSel("cash", fcf); else showSel("income", 0);
  $$("[data-fa]").forEach((tr) => (tr.onclick = () => {
    const [k, ix] = tr.dataset.fa.split(":");
    $$("tr.sel", PAGE).forEach((x) => x.classList.remove("sel"));
    tr.classList.add("sel");
    showSel(k, +ix);
  }));
};

/* ---- ERN: earnings history & estimates */
secPages.ern = async (gen, sym) => {
  const [d, e] = await Promise.all([secData(sym), soft(api(`/api/ern?symbol=${enc(sym)}`))]);
  if (gen !== state.gen) return;
  if (e.error) return secError(sym, d, "Earnings", e.error);
  const hist = arr(e.history);
  const past = hist.filter((h) => isNum(h.act)).sort((a, b) => a.date.localeCompare(b.date));
  const upcoming = hist.filter((h) => !isNum(h.act)).sort((a, b) => a.date.localeCompare(b.date));
  const c = e.calendar && !e.calendar.error ? e.calendar : {};
  const today = new Date().toISOString().slice(0, 10);
  const nextDate = arr(c.next).find((x) => x && x >= today) || (upcoming.find((u) => u.date >= today) || {}).date;
  const daysTo = nextDate ? Math.round((new Date(nextDate + "T12:00:00") - new Date()) / 864e5) : null;
  const scored = past.filter((h) => isNum(h.est)).slice(-12);
  const beats = scored.filter((h) => h.act > h.est).length;
  const surp = scored.map((h) => h.surprise).filter(isNum);
  const avgS = surp.length ? surp.reduce((a, b) => a + b, 0) / surp.length : null;
  const when = (t) => (!t ? "" : t >= "16:00" ? "AMC" : t < "09:30" ? "BMO" : t);
  const nextKV = `<div class="kv">
    <div><span>Next Report</span><span class="amber">${esc(nextDate || "--")}</span></div>
    <div><span>Days Until</span><span>${isNum(daysTo) ? daysTo : "--"}</span></div>
    <div><span>EPS Consensus</span><span>${fmt(c.eps_avg)}</span></div>
    <div><span>EPS Range</span><span>${fmt(c.eps_low)} - ${fmt(c.eps_high)}</span></div>
    <div><span>Revenue Consensus</span><span>${big(c.rev_avg)}</span></div>
    <div><span>Revenue Range</span><span>${big(c.rev_low)} - ${big(c.rev_high)}</span></div>
    <div><span>Beat Rate (last ${scored.length})</span><span class="${beats / (scored.length || 1) >= 0.5 ? "up" : "down"}">${beats} / ${scored.length}</span></div>
    <div><span>Avg EPS Surprise</span><span class="${cls(avgS)}">${pct(avgS, 1)}</span></div></div>`;
  const histT = `<table class="t"><thead><tr><th>Report Date</th><th>Time</th><th>EPS Est</th><th>EPS Actual</th><th>Surprise</th><th>Result</th></tr></thead><tbody>${
    [...upcoming.filter((u) => u.date >= today), ...past.slice().reverse()].map((h) => {
      const res = !isNum(h.act) ? `<span class="amber">UPCOMING</span>` : !isNum(h.est) ? "--" : h.act > h.est ? `<span class="up">BEAT</span>` : h.act < h.est ? `<span class="down">MISS</span>` : "IN LINE";
      return `<tr><td>${esc(h.date)}</td><td class="muted">${esc(when(h.time))}</td><td>${fmt(h.est)}</td><td class="last">${fmt(h.act)}</td>
        <td><span class="pill ${cls(h.surprise)}">${pct(h.surprise, 1)}</span></td><td>${res}</td></tr>`;
    }).join("")}</tbody></table>`;
  const estT = (rows, money) => (!arr(rows).length ? `<div class="loading">No estimates</div>` :
    `<table class="t"><thead><tr><th>Period</th><th>Consensus</th><th>Low</th><th>High</th><th>Year Ago</th><th>Growth</th><th># Est</th></tr></thead><tbody>${
      rows.map((r) => {
        const f2 = money ? big : (v) => fmt(v, 2);
        return `<tr><td class="nm">${esc(r.label)}</td><td class="last">${f2(r.avg)}</td><td>${f2(r.low)}</td><td>${f2(r.high)}</td>
          <td>${f2(money ? r.yearAgoRevenue : r.yearAgoEps)}</td><td class="${cls(r.growth)}">${isNum(r.growth) ? pct(r.growth * 100, 1) : "--"}</td><td>${fmt(r.numberOfAnalysts, 0)}</td></tr>`;
      }).join("")}</tbody></table>`);
  const revs = arr(e.revisions);
  const trendT = !arr(e.trend).length ? `<div class="loading">No estimate trend</div>` :
    `<table class="t"><thead><tr><th>EPS Est.</th><th>Now</th><th>7D Ago</th><th>30D Ago</th><th>60D Ago</th><th>90D Ago</th><th>90D Chg</th><th title="Analysts revising up / down in last 30 days">Up/Down 30D</th></tr></thead><tbody>${
      e.trend.map((r) => {
        const rv = revs.find((x) => x.period === r.period) || {};
        const ch90 = chgPct(r.current, r["90daysAgo"]);
        return `<tr><td class="nm">${esc(r.label)}</td><td class="last">${fmt(r.current)}</td><td>${fmt(r["7daysAgo"])}</td><td>${fmt(r["30daysAgo"])}</td>
          <td>${fmt(r["60daysAgo"])}</td><td>${fmt(r["90daysAgo"])}</td><td class="${cls(ch90)}">${pct(ch90, 1)}</td>
          <td><span class="up">${fmt(rv.upLast30days, 0)}</span> / <span class="down">${fmt(rv.downLast30days, 0)}</span></td></tr>`;
      }).join("")}</tbody></table>`;
  const growthT = !arr(e.growth).length ? "" :
    `<table class="t"><thead><tr><th>Growth Est.</th><th>${esc(sym)}</th><th>S&amp;P 500</th></tr></thead><tbody>${
      e.growth.map((r) => `<tr><td class="nm">${esc(r.label === "LTG" ? "Long-term (5Y p.a.)" : r.label)}</td><td class="${cls(r.stockTrend)}">${isNum(r.stockTrend) ? pct(r.stockTrend * 100, 1) : "--"}</td>
        <td class="${cls(r.indexTrend)}">${isNum(r.indexTrend) ? pct(r.indexTrend * 100, 1) : "--"}</td></tr>`).join("")}</tbody></table>`;
  PAGE.innerHTML = `<div class="grid">
    ${secHead(sym, d)}
    ${panel("Next Earnings", nextKV, { cls: "c4", src: "Yahoo Finance" })}
    ${panel("EPS - Estimate vs Actual", `<div class="chart-box short"><canvas id="ern-cv"></canvas></div>`, { cls: "c8" })}
    ${panel("Earnings History &amp; Surprises", histT, { cls: "c6", scroll: true, maxh: 460 })}
    <div class="c6 stack">
      ${panel("EPS Estimates", estT(e.eps_est, false))}
      ${panel("Revenue Estimates", estT(e.rev_est, true))}
      ${panel("EPS Estimate Trend &amp; Revisions", trendT)}
      ${growthT ? panel("Growth Estimates", growthT) : ""}
    </div>
  </div>`;
  bindSecHead(sym);
  const ch = scored.length ? scored : past.slice(-12);
  vbar("ern-cv", ch.map((h) => h.date.slice(0, 7)), [
    { label: "Estimate", data: ch.map((h) => h.est), backgroundColor: "#55555c" },
    { label: "Actual", data: ch.map((h) => h.act), backgroundColor: ch.map((h) => (isNum(h.est) && h.act < h.est ? "#dc3232" : "#1faa5a")) },
  ], { fmt: (v) => fmt(v, 2) });
};

/* ---- ANR: analyst recommendations */
const ACTIONS = { up: ["UPGRADE", "up"], down: ["DOWNGRADE", "down"], init: ["INITIATE", "amber"], main: ["MAINTAIN", "muted"], reit: ["REITERATE", "muted"] };
secPages.anr = async (gen, sym) => {
  const [d, a, g] = await Promise.all([secData(sym), soft(api(`/api/anr?symbol=${enc(sym)}`)), soft(api(`/api/gp?symbol=${enc(sym)}&range=1Y`))]);
  if (gen !== state.gen) return;
  if (a.error) return secError(sym, d, "Analyst Recommendations", a.error);
  const i = d.info || {};
  const t = a.targets && !a.targets.error ? a.targets : {};
  const cur = t.current ?? i.regularMarketPrice ?? i.currentPrice;
  const recs = arr(a.recs), acts = arr(a.actions);
  const r0 = recs[0] || {};
  const tot = ["strongBuy", "buy", "hold", "sell", "strongSell"].reduce((s, k) => s + (r0[k] || 0), 0);
  const mean = a.rating_mean;
  const gauge = isNum(mean) ? `<div class="gauge"><span style="left:calc(${Math.max(0, Math.min(100, ((mean - 1) / 4) * 100))}% - 2px)"></span></div>
    <div class="gauge-l"><span>Strong Buy</span><span>Buy</span><span>Hold</span><span>Sell</span><span>Strong Sell</span></div>` : "";
  const up = (v) => `<span class="${cls(chgPct(v, cur))}">${pct(chgPct(v, cur), 1)}</span>`;
  const since = new Date(Date.now() - 90 * 864e5).toISOString().slice(0, 10);
  const rec90 = acts.filter((x) => x.date >= since);
  const cnt = (f) => rec90.filter(f).length;
  const cons = `<div class="regime ${mean <= 2.2 ? "green" : mean >= 3.2 ? "red" : "amber"}" style="margin-bottom:2px">${esc((a.rating_key || "n/a").replace("_", " ").toUpperCase())}
      <span class="muted" style="font-size:11px;font-weight:400"> &nbsp;mean ${fmt(mean, 2)} on 1-5 scale &middot; ${fmt(a.n ?? tot, 0)} analysts</span></div>${gauge}
    <div class="kv">
      <div><span>Current Price</span><span>${fmt(cur)}</span></div><div><span>Target Mean</span><span>${fmt(t.mean)} ${up(t.mean)}</span></div>
      <div><span>Target Median</span><span>${fmt(t.median)} ${up(t.median)}</span></div><div><span>Target High</span><span>${fmt(t.high)} ${up(t.high)}</span></div>
      <div><span>Target Low</span><span>${fmt(t.low)} ${up(t.low)}</span></div><div><span>Buy / Hold / Sell</span><span><span class="up">${(r0.strongBuy || 0) + (r0.buy || 0)}</span> / ${r0.hold || 0} / <span class="down">${(r0.sell || 0) + (r0.strongSell || 0)}</span></span></div>
      <div><span>Upgrades / Downgrades (90D)</span><span><span class="up">${cnt((x) => x.action === "up")}</span> / <span class="down">${cnt((x) => x.action === "down")}</span></span></div>
      <div><span>PT Raises / Cuts (90D)</span><span><span class="up">${cnt((x) => x.pt_action === "Raises")}</span> / <span class="down">${cnt((x) => x.pt_action === "Lowers")}</span></span></div>
    </div>`;
  const actT = !acts.length ? `<div class="loading">No rating actions</div>` :
    `<table class="t"><thead><tr><th>Date</th><th>Firm</th><th>Action</th><th>Rating</th><th>Price Target</th><th>PT Chg</th><th>vs Price</th></tr></thead><tbody>${
      acts.map((x) => {
        const [al, ac] = ACTIONS[x.action] || [String(x.action || "").toUpperCase(), "muted"];
        const ptc = chgPct(x.pt, x.pt_prior);
        return `<tr><td class="muted">${esc(x.date)}</td><td class="nm" style="text-align:left">${esc(x.firm)}</td><td class="${ac}" style="text-align:left">${al}</td>
          <td>${x.from && x.from !== x.to ? `<span class="muted">${esc(x.from)} &rarr;</span> ` : ""}${esc(x.to || "")}</td>
          <td>${isNum(x.pt_prior) && x.pt_prior !== x.pt ? `<span class="muted">${fmt(x.pt_prior)} &rarr;</span> ` : ""}${isNum(x.pt) && x.pt ? fmt(x.pt) : "--"}</td>
          <td class="${cls(ptc)}">${isNum(ptc) && ptc !== 0 ? pct(ptc, 1) : "--"}</td><td>${isNum(x.pt) && x.pt ? up(x.pt) : "--"}</td></tr>`;
      }).join("")}</tbody></table>`;
  PAGE.innerHTML = `<div class="grid">
    ${secHead(sym, d)}
    ${panel("Consensus Rating &amp; Price Targets", cons, { cls: "c4", src: "Yahoo Finance" })}
    ${panel("Price vs Analyst Targets (1Y)", g.error ? errBox(g.error) : `<div class="chart-box"><canvas id="anr-px"></canvas></div>`, { cls: "c8" })}
    ${panel("Recommendation Trend", `<div class="chart-box short"><canvas id="anr-rec"></canvas></div>`, { cls: "c4" })}
    ${panel("Rating Changes &amp; Price Targets", actT, { cls: "c8", scroll: true, maxh: 520 })}
  </div>`;
  bindSecHead(sym);
  if (!g.error) {
    const flat = (v, l, c) => ({ label: l, data: g.labels.map(() => v), color: c, dash: [5, 4], borderWidth: 1.2 });
    const ds = [{ label: sym, data: g.close, fill: "rgba(255,160,40,.06)", color: "#e4e4e4" }];
    if (isNum(t.high)) ds.push(flat(t.high, "Target High", "#34d27b"));
    if (isNum(t.mean)) ds.push(flat(t.mean, "Target Mean", "#ffa028"));
    if (isNum(t.low)) ds.push(flat(t.low, "Target Low", "#ff5252"));
    lineChart("anr-px", g.labels, ds, { xticks: 8 });
  }
  const per = recs.slice().reverse();
  const pl = (p) => (p === "0m" ? "Now" : p.replace("-", "").replace("m", "M ago"));
  vbar("anr-rec", per.map((r) => pl(r.period)), [
    ["strongBuy", "Strong Buy", "#1faa5a"], ["buy", "Buy", "#7bd89f"], ["hold", "Hold", "#6b6b72"], ["sell", "Sell", "#ff9a6a"], ["strongSell", "Strong Sell", "#dc3232"],
  ].map(([k, l, c]) => ({ label: l, data: per.map((r) => r[k] || 0), backgroundColor: c })), { stacked: true, fmt: (v) => fmt(v, 0) });
};

/* ---- OMON: option monitor */
secPages.omon = async (gen, sym) => {
  const [d, o] = await Promise.all([secData(sym), soft(api(`/api/omon?symbol=${enc(sym)}${state.optExp ? "&exp=" + state.optExp : ""}`))]);
  if (gen !== state.gen) return;
  if (o.error) return secError(sym, d, "Options", o.error, "Options are available for most US-listed stocks and ETFs.");
  state.optExp = o.expiry;
  const win = +state.optWin;
  const ai = o.rows.findIndex((r) => r.strike === o.atm);
  const rows = win && ai >= 0 ? o.rows.slice(Math.max(0, ai - win), ai + win + 1) : o.rows;
  const side = (x) => {
    if (!x) return `<td colspan="7" class="muted" style="text-align:center">-</td>`;
    const c = x.itm ? "itm" : "";
    return `<td class="${c}">${fmt(x.bid)}</td><td class="${c}">${fmt(x.ask)}</td><td class="${c} last">${fmt(x.last)}</td>
      <td class="${c} ${cls(x.chg)}">${isNum(x.chg) && x.chg !== 0 ? sign(x.chg) + fmt(x.chg) : "--"}</td>
      <td class="${c}">${isNum(x.vol) ? fmt(x.vol, 0) : "--"}</td><td class="${c}">${isNum(x.oi) ? fmt(x.oi, 0) : "--"}</td>
      <td class="${c}">${isNum(x.iv) ? fmt(x.iv, 1) + "%" : "--"}</td>`;
  };
  const cols = "<th>Bid</th><th>Ask</th><th>Last</th><th>Chg</th><th>Volume</th><th>Open Int</th><th>IV</th>";
  const chain = `<table class="t chain"><thead><tr><th colspan="7" class="grp">CALLS</th><th class="grp">${esc(o.expiry)}</th><th colspan="7" class="grp">PUTS</th></tr>
    <tr>${cols}<th style="text-align:center">Strike</th>${cols}</tr></thead><tbody>${
      rows.map((r) => `<tr class="${r.strike === o.atm ? "atm" : ""}">${side(r.c)}<td class="strike">${fmt(r.strike, r.strike % 1 ? 2 : 0)}</td>${side(r.p)}</tr>`).join("")}</tbody></table>`;
  const s = o.summary;
  const kv = `<div class="kv">
    <div><span>Underlying</span><span>${fmt(o.spot)}</span></div><div><span>Expiry</span><span class="amber">${esc(o.expiry)} (${o.dte}d)</span></div>
    <div><span>ATM Strike</span><span>${fmt(o.atm)}</span></div><div><span>ATM Implied Vol</span><span>${isNum(s.atm_iv) ? fmt(s.atm_iv, 1) + "%" : "--"}</span></div>
    <div><span>Implied Move (straddle)</span><span>&plusmn;${fmt(s.straddle)} (${isNum(s.move_pct) ? fmt(s.move_pct, 1) + "%" : "--"})</span></div>
    <div><span>Max Pain</span><span>${fmt(s.max_pain)}</span></div>
    <div><span>Call / Put Volume</span><span>${big(s.call_vol)} / ${big(s.put_vol)}</span></div>
    <div><span>Put/Call Vol Ratio</span><span class="${s.pc_vol > 1 ? "down" : "up"}">${fmt(s.pc_vol)}</span></div>
    <div><span>Call / Put Open Int</span><span>${big(s.call_oi)} / ${big(s.put_oi)}</span></div>
    <div><span>Put/Call OI Ratio</span><span class="${s.pc_oi > 1 ? "down" : "up"}">${fmt(s.pc_oi)}</span></div></div>
    <div class="note">Implied move = at-the-money straddle price: the market's priced-in &plusmn; range to expiry.
    Max pain = strike where option holders collectively lose the most. P/C ratio above 1 = more puts than calls (bearish hedging).</div>`;
  const expSel = `<select id="opt-exp" class="selbox">${o.expiries.map((x) => `<option value="${esc(x)}" ${x === o.expiry ? "selected" : ""}>${esc(x)}</option>`).join("")}</select>`;
  PAGE.innerHTML = `<div class="grid">
    ${secHead(sym, d)}
    ${panel("Option Chain", chain, { cls: "c8", scroll: true, maxh: 760, tools: expSel + segHTML("opt-win", [[10, "±10"], [20, "±20"], [0, "All"]], state.optWin), src: "Yahoo Finance (delayed)" })}
    <div class="c4 stack">
      ${panel("Summary", kv)}
      ${panel("Volatility Smile (OTM)", `<div class="chart-box short"><canvas id="opt-smile"></canvas></div>`)}
      ${panel("Open Interest by Strike", `<div class="chart-box short"><canvas id="opt-oi"></canvas></div>`)}
    </div>
  </div>`;
  bindSecHead(sym);
  $("#opt-exp").onchange = (ev) => { state.optExp = ev.target.value; render(); };
  bindSeg("opt-win", (v) => { state.optWin = +v; render(); });
  lineChart("opt-smile", o.smile.map((x) => x.strike), [{ label: "IV", data: o.smile.map((x) => x.iv), color: "#c084fc", pointRadius: 2 }],
    { unit: "%", digits: 1, ydigits: 0, xticks: 8, legend: false });
  vbar("opt-oi", rows.map((r) => r.strike), [
    { label: "Call OI", data: rows.map((r) => (r.c && r.c.oi) || 0), backgroundColor: "#1faa5a" },
    { label: "Put OI", data: rows.map((r) => (r.p && r.p.oi) || 0), backgroundColor: "#dc3232" },
  ], { fmt: (v) => fmt(v, 0), yfmt: big, xticks: 8 });
  const atmRow = $("tr.atm", PAGE);
  if (atmRow) atmRow.scrollIntoView({ block: "center" });
  PAGE.scrollTop = 0;
};

/* ---- HDS: holders */
const prettySector = (k) => ({ realestate: "Real Estate" }[k] || k.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase()));
function holderTable(rows) {
  if (!arr(rows).length) return `<div class="loading">Not available</div>`;
  return `<table class="t"><thead><tr><th>Holder</th><th>% Out</th><th>Shares</th><th>Value</th><th>% Chg</th><th>Reported</th></tr></thead><tbody>${
    rows.map((r) => `<tr><td class="nm" title="${esc(r.holder)}">${esc(r.holder)}</td><td>${fp(r.pct, 2)}</td><td>${big(r.shares)}</td><td>${big(r.value)}</td>
      <td class="${cls(r.chg)}">${isNum(r.chg) ? pct(r.chg * 100, 2) : "--"}</td><td class="muted">${esc(r.date || "")}</td></tr>`).join("")}</tbody></table>`;
}
secPages.hds = async (gen, sym) => {
  const [d, h] = await Promise.all([secData(sym), soft(api(`/api/hds?symbol=${enc(sym)}`))]);
  if (gen !== state.gen) return;
  if (h.error) return secError(sym, d, "Holders", h.error);
  const fund = h.fund && !h.fund.error && (arr(h.fund.top).length || Object.keys(h.fund.sectors || {}).length) ? h.fund : null;
  const mj = h.major && !h.major.error ? h.major : {};
  const ins = arr(h.insider);
  const insT = !ins.length ? `<div class="loading">No insider transactions reported</div>` :
    `<table class="t"><thead><tr><th>Date</th><th>Insider</th><th>Position</th><th>Transaction</th><th>Shares</th><th>Value</th></tr></thead><tbody>${
      ins.map((r) => {
        const tx = r.text || "";
        const c = /sale/i.test(tx) ? "down" : /purchase|buy/i.test(tx) ? "up" : "muted";
        return `<tr><td class="muted">${esc(r.date || "")}</td><td class="nm">${esc(r.insider)}</td><td class="muted">${esc(r.position || "")}</td>
          <td class="${c}" style="text-align:left;white-space:normal;max-width:260px">${esc(tx || "-")}</td><td>${big(r.shares)}</td><td>${r.value ? big(r.value) : "--"}</td></tr>`;
      }).join("")}</tbody></table>`;
  const isum = arr(h.insider_sum);
  const own = Object.keys(mj).length ? `<div class="kv one">
      <div><span>Held by Insiders</span><span>${fp(mj.insidersPercentHeld, 2)}</span></div>
      <div><span>Held by Institutions</span><span>${fp(mj.institutionsPercentHeld, 1)}</span></div>
      <div><span>Institutions % of Float</span><span>${fp(mj.institutionsFloatPercentHeld, 1)}</span></div>
      <div><span># Institutions</span><span>${fmt(mj.institutionsCount, 0)}</span></div></div>` : "";
  const isumT = isum.length ? `<table class="t"><thead><tr><th>Insider Activity (6M)</th><th>Shares</th><th>Trans</th></tr></thead><tbody>${
    isum.map((r) => `<tr><td class="nm">${esc(r.label)}</td><td class="${/net/i.test(r.label || "") ? cls(r.shares) : ""}">${big(r.shares)}</td><td>${isNum(r.trans) ? fmt(r.trans, 0) : ""}</td></tr>`).join("")}</tbody></table>` : "";
  let html = `<div class="grid">${secHead(sym, d)}`;
  if (fund) {
    const ac = fund.assets || {};
    html += panel("Fund Top Holdings", `<table class="t"><thead><tr><th>Symbol</th><th>Name</th><th>Weight</th></tr></thead><tbody>${
      arr(fund.top).map((r) => `<tr class="click" data-sym="${esc(r.sym)}"><td class="amber">${esc(r.sym)}</td><td class="nm">${esc(r.name)}</td><td>${fp(r.pct, 2)}</td></tr>`).join("")}</tbody></table>
      ${Object.keys(ac).length ? `<div class="kv">${Object.entries(ac).filter(([, v]) => v).map(([k, v]) => `<div><span>${esc(prettySector(k.replace("Position", "")))}</span><span>${fp(v, 1)}</span></div>`).join("")}</div>` : ""}`,
    { cls: "c6", src: "Yahoo Finance" });
    html += panel("Sector Weights", `<div class="chart-box"><canvas id="hds-sec"></canvas></div>`, { cls: "c6" });
  }
  if (own || isumT) html += panel("Ownership Summary", own + isumT, { cls: "c4" });
  if (arr(h.inst).length) html += panel("Top Institutional Holders", holderTable(h.inst), { cls: own || isumT ? "c8" : "c12" });
  if (arr(h.funds).length) html += panel("Top Mutual Fund / ETF Holders", holderTable(h.funds), { cls: "c12" });
  if (ins.length || !fund) html += panel("Insider Transactions", insT, { cls: "c12", scroll: true, maxh: 520 });
  PAGE.innerHTML = html + "</div>";
  bindSecHead(sym);
  if (fund) {
    const sw = Object.entries(fund.sectors || {}).filter(([, v]) => isNum(v) && v > 0).sort((a, b) => b[1] - a[1]);
    barChart("hds-sec", sw.map(([k]) => prettySector(k)), sw.map(([, v]) => +(v * 100).toFixed(2)), { color: "#ffa028", fmt: (v) => fmt(v, 2) + "%" });
  }
};

/* ---- DVD: dividends */
const FREQ = { 1: "Annual", 2: "Semi-annual", 4: "Quarterly", 12: "Monthly" };
secPages.dvd = async (gen, sym) => {
  const [d, v] = await Promise.all([secData(sym), soft(api(`/api/dvd?symbol=${enc(sym)}`))]);
  if (gen !== state.gen) return;
  if (v.error) return secError(sym, d, "Dividends", v.error);
  const s = v.stats || {};
  const thisYear = new Date().getFullYear();
  const has = arr(v.history).length > 0;
  const kv = `<div class="kv">
    <div><span>Fwd Annual Dividend</span><span>${fmt(s.rate)}</span></div><div><span>Fwd Yield</span><span class="amber">${isNum(s.yield) ? fmt(s.yield, 2) + "%" : "--"}</span></div>
    <div><span>Trailing 12M Dividend</span><span>${fmt(s.trail_rate)}</span></div><div><span>Trailing Yield</span><span>${isNum(s.trail_yield) ? fmt(s.trail_yield, 2) + "%" : "--"}</span></div>
    <div><span>5Y Avg Yield</span><span>${isNum(s.avg5y) ? fmt(s.avg5y, 2) + "%" : "--"}</span></div><div><span>Payout Ratio</span><span>${fp(s.payout, 1)}</span></div>
    <div><span>Last Dividend</span><span>${fmt(s.last, 4)}</span></div><div><span>Frequency</span><span>${esc(FREQ[s.freq] || (s.freq ? s.freq + "x / yr" : "--"))}</span></div>
    <div><span>Next / Last Ex-Date</span><span class="amber">${esc(s.ex_date || "--")}</span></div><div><span>Pay Date</span><span>${esc(s.pay_date || "--")}</span></div>
    <div><span>Growth 1Y</span><span class="${cls(s.g1)}">${pct(s.g1, 1)}</span></div><div><span>Growth 3Y (CAGR)</span><span class="${cls(s.g3)}">${pct(s.g3, 1)}</span></div>
    <div><span>Growth 5Y (CAGR)</span><span class="${cls(s.g5)}">${pct(s.g5, 1)}</span></div><div><span>Growth 10Y (CAGR)</span><span class="${cls(s.g10)}">${pct(s.g10, 1)}</span></div>
    <div><span>Consecutive Annual Increases</span><span class="${s.streak >= 10 ? "up" : ""}">${fmt(s.streak, 0)} yrs</span></div></div>`;
  const histT = `<table class="t"><thead><tr><th>Ex-Date</th><th>Amount</th><th>Chg</th></tr></thead><tbody>${
    arr(v.history).map((r, k, a) => { const p = a[k + 1] ? chgPct(r.amt, a[k + 1].amt) : null; return `<tr><td>${esc(r.date)}</td><td class="last">${fmt(r.amt, 4)}</td><td class="${cls(p)}">${isNum(p) && Math.abs(p) > 0.01 ? pct(p, 1) : ""}</td></tr>`; }).join("")}</tbody></table>`;
  const splitT = arr(v.splits).length ? `<table class="t"><thead><tr><th>Date</th><th>Split</th></tr></thead><tbody>${
    v.splits.map((r) => `<tr><td>${esc(r.date)}</td><td>${r.ratio >= 1 ? `${fmt(r.ratio, r.ratio % 1 ? 2 : 0)} : 1` : `1 : ${fmt(1 / r.ratio, 0)}`}</td></tr>`).join("")}</tbody></table>` : `<div class="loading">No splits</div>`;
  PAGE.innerHTML = `<div class="grid">
    ${secHead(sym, d)}
    ${panel("Dividend Summary", has ? kv : `<div class="loading">${esc(sym)} has no dividend history</div>`, { cls: "c5", src: "Yahoo Finance" })}
    ${panel("Dividends per Share by Year", has ? `<div class="chart-box"><canvas id="dvd-cv"></canvas></div><div class="note">* current year to date</div>` : "", { cls: "c7" })}
    ${panel("Dividend History", has ? histT : `<div class="loading">None</div>`, { cls: "c7", scroll: true, maxh: 460 })}
    ${panel("Stock Splits", splitT, { cls: "c5", scroll: true, maxh: 460 })}
  </div>`;
  bindSecHead(sym);
  if (has) {
    const an = arr(v.annual).slice(-20);
    vbar("dvd-cv", an.map((a) => (a.year >= thisYear ? a.year + "*" : String(a.year))),
      [{ label: "Dividends", data: an.map((a) => a.total), backgroundColor: an.map((a) => (a.year >= thisYear ? "#a8681a" : "#ffa028")) }],
      { legend: false, fmt: (x) => fmt(x, 2) });
  }
};

/* ---- RV: relative value vs peers */
const PEER_KEY = "mt.peers";
function getPeers(sym) { try { return (JSON.parse(localStorage.getItem(PEER_KEY)) || {})[sym] || []; } catch (e) { return []; } }
function setPeers(sym, list) {
  try { const m = JSON.parse(localStorage.getItem(PEER_KEY)) || {}; m[sym] = list; localStorage.setItem(PEER_KEY, JSON.stringify(m)); } catch (e) { /* ignore */ }
}
const x1 = (v) => (isNum(v) ? fmt(v, 1) : "--"), x2 = (v) => (isNum(v) ? fmt(v, 2) : "--");
const RV_COLS = [["Mkt Cap", "marketCap", big], ["Last", "last", x2], ["1D%", "chg", pct, 1], ["YTD%", "ytd", pct, 1], ["1Y%", "y1", pct, 1],
  ["P/E", "trailingPE", x1], ["Fwd P/E", "forwardPE", x1], ["PEG", "trailingPegRatio", x2], ["EV/EBITDA", "enterpriseToEbitda", x1],
  ["P/S", "priceToSalesTrailing12Months", x2], ["P/B", "priceToBook", x2], ["Gross M", "grossMargins", fp], ["Op M", "operatingMargins", fp],
  ["Net M", "profitMargins", fp], ["ROE", "returnOnEquity", fp], ["Rev Gr", "revenueGrowth", fp, 1], ["EPS Gr", "earningsGrowth", fp, 1],
  ["Div Yld", "dividendYield", (v) => (isNum(v) ? fmt(v, 2) + "%" : "--")], ["Beta", "beta", x2], ["Rating", "recommendationMean", x2]];
const median = (a) => { const v = a.filter(isNum).sort((x, y) => x - y); if (!v.length) return null; const m = v.length >> 1; return v.length % 2 ? v[m] : (v[m - 1] + v[m]) / 2; };
secPages.rv = async (gen, sym) => {
  const extra = getPeers(sym);
  const [d, r] = await Promise.all([secData(sym), soft(api(`/api/rv?symbol=${enc(sym)}&extra=${enc(extra.join(","))}`))]);
  if (gen !== state.gen) return;
  if (r.error) return secError(sym, d, "Relative Value", r.error);
  const rows = arr(r.rows);
  const peers = rows.filter((x) => !x.subject);
  const tbl = `<table class="t rv"><thead><tr><th>Security</th>${RV_COLS.map(([l]) => `<th>${l}</th>`).join("")}<th></th></tr></thead><tbody>${
    rows.map((x) => `<tr class="click ${x.subject ? "subject" : ""}" data-sym="${esc(x.sym)}"><td class="nm" title="${esc(x.name)}"><span class="amber">${esc(x.sym)}</span> <span class="muted">${esc((x.name || "").slice(0, 20))}</span></td>${
      RV_COLS.map(([, k, f, c]) => `<td class="${c ? cls(x[k]) : ""}">${f(x[k])}</td>`).join("")}<td>${x.custom ? `<button class="x" data-prm="${esc(x.sym)}" title="Remove peer">&times;</button>` : ""}</td></tr>`).join("")}
    <tr class="med"><td>Peer Median</td>${RV_COLS.map(([, k, f]) => `<td>${k === "last" ? "" : f(median(peers.map((p) => p[k])))}</td>`).join("")}<td></td></tr></tbody></table>`;
  PAGE.innerHTML = `<div class="grid">
    ${secHead(sym, d)}
    ${panel(`RV - Peer Comparison <span class="muted">${esc(r.industry || "")}</span>`, tbl + `<div class="wl-add"><input id="peer-in" placeholder="Add peer ticker(s), e.g. AMD, INTC" spellcheck="false"><button id="peer-btn">+ ADD PEER</button>
      <button class="btn" id="peer-comp" style="margin-left:8px">COMPARE TOP 6</button></div>`, { cls: "c12", src: "Yahoo Finance industry constituents" })}
    ${panel("Valuation vs Growth", `<div class="chart-box tall"><canvas id="rv-sc"></canvas></div>`, { cls: "c6" })}
    ${panel("Profitability vs Valuation", `<div class="chart-box tall"><canvas id="rv-sc2"></canvas></div>`, { cls: "c6" })}
  </div>`;
  bindSecHead(sym);
  const add = () => {
    const v = ($("#peer-in").value || "").toUpperCase().split(/[\s,]+/).filter(Boolean);
    if (!v.length) return;
    setPeers(sym, [...new Set([...getPeers(sym), ...v])]);
    render();
  };
  $("#peer-btn").onclick = add;
  $("#peer-in").onkeydown = (e) => { if (e.key === "Enter") add(); };
  $$("[data-prm]").forEach((b) => (b.onclick = (ev) => { ev.stopPropagation(); setPeers(sym, getPeers(sym).filter((x) => x !== b.dataset.prm)); render(); }));
  $("#peer-comp").onclick = () => goComp(rows.slice(0, 6).map((x) => x.sym));
  const pts = (fx, fy) => rows.filter((x) => isNum(fx(x)) && isNum(fy(x))).map((x) => ({ x: fx(x), y: fy(x), s: x.sym, hl: x.subject }));
  scatterChart("rv-sc", pts((x) => (isNum(x.revenueGrowth) ? x.revenueGrowth * 100 : null), (x) => (x.forwardPE > 0 && x.forwardPE < 200 ? x.forwardPE : null)),
    { xl: "Revenue Growth", xu: "%", yl: "Fwd P/E", yu: "x" });
  scatterChart("rv-sc2", pts((x) => (isNum(x.operatingMargins) ? x.operatingMargins * 100 : null), (x) => (x.enterpriseToEbitda > 0 && x.enterpriseToEbitda < 200 ? x.enterpriseToEbitda : null)),
    { xl: "Operating Margin", xu: "%", yl: "EV/EBITDA", yu: "x" });
};

/* ================================================================== COMP: multi-security comparison */
const COMP_KEY = "mt.comp";
const COMP_RANGES = ["1M", "3M", "6M", "YTD", "1Y", "2Y", "5Y", "10Y"];
const COMP_PRESETS = [["Asset Classes", ["SPY", "AGG", "GLD", "USO", "UUP", "BTC-USD"]], ["US Sectors", ["XLK", "XLF", "XLV", "XLE", "XLI", "XLY", "XLP", "XLU"]],
  ["Mega Caps", ["AAPL", "MSFT", "NVDA", "AMZN", "GOOGL", "META"]], ["Factors", ["SPY", "MTUM", "VLUE", "QUAL", "USMV", "IWM"]],
  ["Global", ["SPY", "EFA", "EEM", "EWJ", "FXI", "INDA"]], ["Rates & Credit", ["SHY", "IEF", "TLT", "LQD", "HYG", "TIP"]]];
function getComp() {
  try { const v = JSON.parse(localStorage.getItem(COMP_KEY)); if (Array.isArray(v) && v.length) return v; } catch (e) { /* ignore */ }
  return ["SPY", "QQQ", "IWM", "TLT", "GLD"];
}
function setComp(v) { try { localStorage.setItem(COMP_KEY, JSON.stringify(v)); } catch (e) { /* ignore */ } }
function goComp(list) {
  list = [...new Set(list.map((s) => String(s).trim().toUpperCase()).filter(Boolean))].slice(0, 10);
  if (!list.length) return;
  setComp(list);
  state.comp = list;
  const h = "#/comp/" + list.map(enc).join(",");
  if (location.hash === h) render(); else location.hash = h;
}
const corrColor = (v) => (!isNum(v) ? "transparent" : v >= 0 ? `rgba(255,160,40,${(v * 0.55).toFixed(2)})` : `rgba(92,179,255,${(-v * 0.55).toFixed(2)})`);
pages.comp = async (gen) => {
  const syms = state.comp && state.comp.length ? state.comp : getComp();
  state.comp = syms;
  setComp(syms);
  const d = await soft(api(`/api/comp?symbols=${enc(syms.join(","))}&range=${state.compRange}`));
  if (gen !== state.gen) return;
  const color = (s) => PALETTE[Math.max(0, syms.indexOf(s)) % PALETTE.length];
  const chips = syms.map((s) => `<span class="chip"><i style="background:${color(s)}"></i><a href="#/des/${enc(s)}">${esc(s)}</a><button class="x" data-crm="${esc(s)}" title="Remove">&times;</button></span>`).join("");
  const ctl = `<div class="chips">${chips}
      <input id="comp-in" class="inp" placeholder="Add ticker(s)" spellcheck="false"><button class="btn" id="comp-add">+ ADD</button>
      <span class="muted" style="margin-left:12px">Presets:</span>${COMP_PRESETS.map(([l], k) => `<button class="btn sm" data-preset="${k}">${esc(l)}</button>`).join("")}</div>`;
  let body = "";
  if (d.error) body = panel("Comparison", errBox(d.error), { cls: "c12" });
  else {
    const base = d.symbols[0];
    const st = arr(d.stats);
    const statT = `<table class="t"><thead><tr><th>Security</th><th>Last</th><th>Total Return</th><th>CAGR</th><th>Ann. Vol</th><th>Max Drawdown</th><th title="Return / volatility, no risk-free rate">Sharpe*</th><th>Beta vs ${esc(base)}</th><th>Corr vs ${esc(base)}</th><th>High</th><th>Low</th></tr></thead><tbody>${
      st.map((x) => `<tr class="click" data-sym="${esc(x.sym)}"><td><i class="sw" style="background:${color(x.sym)}"></i><span class="amber">${esc(x.sym)}</span></td><td class="last">${fmt(x.last, pxDigits(x.sym, x.last))}</td>
        <td><span class="pill ${cls(x.ret)}">${pct(x.ret)}</span></td><td class="${cls(x.cagr)}">${pct(x.cagr)}</td><td>${isNum(x.vol) ? fmt(x.vol, 1) + "%" : "--"}</td>
        <td class="down">${pct(x.mdd, 1)}</td><td class="${cls(x.sharpe)}">${x2(x.sharpe)}</td><td>${x2(x.beta)}</td><td>${x2(x.corr)}</td>
        <td>${fmt(x.hi, pxDigits(x.sym, x.hi))}</td><td>${fmt(x.lo, pxDigits(x.sym, x.lo))}</td></tr>`).join("")}</tbody></table>
      ${d.missing.length ? `<div class="note">No data for: <b>${esc(d.missing.join(", "))}</b></div>` : ""}
      <div class="note">Returns are total returns (dividend-adjusted). Volatility and Sharpe are annualised from ${state.compRange === "5Y" || state.compRange === "10Y" ? "weekly" : "daily"} returns.</div>`;
    const corrT = `<table class="t corr"><thead><tr><th></th>${d.symbols.map((s) => `<th>${esc(s)}</th>`).join("")}</tr></thead><tbody>${
      d.symbols.map((a, i) => `<tr><td class="amber">${esc(a)}</td>${d.corr[i].map((v) => `<td style="background:${corrColor(v)}">${x2(v)}</td>`).join("")}</tr>`).join("")}</tbody></table>`;
    const ranked = st.slice().sort((a, b) => (b.ret ?? -1e9) - (a.ret ?? -1e9));
    body = panel(`Relative Performance - rebased to 100 <span class="muted">(${esc(d.labels[0])} &rarr; ${esc(d.labels[d.labels.length - 1])})</span>`,
      `<div class="chart-box xtall"><canvas id="comp-cv"></canvas></div>`, { cls: "c8", tools: segHTML("comp-rng", COMP_RANGES, state.compRange), src: "Yahoo Finance" }) +
      panel("Total Return Ranking", `<div class="chart-box xtall"><canvas id="comp-bar"></canvas></div>`, { cls: "c4" }) +
      panel("Return &amp; Risk Statistics", statT, { cls: "c8", tools: `<button class="btn sm" id="comp-csv">CSV</button>` }) +
      panel("Correlation Matrix", corrT, { cls: "c4" });
    state.compRanked = ranked;
  }
  PAGE.innerHTML = `<div class="grid">${panel("COMP - Comparison", ctl, { cls: "c12", flush: false })}${body}</div>`;
  const add = () => goComp([...syms, ...($("#comp-in").value || "").toUpperCase().split(/[\s,]+/).filter(Boolean)]);
  $("#comp-add").onclick = add;
  $("#comp-in").onkeydown = (e) => { if (e.key === "Enter") add(); };
  $$("[data-crm]").forEach((b) => (b.onclick = () => { const l = syms.filter((x) => x !== b.dataset.crm); if (l.length) goComp(l); }));
  $$("[data-preset]").forEach((b) => (b.onclick = () => goComp(COMP_PRESETS[+b.dataset.preset][1])));
  if (d.error) return;
  bindSeg("comp-rng", (v) => { state.compRange = v; render(); });
  lineChart("comp-cv", d.labels, [...d.symbols.map((s) => ({ label: s, data: d.series[s], color: color(s), borderWidth: 1.6 })),
    { label: "100", data: d.labels.map(() => 100), color: "#55555c", dash: [2, 4], borderWidth: 1, noTip: true }],
  { digits: 1, ydigits: 0, xticks: 10 });
  const rk = state.compRanked;
  barChart("comp-bar", rk.map((x) => x.sym), rk.map((x) => x.ret), { fmt: (v) => pct(v) });
  $("#comp-csv").onclick = () => downloadCSV(`comp_${state.compRange}.csv`, [["Symbol", "Last", "TotalReturn%", "CAGR%", "AnnVol%", "MaxDD%", "Sharpe", "Beta", "Corr"],
    ...arr(d.stats).map((x) => [x.sym, x.last, x.ret, x.cagr, x.vol, x.mdd, x.sharpe, x.beta, x.corr])]);
};

/* ================================================================== EVTS: earnings / economic / IPO calendar */
const ET = (ts, o) => new Date(ts * 1000).toLocaleString("en-US", { timeZone: "America/New_York", ...o });
const dayKey = (ts) => ET(ts, { weekday: "short", month: "short", day: "numeric" });
pages.cal = async (gen) => {
  const wl = getWL();
  const [c, ne] = await Promise.all([api(`/api/cal?days=${state.calDays}`), soft(api(`/api/next_earnings?symbols=${enc(wl.join(","))}`))]);
  if (gen !== state.gen) return;
  /* earnings */
  const E = arr(c.earnings).filter((r) => r.ts && (r.mcap || 0) >= state.calCap);
  let et = `<table class="t"><thead><tr><th>Time</th><th>Company</th><th>Mkt Cap</th><th>EPS Est</th><th>Reported</th><th>Surprise</th></tr></thead><tbody>`;
  let day = null;
  for (const r of E) {
    const k = dayKey(r.ts);
    if (k !== day) { day = k; et += `<tr class="cat"><td colspan="6">${esc(k)}</td></tr>`; }
    const tm = r.timing === "BMO" ? "Pre-mkt" : r.timing === "AMC" ? "After-close" : "--";
    et += `<tr class="click" data-sym="${esc(r.sym)}" data-fn="ern"><td class="muted">${tm}</td><td class="nm" title="${esc(r.company)}"><span class="amber">${esc(r.sym)}</span> <span class="muted">${esc((r.company || "").slice(0, 26))}</span></td>
      <td>${big(r.mcap)}</td><td>${fmt(r.est)}</td><td class="last">${fmt(r.act)}</td><td>${isNum(r.surprise) ? `<span class="pill ${cls(r.surprise)}">${pct(r.surprise, 1)}</span>` : ""}</td></tr>`;
  }
  et += "</tbody></table>";
  if (!E.length) et = `<div class="loading">${c.earnings && c.earnings.error ? esc(c.earnings.error) : "No reports in range"}</div>`;
  /* economic */
  const ec = arr(c.econ);
  const counts = {};
  ec.forEach((r) => { counts[r.region] = (counts[r.region] || 0) + 1; });
  const regs = ["US", ...Object.entries(counts).sort((a, b) => b[1] - a[1]).map((x) => x[0]).filter((x) => x && x !== "US").slice(0, 9), "ALL"];
  const EC = ec.filter((r) => r.ts && (state.calRegion === "ALL" || r.region === state.calRegion));
  let xt = `<table class="t"><thead><tr><th>Time ET</th><th>Region</th><th>Event</th><th>Period</th><th>Actual</th><th>Consensus</th><th>Prior</th><th>Revised</th></tr></thead><tbody>`;
  day = null;
  for (const r of EC) {
    const k = dayKey(r.ts);
    if (k !== day) { day = k; xt += `<tr class="cat"><td colspan="8">${esc(k)}</td></tr>`; }
    const sur = isNum(r.actual) && isNum(r.expected) ? r.actual - r.expected : null;
    xt += `<tr><td class="muted">${ET(r.ts, { hour: "2-digit", minute: "2-digit", hour12: false })}</td><td class="amber">${esc(r.region || "")}</td>
      <td class="nm" style="max-width:340px">${esc(r.event)}</td><td class="muted">${esc(r.for || "")}</td>
      <td class="last ${cls(sur)}">${isNum(r.actual) ? fmt(r.actual, 2) : ""}</td><td>${isNum(r.expected) ? fmt(r.expected, 2) : ""}</td>
      <td>${isNum(r.last) ? fmt(r.last, 2) : ""}</td><td class="muted">${isNum(r.revised) ? fmt(r.revised, 2) : ""}</td></tr>`;
  }
  xt += "</tbody></table>";
  if (!EC.length) xt = `<div class="loading">${c.econ && c.econ.error ? esc(c.econ.error) : "No events"}</div>`;
  /* watchlist + ipo */
  const today = new Date().toISOString().slice(0, 10);
  const W = arr(ne);
  const wt = !W.length ? `<div class="loading">Watchlist is empty</div>` :
    `<table class="t"><thead><tr><th>Ticker</th><th>Next Report</th><th>Days</th><th>EPS Est</th><th>Rev Est</th></tr></thead><tbody>${
      W.map((r) => {
        const dd = r.date ? Math.round((new Date(r.date + "T12:00:00") - new Date()) / 864e5) : null;
        return `<tr class="click" data-sym="${esc(r.sym)}" data-fn="ern"><td class="amber">${esc(r.sym)}</td><td>${r.date && r.date >= today ? esc(r.date) : `<span class="muted">${esc(r.date || "n/a")}</span>`}</td>
          <td class="${isNum(dd) && dd >= 0 && dd <= 7 ? "amber" : "muted"}">${isNum(dd) && dd >= 0 ? dd : ""}</td><td>${fmt(r.eps)}</td><td>${big(r.rev)}</td></tr>`;
      }).join("")}</tbody></table>`;
  const ipo = arr(c.ipo);
  const it = !ipo.length ? `<div class="loading">No IPOs scheduled</div>` :
    `<table class="t"><thead><tr><th>Date</th><th>Company</th><th>Exch</th><th>Price Range</th><th>Shares</th><th>Status</th></tr></thead><tbody>${
      ipo.map((r) => `<tr><td class="muted">${esc(r.date || "")}</td><td class="nm" title="${esc(r.company)}"><span class="amber">${esc(r.sym)}</span> <span class="muted">${esc((r.company || "").slice(0, 26))}</span></td>
        <td class="muted">${esc(r.exchange || "")}</td><td>${isNum(r.price) ? fmt(r.price) : isNum(r.lo) ? `${fmt(r.lo)} - ${fmt(r.hi)}` : "--"}</td><td>${big(r.shares)}</td><td class="muted">${esc(r.action || "")}</td></tr>`).join("")}</tbody></table>`;
  PAGE.innerHTML = `<div class="grid">
    ${panel(`EVTS - Earnings Calendar <span class="muted">${esc(c.start)} &rarr; ${esc(c.end)} &middot; ${E.length} reports</span>`, et,
      { cls: "c7", scroll: true, maxh: 640, tools: segHTML("cal-days", [[7, "1W"], [14, "2W"], [30, "1M"]], state.calDays) + segHTML("cal-cap", [[2e9, "$2B+"], [1e10, "$10B+"], [5e10, "$50B+"], [2e11, "$200B+"]], state.calCap), src: "Yahoo Finance" })}
    <div class="c5 stack">
      ${panel("Watchlist - Next Earnings", wt, { scroll: true, maxh: 330 })}
      ${panel("IPO Calendar", it, { scroll: true, maxh: 290 })}
    </div>
    ${panel(`ECO - Economic Calendar <span class="muted">${EC.length} releases</span>`, xt, { cls: "c12", scroll: true, maxh: 620, tools: segHTML("cal-reg", regs, state.calRegion), src: "Yahoo Finance" })}
  </div>`;
  bindSeg("cal-days", (v) => { state.calDays = +v; render(); });
  bindSeg("cal-cap", (v) => { state.calCap = +v; render(); });
  bindSeg("cal-reg", (v) => { state.calRegion = v; render(); });
};

/* ================================================================== EQS: equity screener */
const EQS_KEY = "mt.eqs";
const EQS_PRESETS = [["", "Custom (use filters)"], ["undervalued_large_caps", "Undervalued Large Caps"], ["undervalued_growth_stocks", "Undervalued Growth"],
  ["growth_technology_stocks", "Growth Technology"], ["aggressive_small_caps", "Aggressive Small Caps"], ["small_cap_gainers", "Small Cap Gainers"],
  ["most_shorted_stocks", "Most Shorted"], ["day_gainers", "Day Gainers"], ["day_losers", "Day Losers"], ["most_actives", "Most Active"]];
const EQS_SECTORS = ["", "Basic Materials", "Communication Services", "Consumer Cyclical", "Consumer Defensive", "Energy", "Financial Services",
  "Healthcare", "Industrials", "Real Estate", "Technology", "Utilities"];
const EQS_REGIONS = [["us", "United States"], ["ca", "Canada"], ["gb", "United Kingdom"], ["de", "Germany"], ["fr", "France"], ["ch", "Switzerland"],
  ["nl", "Netherlands"], ["jp", "Japan"], ["hk", "Hong Kong"], ["cn", "China"], ["in", "India"], ["kr", "South Korea"], ["au", "Australia"], ["br", "Brazil"], ["mx", "Mexico"]];
const EQS_CAPS = [["", "Any"], ["3e8", "$300M+"], ["2e9", "$2B+"], ["1e10", "$10B+"], ["5e10", "$50B+"], ["2e11", "$200B+"]];
const EQS_SORTS = [["mcap", "Market Cap"], ["chg", "% Change Today"], ["y1", "52W % Change"], ["pe", "P/E"], ["dy", "Dividend Yield"], ["vol", "Volume"]];
function getEqs() {
  try { const v = JSON.parse(localStorage.getItem(EQS_KEY)); if (v && typeof v === "object") return v; } catch (e) { /* ignore */ }
  return { preset: "", region: "us", sector: "", mcap_min: "1e10", sort: "mcap", asc: "0" };
}
function setEqs(v) { try { localStorage.setItem(EQS_KEY, JSON.stringify(v)); } catch (e) { /* ignore */ } }
const EQS_COLS = [["Symbol", "sym"], ["Last", "last"], ["%Chg", "chg"], ["Mkt Cap", "mcap"], ["P/E", "pe"], ["Fwd P/E", "fpe"], ["P/B", "pb"],
  ["Div Yld", "dy"], ["52W%", "y1"], ["Volume", "vol"], ["Rating", "rating"]];
pages.eqs = async (gen) => {
  const p = getEqs();
  const sel = (name, opts) => `<select name="${name}">${opts.map((o) => { const [v, l] = Array.isArray(o) ? o : [o, o || "Any"]; return `<option value="${esc(v)}" ${String(p[name] ?? "") === String(v) ? "selected" : ""}>${esc(l)}</option>`; }).join("")}</select>`;
  const inp = (name, ph) => `<input name="${name}" value="${esc(p[name] ?? "")}" placeholder="${esc(ph)}" spellcheck="false">`;
  const form = `<form id="eqs-form" class="form">
    <label>Preset screen ${sel("preset", EQS_PRESETS)}</label>
    <div class="note" style="padding:0">Presets are Yahoo's predefined screens and ignore the filters below.</div>
    <label>Region ${sel("region", EQS_REGIONS)}</label>
    <label>Sector ${sel("sector", EQS_SECTORS)}</label>
    <label>Market cap ${sel("mcap_min", EQS_CAPS)}</label>
    <div class="two"><label>P/E min ${inp("pe_min", "e.g. 0")}</label><label>P/E max ${inp("pe_max", "e.g. 25")}</label></div>
    <div class="two"><label>Div yield min % ${inp("dy_min", "e.g. 2")}</label><label>Rev growth min % ${inp("growth_min", "e.g. 10")}</label></div>
    <div class="two"><label>Today chg min % ${inp("chg_min", "")}</label><label>Today chg max % ${inp("chg_max", "")}</label></div>
    <div class="two"><label>Price min ${inp("price_min", "e.g. 5")}</label><label>Beta max ${inp("beta_max", "e.g. 1.2")}</label></div>
    <div class="two"><label>Sort by ${sel("sort", EQS_SORTS)}</label><label>Order ${sel("asc", [["0", "Descending"], ["1", "Ascending"]])}</label></div>
    <div style="display:flex;gap:6px"><button type="submit" class="btn primary">RUN SCREEN</button><button type="button" class="btn" id="eqs-reset">RESET</button></div>
  </form>`;
  PAGE.innerHTML = `<div class="grid">
    ${panel("EQS - Screener Criteria", form, { cls: "c3" })}
    ${panel(`<span id="eqs-title">Results</span>`, `<div id="eqs-res"><div class="loading">Screening...</div></div>`, { cls: "c9", scroll: true, maxh: 760, src: "Yahoo Finance screener",
      tools: `<button class="btn sm" id="eqs-comp">COMPARE TOP 5</button><button class="btn sm" id="eqs-wl">+ WATCHLIST TOP 5</button><button class="btn sm" id="eqs-csv">CSV</button>` })}
  </div>`;
  $("#eqs-form").onsubmit = (e) => {
    e.preventDefault();
    const v = {};
    new FormData(e.target).forEach((val, k) => { v[k] = String(val).trim(); });
    setEqs(v);
    state.eqsSort = null;
    render();
  };
  $("#eqs-reset").onclick = () => { try { localStorage.removeItem(EQS_KEY); } catch (e) { /* ignore */ } render(); };
  const qs = new URLSearchParams(Object.entries(p).filter(([, v]) => v !== "" && v !== null && v !== undefined)).toString();
  let res;
  try { res = await api(`/api/eqs?${qs}`); } catch (e) { if (gen === state.gen) $("#eqs-res").innerHTML = errBox(e); return; }
  if (gen !== state.gen) return;
  const rows = arr(res.rows);
  $("#eqs-title").textContent = `${res.title} - ${rows.length} shown${isNum(res.total) ? ` of ${fmt(res.total, 0)} matches` : ""}`;
  const draw = () => {
    const s = state.eqsSort;
    const R = s ? rows.slice().sort((a, b) => {
      const x = a[s.k], y = b[s.k];
      if (!isNum(x) && !isNum(y)) return String(x || "").localeCompare(String(y || "")) * s.dir;
      if (!isNum(x)) return 1; if (!isNum(y)) return -1;
      return (x - y) * s.dir;
    }) : rows;
    $("#eqs-res").innerHTML = !R.length ? `<div class="loading">No matches - loosen the criteria</div>` :
      `<table class="t"><thead><tr>${EQS_COLS.map(([l, k]) => `<th class="sortable" data-k="${k}">${l}${s && s.k === k ? (s.dir > 0 ? " &#9650;" : " &#9660;") : ""}</th>`).join("")}</tr></thead><tbody>${
        R.map((r) => `<tr class="click" data-sym="${esc(r.sym)}"><td class="nm" title="${esc(r.name)} - ${esc(r.exch || "")}"><span class="amber">${esc(r.sym)}</span> <span class="muted">${esc((r.name || "").slice(0, 24))}</span></td>
          <td class="last">${fmt(r.last)}</td><td><span class="pill ${cls(r.chg)}">${pct(r.chg)}</span></td><td>${big(r.mcap)}</td><td>${x1(r.pe)}</td><td>${x1(r.fpe)}</td>
          <td>${x2(r.pb)}</td><td>${isNum(r.dy) && r.dy ? fmt(r.dy, 2) + "%" : "--"}</td><td class="${cls(r.y1)}">${pct(r.y1, 1)}</td><td>${big(r.vol)}</td>
          <td class="muted">${esc(r.rating || "")}</td></tr>`).join("")}</tbody></table>`;
    $$("#eqs-res th.sortable").forEach((th) => (th.onclick = () => {
      const k = th.dataset.k;
      state.eqsSort = state.eqsSort && state.eqsSort.k === k ? { k, dir: -state.eqsSort.dir } : { k, dir: k === "sym" ? 1 : -1 };
      draw();
    }));
  };
  draw();
  $("#eqs-comp").onclick = () => rows.length && goComp(rows.slice(0, 5).map((r) => r.sym));
  $("#eqs-wl").onclick = () => { setWL([...new Set([...getWL(), ...rows.slice(0, 5).map((r) => r.sym)])]); $("#eqs-wl").textContent = "✓ ADDED"; };
  $("#eqs-csv").onclick = () => downloadCSV("screen.csv", [["Symbol", "Name", "Last", "PctChg", "MktCap", "PE", "FwdPE", "PB", "DivYield", "52wPct", "Volume", "Rating"],
    ...rows.map((r) => [r.sym, r.name, r.last, r.chg, r.mcap, r.pe, r.fpe, r.pb, r.dy, r.y1, r.vol, r.rating])]);
};

/* ================================================================== EXT: pre-market / after-hours */
const SESS_COL = { pre: "#5cb3ff", reg: "#ffa028", post: "#c084fc" };
const STATE_TXT = { PRE: ["PRE-MARKET", "4:00 - 9:30 ET", "amber"], REGULAR: ["REGULAR SESSION", "9:30 - 16:00 ET", "green"],
  POST: ["AFTER-HOURS", "16:00 - 20:00 ET", "amber"], POSTPOST: ["CLOSED", "after-hours ended 20:00 ET", "red"],
  PREPRE: ["CLOSED", "pre-market opens 4:00 ET", "red"], CLOSED: ["CLOSED", "market closed", "red"] };
function extTable(g) {
  if (!g.rows.length) return `<div class="loading">No data</div>`;
  const ex = (p, c) => (isNum(p) ? `<td>${fmt(p, pxDigits("", p))}</td><td><span class="pill ${cls(c)}">${pct(c)}</span></td>` : `<td class="muted">--</td><td class="muted">--</td>`);
  return `<table class="t"><thead><tr><th>Security</th><th>Close / Last</th><th>Day %</th><th>Pre-Mkt</th><th>Pre %</th><th>After-Hrs</th><th>AH %</th></tr></thead><tbody>${
    g.rows.map((r) => `<tr class="click" data-ext="${esc(r.sym)}"><td class="nm" title="${esc(r.name)}"><span class="amber">${esc(r.sym)}</span> <span class="muted">${esc((r.name || "").slice(0, 18))}</span>
</td>
      <td class="last">${fmt(r.reg, pxDigits(r.sym, r.reg))}</td><td class="${cls(r.reg_chg)}">${pct(r.reg_chg)}</td>${ex(r.pre, r.pre_chg)}${ex(r.post, r.post_chg)}</tr>`).join("")}</tbody></table>`;
}
function extMovers(m, key, label) {
  const rows = (m && m[key]) || [];
  if (!rows.length) return `<div class="loading">No ${label} trading yet</div>`;
  const pk = label === "pre" ? "pre" : "post";
  return `<table class="t"><thead><tr><th>Symbol</th><th>Price</th><th>%</th><th>Mkt Cap</th></tr></thead><tbody>${
    rows.map((r) => `<tr class="click" data-ext="${esc(r.sym)}"><td class="nm" title="${esc(r.name)}"><span class="amber">${esc(r.sym)}</span> <span class="muted">${esc((r.name || "").slice(0, 14))}</span></td>
      <td>${fmt(r[pk])}</td><td><span class="pill ${cls(r[pk + "_chg"])}">${pct(r[pk + "_chg"])}</span></td><td>${big(r.mcap)}</td></tr>`).join("")}</tbody></table>`;
}
async function loadExtChart(sym) {
  state.extSym = sym;
  const t = $("#ext-title");
  if (t) t.innerHTML = `${esc(sym)} - 5 Days incl. Extended Hours <a href="#/des/${enc(sym)}" class="muted" style="font-size:11px;margin-left:8px">DES &rsaquo;</a>`;
  $$("[data-ext]", PAGE).forEach((x) => x.classList.toggle("sel", x.dataset.ext === sym));
  try {
    const c = await api(`/api/ext_chart?symbol=${enc(sym)}`);
    if (state.page !== "ext") return;
    lineChart("ext-cv", c.labels, [{ label: sym, data: c.close, color: "#ffa028", borderWidth: 1.5,
      segment: { borderColor: (x) => SESS_COL[c.session[x.p0DataIndex]] || "#ffa028" } }],
    { legend: false, digits: pxDigits(sym, lastNum(c.close)), ydigits: pxDigits(sym, lastNum(c.close)), xticks: 10, yWidth: 64 });
    volChart("ext-vol", c.labels, c.volume, c.close, 64);
  } catch (e) { const b = $("#ext-cv"); if (b) b.parentElement.innerHTML = errBox(e); }
}
pages.ext = async (gen) => {
  const d = await api(`/api/ext?watch=${enc(getWL().join(","))}`);
  if (gen !== state.gen) return;
  const [st, hrs, col] = STATE_TXT[d.state] || [d.state || "--", "", "amber"];
  const m = d.movers || {};
  const G = d.groups || [];
  PAGE.innerHTML = `<div class="grid">
    <section class="panel c12"><div class="regime ${col}" style="display:flex;gap:16px;align-items:baseline;flex-wrap:wrap">US EQUITIES: ${esc(st)}
      <span class="muted" style="font-size:12px;font-weight:400">${esc(hrs)} &middot; futures trade nearly 24h and lead the open &middot; ${fmt(d.universe, 0)} US stocks over $2B scanned for movers
      &middot; chart colours: <span style="color:${SESS_COL.pre}">pre-market</span> / <span style="color:${SESS_COL.reg}">regular</span> / <span style="color:${SESS_COL.post}">after-hours</span></span></div></section>
    ${panel(`<span id="ext-title">Chart</span>`, `<div class="chart-box"><canvas id="ext-cv"></canvas></div><div class="chart-box mini"><canvas id="ext-vol"></canvas></div>`, { cls: "c7", src: "Yahoo Finance, 5-min bars" })}
    ${panel(G[0] ? G[0].title : "Futures", G[0] ? extTable(G[0]) : "", { cls: "c5" })}
    ${panel(`Pre-Market Gainers <span class="muted">${fmt((m.pre || {}).n, 0)} trading</span>`, extMovers(m.pre, "up", "pre"), { cls: "c3", scroll: true, maxh: 480 })}
    ${panel("Pre-Market Losers", extMovers(m.pre, "down", "pre"), { cls: "c3", scroll: true, maxh: 480 })}
    ${panel(`After-Hours Gainers <span class="muted">${fmt((m.post || {}).n, 0)} trading</span>`, extMovers(m.post, "up", "post"), { cls: "c3", scroll: true, maxh: 480 })}
    ${panel("After-Hours Losers", extMovers(m.post, "down", "post"), { cls: "c3", scroll: true, maxh: 480 })}
    ${G.slice(1).map((g) => panel(g.title, extTable(g), { cls: "c6", src: "Yahoo Finance" })).join("")}
  </div>`;
  $$("[data-ext]", PAGE).forEach((r) => (r.onclick = () => loadExtChart(r.dataset.ext)));
  loadExtChart(state.extSym || "SPY");
};

/* ================================================================== ALRT: price alerts */
const ALRT_KEY = "mt.alerts";
const ALRT_OPS = { above: "Price above", below: "Price below", up: "Day move ≥ +%", down: "Day move ≤ -%" };
function getAlerts() { try { const v = JSON.parse(localStorage.getItem(ALRT_KEY)); if (Array.isArray(v)) return v; } catch (e) { /* ignore */ } return []; }
function setAlerts(v) { try { localStorage.setItem(ALRT_KEY, JSON.stringify(v)); } catch (e) { /* ignore */ } updateAlertBadge(); }
function updateAlertBadge() {
  const b = $("#alrt-badge");
  if (!b) return;
  const n = getAlerts().filter((a) => a.hit && !a.seen).length;
  b.textContent = n; b.classList.toggle("hidden", !n);
}
function alertHit(a, q) {
  if (!q || !isNum(q.last)) return false;
  const p = chgPct(q.last, q.prev);
  if (a.op === "above") return q.last >= a.val;
  if (a.op === "below") return q.last <= a.val;
  if (a.op === "up") return isNum(p) && p >= a.val;
  if (a.op === "down") return isNum(p) && p <= -Math.abs(a.val);
  return false;
}
function toast(html) {
  const t = document.createElement("div");
  t.className = "toast";
  t.innerHTML = html;
  t.onclick = () => t.remove();
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 15000);
}
async function checkAlerts() {
  const al = getAlerts();
  const live = al.filter((a) => !a.hit);
  if (!live.length) return {};
  let q = {};
  try { q = await api(`/api/quotes?symbols=${enc([...new Set(live.map((a) => a.sym))].join(","))}`); } catch (e) { return {}; }
  let changed = false;
  for (const a of al) {
    if (a.hit || !alertHit(a, q[a.sym])) continue;
    a.hit = Date.now(); a.hitPx = q[a.sym].last; changed = true;
    const msg = `${a.sym}: ${ALRT_OPS[a.op]} ${fmt(a.val)} - now ${fmt(q[a.sym].last, pxDigits(a.sym, q[a.sym].last))} (${pct(chgPct(q[a.sym].last, q[a.sym].prev))})`;
    toast(`<b>&#128276; ALERT</b> ${esc(msg)}${a.note ? `<br><span class="muted">${esc(a.note)}</span>` : ""}`);
    try { if ("Notification" in window && Notification.permission === "granted") new Notification("Market Terminal alert", { body: msg + (a.note ? "\n" + a.note : "") }); } catch (e) { /* ignore */ }
  }
  if (changed) { setAlerts(al); if (state.page === "alrt") render(true); }
  return q;
}
setInterval(checkAlerts, 60000);
setTimeout(checkAlerts, 5000);

pages.alrt = async (gen) => {
  const al = getAlerts();
  let q = {};
  const syms = [...new Set(al.map((a) => a.sym))];
  if (syms.length) { try { q = await api(`/api/quotes?symbols=${enc(syms.join(","))}`); } catch (e) { /* ignore */ } }
  if (gen !== state.gen) return;
  al.forEach((a) => { if (a.hit) a.seen = true; });
  setAlerts(al);
  const perm = "Notification" in window ? Notification.permission : "unsupported";
  const row = (a, k) => {
    const r = q[a.sym] || {};
    const p = chgPct(r.last, r.prev);
    const dist = a.op === "above" || a.op === "below" ? chgPct(a.val, r.last) : null;
    return `<tr class="click" data-sym="${esc(a.sym)}"><td class="amber">${esc(a.sym)}</td><td>${esc(ALRT_OPS[a.op])}</td><td class="last">${a.op === "up" || a.op === "down" ? fmt(a.val, 1) + "%" : fmt(a.val)}</td>
      <td>${fmt(r.last, pxDigits(a.sym, r.last))}</td><td><span class="pill ${cls(p)}">${pct(p)}</span></td><td class="${dist === null ? "" : "muted"}">${dist === null ? "" : pct(dist, 1) + " away"}</td>
      <td>${a.hit ? `<span class="up">TRIGGERED</span> <span class="muted">${new Date(a.hit).toLocaleString([], { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })} @ ${fmt(a.hitPx)}</span>` : `<span class="amber">ACTIVE</span>`}</td>
      <td class="muted" style="text-align:left">${esc(a.note || "")}</td>
      <td>${a.hit ? `<button class="btn sm" data-rearm="${k}">RE-ARM</button>` : ""}<button class="x" data-arm="${k}" title="Delete">&times;</button></td></tr>`;
  };
  const tbl = !al.length ? `<div class="loading">No alerts yet - add one on the left</div>` :
    `<table class="t"><thead><tr><th>Ticker</th><th>Condition</th><th>Level</th><th>Last</th><th>Today</th><th>Distance</th><th>Status</th><th style="text-align:left">Note</th><th></th></tr></thead><tbody>${
      al.map(row).join("")}</tbody></table>`;
  PAGE.innerHTML = `<div class="grid">
    ${panel("ALRT - New Price Alert", `<form id="alrt-form" class="form">
      <label>Ticker <input name="sym" value="${esc(state.sym || "")}" placeholder="e.g. AAPL, ^GSPC, BTC-USD, CL=F" spellcheck="false" required></label>
      <label>Condition <select name="op">${Object.entries(ALRT_OPS).map(([k, l]) => `<option value="${k}">${esc(l)}</option>`).join("")}</select></label>
      <label>Level (price, or % for day-move alerts) <input name="val" placeholder="e.g. 250 or 3" required></label>
      <label>Note (optional) <input name="note" placeholder="why this level matters"></label>
      <button type="submit" class="btn primary">ADD ALERT</button></form>
      <div class="note">Alerts are checked every 60 seconds while the terminal is open (quotes may be ~15 min delayed).
      Desktop notifications: <b>${esc(perm)}</b> ${perm === "default" ? `<button class="btn sm" id="alrt-perm">ENABLE</button>` : ""}</div>`, { cls: "c4" })}
    ${panel(`Alerts <span class="muted">${al.filter((a) => !a.hit).length} active &middot; ${al.filter((a) => a.hit).length} triggered</span>`, tbl, { cls: "c8",
      tools: al.some((a) => a.hit) ? `<button class="btn sm" id="alrt-clear">CLEAR TRIGGERED</button>` : "" })}
  </div>`;
  $("#alrt-form").onsubmit = (e) => {
    e.preventDefault();
    const f = new FormData(e.target);
    const val = parseFloat(String(f.get("val")).replace(/[,%$]/g, ""));
    const sym = String(f.get("sym")).trim().toUpperCase();
    if (!sym || !isFinite(val)) return;
    setAlerts([...getAlerts(), { sym, op: String(f.get("op")), val, note: String(f.get("note") || "").trim(), created: Date.now() }]);
    if ("Notification" in window && Notification.permission === "default") Notification.requestPermission().catch(() => {});
    render();
  };
  if ($("#alrt-perm")) $("#alrt-perm").onclick = () => Notification.requestPermission().then(() => render());
  if ($("#alrt-clear")) $("#alrt-clear").onclick = () => { setAlerts(getAlerts().filter((a) => !a.hit)); render(); };
  $$("[data-arm]").forEach((b) => (b.onclick = () => { const l = getAlerts(); l.splice(+b.dataset.arm, 1); setAlerts(l); render(); }));
  $$("[data-rearm]").forEach((b) => (b.onclick = () => { const l = getAlerts(); const a = l[+b.dataset.rearm]; delete a.hit; delete a.hitPx; delete a.seen; setAlerts(l); render(); }));
};

/* keep the local server alive while any app window is open */
setInterval(() => { fetch("/api/ping").catch(() => {}); }, 20000);
function openApp(path) { window.open(path, "_blank", "popup,width=1500,height=920"); }

pages.des = async (gen) => {
  const sym = state.sym;
  if (!sym) return pages.help();
  const fn = secPages[state.fn] ? state.fn : "des";
  PAGE.innerHTML = `<div class="loading">Loading ${esc(sym)} ${fn.toUpperCase()}...</div>`;
  return secPages[fn](gen, sym);
};

/* ------------------------------------------------------------------ routing & render */
async function render(silent = false) {
  const gen = ++state.gen;
  $$("#tabs button[data-page]").forEach((b) => b.classList.toggle("active", b.dataset.page === state.page));
  $("#tab-des").classList.toggle("hidden", !state.sym);
  const scroll = PAGE.scrollTop;
  setStatus("busy", "Updating...");
  try {
    await (pages[state.page] || pages.mkts)(gen);
    if (gen === state.gen) {
      setStatus("ok", "Updated " + new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" }));
      if (silent) PAGE.scrollTop = scroll;
    }
  } catch (e) {
    if (gen === state.gen) {
      PAGE.innerHTML = errBox(e) + `<div class="note">Check your internet connection, then press REFRESH.</div>`;
      setStatus("err", "Error");
    }
  }
  clearTimeout(state.timer);
  if (state.page !== "help") {
    const again = () => {
      const a = document.activeElement;
      if (a && PAGE.contains(a) && ["INPUT", "SELECT", "TEXTAREA"].includes(a.tagName)) { state.timer = setTimeout(again, 15000); return; }
      render(true);
    };
    state.timer = setTimeout(again, 60000);
  }
}

function route() {
  const parts = location.hash.replace(/^#\/?/, "").split("/");
  const p = parts[0] || "mkts";
  if (p === "des" && parts[1]) {
    const s = decodeURIComponent(parts[1]).toUpperCase();
    if (s !== state.sym) { state.range = "1Y"; state.optExp = null; }
    state.sym = s;
    const f = (parts[2] || "").toLowerCase();
    state.fn = SEC_FN_KEYS.includes(f) ? f : "des";
  }
  if (p === "comp" && parts[1]) state.comp = parts[1].split(",").map((x) => decodeURIComponent(x).toUpperCase()).filter(Boolean);
  state.page = pages[p] ? p : "mkts";
  render();
}
window.addEventListener("hashchange", route);

function go(page, sym) {
  if (sym) return goFn(sym, "des");
  const h = `#/${page}`;
  if (location.hash === h) render(); else location.hash = h;
}
function goFn(sym, fn) {
  if (!sym) return;
  const h = `#/des/${encodeURIComponent(sym)}${fn && fn !== "des" ? "/" + fn : ""}`;
  if (location.hash === h) render(); else location.hash = h;
}

/* row clicks (delegated) */
PAGE.addEventListener("click", (e) => {
  if (e.target.closest("a, button, input, select")) return;
  const row = e.target.closest("[data-sym], [data-fred]");
  if (!row) return;
  if (row.dataset.sym) return row.dataset.fn ? goFn(row.dataset.sym, row.dataset.fn) : go("des", row.dataset.sym);
  const panelEl = $("[id$='-hist']", PAGE);
  if (panelEl && row.dataset.fred) {
    $$("tr.sel", PAGE).forEach((x) => x.classList.remove("sel"));
    row.classList.add("sel");
    loadFred(panelEl.id, row.dataset.fred, row.dataset.tf || "lvl", row.dataset.name, row.dataset.unit || "");
    panelEl.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }
});
$("#tabs").addEventListener("click", (e) => {
  const b = e.target.closest("button");
  if (!b) return;
  if (b.id === "refresh") return render();
  if (b.dataset.page === "des") return goFn(state.sym, state.fn);
  if (b.dataset.page) go(b.dataset.page);
});

/* ------------------------------------------------------------------ command line */
const CMDS = { MKTS: "mkts", MKT: "mkts", HOME: "mkts", WEI: "mkts", EQTY: "eqty", EQ: "eqty", EQUITY: "eqty", MOST: "eqty", TOP: "news",
  GOVT: "govt", RATES: "govt", UST: "govt", GC: "govt", CORP: "corp", CREDIT: "corp", PRIV: "priv", PRIVATE: "priv", PE: "priv",
  ECON: "econ", ECO: "econ", MACRO: "econ", NEWS: "news", N: "news", HELP: "help", "?": "help",
  COMP: "comp", COMPARE: "comp", EVTS: "cal", CAL: "cal", CALENDAR: "cal", EARNINGS: "cal", IPO: "cal",
  EQS: "eqs", SCREEN: "eqs", SCREENER: "eqs", ALRT: "alrt", ALERT: "alrt", ALERTS: "alrt",
  EXT: "ext", PRE: "ext", POST: "ext", PREMARKET: "ext", AH: "ext", AFTERHOURS: "ext" };
const FNCMD = { DES: "des", GP: "gp", GIP: "gp", HP: "gp", FA: "fa", ERN: "ern", EE: "ern", EM: "ern", ANR: "anr", OMON: "omon", OPT: "omon",
  HDS: "hds", DVD: "dvd", RV: "rv", PEERS: "rv" };
const cmd = $("#cmd"), sug = $("#suggest");
let sugItems = [], sugSel = -1, sugTimer = null;

function closeSug() { sug.classList.add("hidden"); sugItems = []; sugSel = -1; }
function drawSug() {
  if (!sugItems.length) return closeSug();
  sug.innerHTML = sugItems.map((s, i) => `<div data-i="${i}" class="${i === sugSel ? "sel" : ""}"><span class="s-sym">${esc(s.sym)}</span><span>${esc(s.name)}</span><span class="s-meta">${esc(s.type)} ${esc(s.exch)}</span></div>`).join("");
  sug.classList.remove("hidden");
}
cmd.addEventListener("input", () => {
  clearTimeout(sugTimer);
  const q = cmd.value.trim();
  const tk = q.toUpperCase().split(/\s+/);
  if (q.length < 2 || CMDS[q.toUpperCase()] || tk[0] === "COMP" || (tk.length > 1 && FNCMD[tk[tk.length - 1]])) return closeSug();
  sugTimer = setTimeout(async () => {
    try { sugItems = await api(`/api/search?q=${encodeURIComponent(q)}`); sugSel = -1; drawSug(); } catch (e) { closeSug(); }
  }, 250);
});
function submit(v) {
  v = (v || "").trim().toUpperCase().replace(/\s+(US\s+)?(EQUITY|<GO>|GO)$/, "");
  cmd.value = ""; closeSug(); cmd.blur();
  if (!v) return;
  if (CMDS[v]) return go(CMDS[v]);
  const t = v.split(/[\s,]+/).filter(Boolean);
  if (t[0] === "COMP") return goComp(t.slice(1));
  if (t.length > 1 && t[t.length - 1] === "COMP") return goComp(t.slice(0, -1));
  if (t.length === 1 && FNCMD[t[0]] && state.sym) return goFn(state.sym, FNCMD[t[0]]);
  if (t.length >= 2 && FNCMD[t[t.length - 1]]) return goFn(t[0], FNCMD[t[t.length - 1]]);
  if (t.length >= 2 && FNCMD[t[0]]) return goFn(t[1], FNCMD[t[0]]);
  go("des", t[0]);
}
cmd.addEventListener("keydown", (e) => {
  if (e.key === "ArrowDown" && sugItems.length) { sugSel = (sugSel + 1) % sugItems.length; drawSug(); e.preventDefault(); }
  else if (e.key === "ArrowUp" && sugItems.length) { sugSel = (sugSel - 1 + sugItems.length) % sugItems.length; drawSug(); e.preventDefault(); }
  else if (e.key === "Enter") submit(sugSel >= 0 ? sugItems[sugSel].sym : cmd.value);
  else if (e.key === "Escape") { closeSug(); cmd.value = ""; }
});
sug.addEventListener("mousedown", (e) => { const d = e.target.closest("[data-i]"); if (d) { e.preventDefault(); submit(sugItems[+d.dataset.i].sym); } });
cmd.addEventListener("blur", () => setTimeout(closeSug, 150));
$(".cmd-go").onclick = () => submit(cmd.value);

const FKEYS = { F1: "mkts", F2: "eqty", F3: "govt", F4: "corp", F5: "priv", F6: "econ", F7: "news" };
document.addEventListener("keydown", (e) => {
  if (FKEYS[e.key]) { e.preventDefault(); return go(FKEYS[e.key]); }
  if (e.key === "F8" && state.sym) { e.preventDefault(); return goFn(state.sym, state.fn); }
  if ((e.ctrlKey && e.key.toLowerCase() === "r") || e.key === "F9") { e.preventDefault(); return render(); }
  const typing = document.activeElement && ["INPUT", "TEXTAREA", "SELECT"].includes(document.activeElement.tagName);
  if (!typing && (e.key === "/" || e.key === "Escape")) { e.preventDefault(); cmd.focus(); }
  else if (!typing && /^[a-zA-Z^]$/.test(e.key) && !e.ctrlKey && !e.altKey && !e.metaKey) { cmd.focus(); }
});

/* ------------------------------------------------------------------ clocks & tape */
function tick() {
  const z = [["NY", "America/New_York"], ["LDN", "Europe/London"], ["FRA", "Europe/Berlin"], ["TKY", "Asia/Tokyo"], ["HK", "Asia/Hong_Kong"]];
  const now = new Date();
  const ny = new Date(now.toLocaleString("en-US", { timeZone: "America/New_York" }));
  const mins = ny.getHours() * 60 + ny.getMinutes(), wd = ny.getDay();
  const open = wd > 0 && wd < 6 && mins >= 570 && mins < 960;
  const pre = wd > 0 && wd < 6 && mins >= 240 && mins < 570;
  const post = wd > 0 && wd < 6 && mins >= 960 && mins < 1200;
  $("#clocks").innerHTML = z.map(([l, tz]) => `<span>${l} <b>${now.toLocaleTimeString("en-GB", { timeZone: tz, hour: "2-digit", minute: "2-digit" })}</b></span>`).join("") +
    `<span class="${open ? "up" : pre || post ? "amber" : "down"}">US ${open ? "OPEN" : pre ? "PRE-MKT" : post ? "AFTER-HRS" : "CLOSED"}</span>`;
}
tick(); setInterval(tick, 15000);

function updateTape(groups) {
  if (!Array.isArray(groups)) return;
  const items = [];
  for (const g of groups) for (const r of g.rows) {
    if (r.missing) continue;
    const p = chgPct(r.last, r.prev);
    const v = g.kind === "yld" ? fmt(r.last, 3) + "%" : fmt(r.last, pxDigits(r.sym, r.last));
    const c = g.kind === "yld" ? `${bp((r.last - r.prev) * 100)}bp` : pct(p);
    const dir = g.kind === "yld" ? r.last - r.prev : p;
    items.push(`<span data-sym="${esc(r.sym)}"><b>${esc(r.name)}</b>${v} <span class="${cls(dir)}">${dir > 0 ? "&#9650;" : dir < 0 ? "&#9660;" : ""}${c}</span></span>`);
  }
  $("#tape-inner").innerHTML = items.join("");
}
$("#tape").addEventListener("click", (e) => { const s = e.target.closest("[data-sym]"); if (s) go("des", s.dataset.sym); });
async function refreshTape() { try { updateTape((await api("/api/overview")).groups); } catch (e) { /* ignore */ } }
refreshTape(); setInterval(refreshTape, 90000);

updateAlertBadge();
route();

# Market Terminal: six research apps, as readable source code

Everything here is plain text you can open in Notepad, TextEdit or any code editor: Python for the local server,
HTML/JavaScript/CSS for the windows. There is no installer, no .exe and no .bat. It runs on **Windows 10/11 and macOS**.

| App | What it does |
|-----|--------------|
| **Market Terminal** | Markets, rates, credit, economy, news, per-stock research (type e.g. `AAPL DES`, `TSLA OMON`) |
| **Portfolio Lab** | Backtest a portfolio: returns, risk, drawdowns, efficient frontier, Monte Carlo, historical stress tests |
| **Signal Monitor** | Wikipedia attention, news sentiment, Hacker News and GDELT vs stock prices; attention scanner with preset lists |
| **Influence Watch** | Who pushes which story (incl. Russian/Chinese/Iranian/Venezuelan state media), foreign agents (FARA), lobbying, donations, Congress and insider trades, federal contracts |
| **Auction Finder** | Police, government-surplus and local auctions for cars, tech, antiques, jewelry, tools, scored for what looks interesting |
| **Device Watch** | What your PC connects to, who owns those servers and where, and an audit of what the manufacturer installed |

## Run it

You need **Python 3.10 or newer** from https://www.python.org/downloads/ and, for the app windows, **Google Chrome,
Microsoft Edge or Brave**. Without one of those it still works, but opens in an ordinary browser tab.

**Windows**
1. Install Python (tick "Add python.exe to PATH" on the first screen).
2. Open this folder in File Explorer, click the address bar, type `cmd`, press Enter.
3. Type `python start.py` and press Enter.

**Mac**
1. Install Python from python.org (macOS's own `python3` may be too old).
2. Open **Terminal** (Applications > Utilities), type `cd ` (with a space), drag this folder into the Terminal window, press Enter.
3. Type `python3 start.py` and press Enter.

The first run takes a minute or two while it downloads the libraries. After that it starts in a few seconds.
The other apps open from the buttons in the Terminal's top bar, or directly (use `python3` on a Mac):

```
python start.py --app lab        (Portfolio Lab)
python start.py --app signal     (Signal Monitor)
python start.py --app watch      (Influence Watch)
python start.py --app auctions   (Auction Finder)
python start.py --app device     (Device Watch)
```

### The same thing by hand (exactly what start.py runs)

Windows:
```
python -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe app\main.py
```
Mac:
```
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python app/main.py
```

`start.py` prints each of these commands before it runs it, and only does steps 1 and 2 the first time.

### Device Watch on a Mac

- macOS only lets an administrator see every program's network connections. Started normally, Device Watch shows
  **your own programs**. To include system services: `sudo python3 start.py --app device` (it asks for your Mac password).
- The AUDIT tab checks the Mac's own protections and the places background software hides: System Integrity Protection,
  Gatekeeper, FileVault, the firewall, device-management (MDM) enrollment, launch agents and daemons, system extensions,
  every app's code signature (using Apple's `codesign`), added trusted certificates, proxy and DNS settings, remote access and accounts.
- There's no BLOCK button on a Mac: macOS's built-in firewall can't stop a program sending data out.
  The free **LuLu** (objective-see.org) does that.
- The DNS tab stays empty: macOS doesn't let apps read its DNS cache.

## What it touches on your PC

- **This folder**: `.venv` (the private Python environment). Delete the folder to remove the app completely.
- **Your settings and caches**: settings, caches, the Device Watch network log, and a separate browser profile for the app windows.
  Delete the folder to reset.
  - Windows: `%LOCALAPPDATA%\MarketTerminal`
  - Mac: `~/Library/Application Support/MarketTerminal`
- **Network**: a local web server on `127.0.0.1:8765`, reachable only from this computer.
- Device Watch changes system settings only when you click one of these buttons:
  - **BLOCK** (Windows only) adds an outbound Windows Firewall rule for one program. Windows asks for administrator permission first.
  - **Always-on** makes the network logger start at login. On Windows it adds a shortcut to your Startup folder.
    On a Mac it adds `~/Library/LaunchAgents/com.marketterminal.devicewatch.plist`.
  The code for both is `block()` and `set_always_on()` in `app/device.py`.

## Which websites each app contacts

All public, free sources. No accounts. Nothing about you is sent, except what you type into a Settings box (for example an email address the SEC asks for), and that goes only to the site that asked for it.

| App | Sites |
|-----|-------|
| Market Terminal, Portfolio Lab | Yahoo Finance, FRED (St. Louis Fed), news RSS feeds (CNBC, MarketWatch, Yahoo, Federal Reserve, Crunchbase, Google News) |
| Signal Monitor | Wikimedia (pageviews, edits), Google News, Hacker News (Algolia), GDELT, Yahoo Finance |
| Influence Watch | ~65 news RSS feeds (listed in its ABOUT tab), DOJ FARA, lda.gov, OpenFEC, Federal Register, House Clerk, SEC EDGAR, USAspending.gov |
| Auction Finder | propertyroom.com, api.gsa.gov (GSA Auctions), publicsurplus.com, hibid.com |
| Device Watch | data.iana.org and the five regional internet registries (ARIN, RIPE, APNIC, LACNIC, AFRINIC) to look up who owns an IP address. Only the IP address is sent. |

## Files

```
start.py            launcher (above)
requirements.txt    the five libraries it installs: yfinance, requests, feedparser, pypdf, psutil
app/main.py         local web server: maps each /api/... address to a Python function; opens the window
app/data.py         market data, FRED, news (Market Terminal)
app/research.py     per-stock functions: charts, financials, options, holders... (Market Terminal)
app/apps.py         Portfolio Lab + Signal Monitor
app/watch.py        Influence Watch: feeds, stories, framing, FARA, lobbying, FEC
app/trades.py       Influence Watch: Congress trades, SEC insider trades, federal contracts
app/auctions.py     Auction Finder: the four auction sites + the interest score
app/device.py       Device Watch: connection logger, IP owner lookups, signature checks, PC audit
app/static/         the windows: one folder per app (index.html + .js), shared kit.js / style.css / apps.css
app/static/chart.umd.min.js   the Chart.js 4.4.1 charting library (see below)
app/icons/          window icons
```

### The one file that isn't hand-readable

`app/static/chart.umd.min.js` is the official, compressed release of the open-source Chart.js 4.4.1 library (MIT licence).
It's an unmodified copy of https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.js. To check it, compare the SHA-256 fingerprint:

```
certutil -hashfile app\static\chart.umd.min.js SHA256        (Windows)
shasum -a 256 app/static/chart.umd.min.js                    (Mac)
```

It should print `74401d738dd3e03ee5dfb3b6841210fe2c4ead8a960c4011ca4ba0b78a9fd8f3`.

---
For information only. Not investment advice.

"""Market Terminal launcher.

Run it with:   python start.py                (Windows)    python3 start.py        (Mac)
               python start.py --app watch    (or: lab, signal, watch, auctions, device)

What it does - every command is printed before it runs, nothing is hidden:
  1. First run only: creates a private Python environment in the folder ".venv" next to this file
     (python -m venv .venv), so nothing is installed into your system Python.
  2. First run only (or when requirements.txt changes): installs the libraries listed in requirements.txt
     into that environment with pip.
  3. Starts the app:  .venv python app/main.py  (plus any arguments you gave).
     The app runs a small web server on http://127.0.0.1:8765 (this PC only) and opens a window in Edge/Chrome.

To undo everything: delete this folder, and your settings/caches folder:
  Windows: %LOCALAPPDATA%\\MarketTerminal        Mac: ~/Library/Application Support/MarketTerminal
"""
import hashlib
import os
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
VENV = HERE / ".venv"
PY = VENV / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
REQS = HERE / "requirements.txt"
STAMP = VENV / "installed-requirements.sha256"


def run(cmd):
    print(">", " ".join(f'"{c}"' if " " in str(c) else str(c) for c in cmd), flush=True)
    subprocess.check_call([str(c) for c in cmd])


def main():
    if sys.version_info < (3, 10):
        sys.exit(f"Python 3.10 or newer is needed (this is {sys.version.split()[0]}). Get it from https://www.python.org/downloads/")
    if not PY.exists():
        print("Step 1/3: creating a private Python environment in .venv")
        run([sys.executable, "-m", "venv", VENV])
    want = hashlib.sha256(REQS.read_bytes()).hexdigest()
    if not STAMP.exists() or STAMP.read_text().strip() != want:
        print("Step 2/3: installing the libraries listed in requirements.txt (one time, a minute or two)")
        run([PY, "-m", "pip", "install", "--disable-pip-version-check", "-r", REQS])
        STAMP.write_text(want)
    print("Step 3/3: starting the app (close its window to stop it; the server stops about a minute later)")
    run([PY, HERE / "app" / "main.py", *sys.argv[1:]])


if __name__ == "__main__":
    try:
        main()
    except subprocess.CalledProcessError as e:
        sys.exit(f"\nThat command failed (exit code {e.returncode}). The output above says why.")
    except KeyboardInterrupt:
        pass

/* Portfolio Lab - backtesting & risk analytics */
"use strict";

const PRESETS = [
  ["60/40 Classic", [["SPY", 60], ["AGG", 40]]],
  ["Three-Fund", [["VTI", 50], ["VXUS", 30], ["BND", 20]]],
  ["All Weather", [["VTI", 30], ["TLT", 40], ["IEF", 15], ["GLD", 7.5], ["DBC", 7.5]]],
  ["Permanent", [["VTI", 25], ["TLT", 25], ["GLD", 25], ["BIL", 25]]],
  ["Magnificent 7", [["AAPL", 1], ["MSFT", 1], ["NVDA", 1], ["AMZN", 1], ["GOOGL", 1], ["META", 1], ["TSLA", 1]]],
  ["Dividend Income", [["SCHD", 40], ["VYM", 30], ["JEPI", 15], ["VNQ", 15]]],
  ["Global Equity", [["VTI", 55], ["VEA", 30], ["VWO", 15]]],
  ["Risk Parity-ish", [["SPY", 25], ["TLT", 35], ["GLD", 20], ["TIP", 20]]],
];
const KEY = "lab.state", SAVED = "lab.saved";
const S = Object.assign({ name: "My Portfolio", rows: [["SPY", 60], ["AGG", 40]], bench: "SPY", period: "10Y", rebal: "Q",
  amount: 10000, contrib: 0, horizon: 10, log: false }, store(KEY) || {});
let LAST = null;

function save() { store(KEY, S); }
function holdingsParam() { return S.rows.filter((r) => r[0] && +r[1] > 0).map((r) => `${r[0].toUpperCase()}:${+r[1]}`).join(","); }

/* ------------------------------------------------------------------ editor */
function renderEditor() {
  const saved = store(SAVED) || {};
  const tot = S.rows.reduce((a, r) => a + (+r[1] || 0), 0);
  $("#editor").innerHTML = panel("Portfolio", `
    <div class="form">
      <label>Name <input id="p-name" value="${esc(S.name)}"></label>
      <div class="two">
        <label>Saved <select id="p-saved"><option value="">-- load saved --</option>${Object.keys(saved).map((k) => `<option>${esc(k)}</option>`).join("")}</select></label>
        <label>&nbsp;<span style="display:flex;gap:4px"><button type="button" class="btn" id="p-save">SAVE</button><button type="button" class="btn" id="p-del">DELETE</button></span></label>
      </div>
      <table class="t holdings"><thead><tr><th>Ticker</th><th>Weight</th><th>%</th><th></th></tr></thead><tbody>${
        S.rows.map((r, i) => `<tr><td><input class="h-sym" data-i="${i}" value="${esc(r[0])}" spellcheck="false"></td>
          <td><input class="h-w" data-i="${i}" value="${esc(r[1])}"></td><td class="muted">${tot > 0 && +r[1] > 0 ? fmt((+r[1] / tot) * 100, 1) : "--"}</td>
          <td><button type="button" class="x" data-rm="${i}">&times;</button></td></tr>`).join("")}</tbody></table>
      <div style="display:flex;gap:4px;flex-wrap:wrap">
        <button type="button" class="btn" id="h-add">+ ROW</button><button type="button" class="btn" id="h-eq">EQUAL WEIGHT</button>
        <button type="button" class="btn" id="h-wl" title="Import the Terminal watchlist (equal weight)">IMPORT WATCHLIST</button></div>
      <div class="note" style="padding:0">Weights are normalised to 100%. Any Yahoo ticker works: stocks, ETFs, mutual funds, crypto (BTC-USD).</div>
    </div>`, { src: "" }) +
  panel("Presets", `<div class="chips" style="padding:8px">${PRESETS.map(([n], i) => `<button type="button" class="btn sm" data-pre="${i}">${esc(n)}</button>`).join("")}</div>`) +
  panel("Settings", `<div class="form">
      <label>Benchmark <input id="s-bench" value="${esc(S.bench)}" spellcheck="false"></label>
      <label>Backtest period ${segHTML("s-period", ["1Y", "3Y", "5Y", "10Y", "20Y", "MAX"], S.period)}</label>
      <label>Rebalancing <select id="s-rebal">${[["none", "Never (buy & hold)"], ["M", "Monthly"], ["Q", "Quarterly"], ["A", "Annually"]].map(([v, l]) => `<option value="${v}" ${S.rebal === v ? "selected" : ""}>${l}</option>`).join("")}</select></label>
      <div class="two"><label>Starting amount $ <input id="s-amt" value="${esc(S.amount)}"></label><label>Monthly add $ (MC) <input id="s-con" value="${esc(S.contrib)}"></label></div>
      <label>Monte Carlo horizon (years) <input id="s-hor" value="${esc(S.horizon)}"></label>
      <button type="button" class="btn primary" id="run">&#9654; RUN BACKTEST</button>
    </div>`);
  const sync = () => {
    $$(".h-sym").forEach((x) => { S.rows[+x.dataset.i][0] = x.value.trim().toUpperCase(); });
    $$(".h-w").forEach((x) => { S.rows[+x.dataset.i][1] = parseFloat(x.value) || 0; });
    S.name = $("#p-name").value.trim() || "My Portfolio";
    S.bench = ($("#s-bench").value || "SPY").trim().toUpperCase();
    S.rebal = $("#s-rebal").value;
    S.amount = parseFloat($("#s-amt").value) || 10000;
    S.contrib = parseFloat($("#s-con").value) || 0;
    S.horizon = Math.max(1, Math.min(40, parseInt($("#s-hor").value, 10) || 10));
    save();
  };
  $$("#editor input").forEach((x) => { x.onchange = () => { sync(); if (x.classList.contains("h-w")) renderEditor(); }; x.onkeydown = (e) => { if (e.key === "Enter") { sync(); run(); } }; });
  $("#s-rebal").onchange = sync;
  bindSeg("s-period", (v) => { S.period = v; save(); });
  $$("[data-rm]").forEach((b) => (b.onclick = () => { sync(); S.rows.splice(+b.dataset.rm, 1); if (!S.rows.length) S.rows.push(["", 0]); save(); renderEditor(); }));
  $("#h-add").onclick = () => { sync(); S.rows.push(["", 10]); save(); renderEditor(); setTimeout(() => { const l = $$(".h-sym"); l[l.length - 1].focus(); }, 0); };
  $("#h-eq").onclick = () => { sync(); S.rows.forEach((r) => { if (r[0]) r[1] = 1; }); save(); renderEditor(); };
  $("#h-wl").onclick = () => {
    const wl = store("mt.watchlist") || ["AAPL", "MSFT", "NVDA", "SPY", "TLT", "GLD", "HYG"];
    S.rows = wl.slice(0, 25).map((s) => [s, 1]); S.name = "Watchlist (equal weight)"; save(); renderEditor();
  };
  $$("[data-pre]").forEach((b) => (b.onclick = () => { const [n, rows] = PRESETS[+b.dataset.pre]; S.name = n; S.rows = rows.map((r) => [...r]); save(); renderEditor(); run(); }));
  $("#p-save").onclick = () => { sync(); const sv = store(SAVED) || {}; sv[S.name] = { rows: S.rows, bench: S.bench, rebal: S.rebal }; store(SAVED, sv); renderEditor(); };
  $("#p-del").onclick = () => { const sv = store(SAVED) || {}; delete sv[S.name]; store(SAVED, sv); renderEditor(); };
  $("#p-saved").onchange = (e) => { const sv = store(SAVED) || {}; const p = sv[e.target.value]; if (p) { Object.assign(S, { name: e.target.value }, p); S.rows = p.rows.map((r) => [...r]); save(); renderEditor(); run(); } };
  $("#run").onclick = () => { sync(); run(); };
}

/* ------------------------------------------------------------------ results */
const kpi = (label, v, sub = "", c = "") => `<div class="kpi"><span>${label}</span><b class="${c}">${v}</b><small>${sub}</small></div>`;
const STAT_ROWS = [["Total Return", "total", (v) => pct(v)], ["CAGR", "cagr", (v) => pct(v)], ["Volatility (ann.)", "vol", (v) => fmt(v) + "%"],
  ["Sharpe Ratio", "sharpe", (v) => fmt(v)], ["Sortino Ratio", "sortino", (v) => fmt(v)], ["Max Drawdown", "mdd", (v) => pct(v)],
  ["Current Drawdown", "cur_dd", (v) => pct(v)], ["Longest Drawdown", "longest_dd", (v) => (isNum(v) ? fmt(v, 0) + " days" : "--")],
  ["Calmar Ratio", "calmar", (v) => fmt(v)], ["Daily VaR 95%", "var95", (v) => (isNum(v) ? "-" + fmt(v) + "%" : "--")],
  ["Daily CVaR 95%", "cvar95", (v) => (isNum(v) ? "-" + fmt(v) + "%" : "--")], ["Best Month", "best_m", (v) => pct(v)], ["Worst Month", "worst_m", (v) => pct(v)],
  ["Positive Months", "pos_m", (v) => fmt(v, 1) + "%"], ["Best Day", "best_d", (v) => pct(v)], ["Worst Day", "worst_d", (v) => pct(v)],
  ["Beta", "beta", (v) => fmt(v)], ["Alpha (ann.)", "alpha", (v) => pct(v)], ["Correlation", "corr", (v) => fmt(v)],
  ["Tracking Error", "te", (v) => fmt(v) + "%"], ["Information Ratio", "ir", (v) => fmt(v)], ["Up Capture", "up_cap", (v) => fmt(v, 1) + "%"],
  ["Down Capture", "down_cap", (v) => fmt(v, 1) + "%"], ["Ending Value", "end", money]];
const heat = (v, s = 6) => (!isNum(v) ? "transparent" : v >= 0 ? `rgba(30,170,90,${Math.min(0.85, 0.12 + Math.abs(v) / s * 0.7).toFixed(2)})` : `rgba(220,50,50,${Math.min(0.85, 0.12 + Math.abs(v) / s * 0.7).toFixed(2)})`);
const corrC = (v) => (!isNum(v) ? "transparent" : v >= 0 ? `rgba(255,160,40,${(v * 0.55).toFixed(2)})` : `rgba(92,179,255,${(-v * 0.55).toFixed(2)})`);
const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

async function run() {
  const h = holdingsParam();
  if (!h) { $("#results").innerHTML = errBox("Add at least one ticker with a weight"); return; }
  setStatus("busy", "Running backtest...");
  $("#results").innerHTML = `<div class="loading">Downloading full price history and running ${esc(S.name)}...</div>`;
  try {
    const qs = new URLSearchParams({ h, bench: S.bench, period: S.period, rebal: S.rebal, amount: S.amount, contrib: S.contrib, horizon: S.horizon });
    LAST = await api(`/api/lab/backtest?${qs}`);
    draw(LAST);
    setStatus("ok", "Done " + new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }));
  } catch (e) {
    $("#results").innerHTML = errBox(e);
    setStatus("err", "Error");
  }
}

function draw(d) {
  const st = d.stats, bs = d.bench_stats || {};
  const B = d.bench || "Benchmark";
  const vs = (k, f) => (isNum(bs[k]) ? `${esc(B)} ${f(bs[k])}` : "");
  const rebal = { none: "buy & hold", M: "monthly rebalance", Q: "quarterly rebalance", A: "annual rebalance" }[d.rebal];
  const kpis = `<div class="kpis">
    ${kpi("CAGR", pct(st.cagr), vs("cagr", pct), cls(st.cagr))}${kpi("Total Return", pct(st.total), vs("total", pct), cls(st.total))}
    ${kpi("Volatility", fmt(st.vol) + "%", vs("vol", (v) => fmt(v) + "%"))}${kpi("Sharpe", fmt(st.sharpe), vs("sharpe", (v) => fmt(v)))}
    ${kpi("Max Drawdown", pct(st.mdd), vs("mdd", pct), "down")}${kpi("Beta", fmt(st.beta), "vs " + esc(B))}
    ${kpi("Ending Value", money(st.end), "from " + money(d.amount))}</div>`;
  const statT = `<table class="t"><thead><tr><th>Metric</th><th>${esc(S.name)}</th><th>${esc(B)}</th></tr></thead><tbody>${
    STAT_ROWS.map(([l, k, f]) => `<tr><td class="nm">${l}</td><td class="last">${f(st[k])}</td><td>${["beta", "alpha", "corr", "te", "ir", "up_cap", "down_cap"].includes(k) ? "" : f(bs[k])}</td></tr>`).join("")}</tbody></table>`;
  const yrs = Object.keys(d.monthly).sort();
  const yrMap = Object.fromEntries(d.years.map((y) => [String(y.year), y]));
  const monT = `<table class="t heatm"><thead><tr><th>Year</th>${MONTHS.map((m) => `<th>${m}</th>`).join("")}<th>Year</th><th>${esc(B)}</th></tr></thead><tbody>${
    yrs.slice().reverse().map((y) => `<tr><td class="amber">${y}</td>${d.monthly[y].map((v) => `<td style="background:${heat(v)}">${isNum(v) ? fmt(v, 1) : ""}</td>`).join("")}
      <td style="background:${heat((yrMap[y] || {}).port, 25)}" class="last">${pct((yrMap[y] || {}).port, 1)}</td><td class="muted">${pct((yrMap[y] || {}).bench, 1)}</td></tr>`).join("")}</tbody></table>`;
  const H = d.holdings;
  const holdT = `<table class="t"><thead><tr><th>Holding</th><th>Weight</th><th>Risk Contrib.</th><th></th><th>CAGR</th><th>Total</th><th>Vol</th><th>Max DD</th><th>Sharpe</th><th>Corr to Port.</th><th>Data Since</th></tr></thead><tbody>${
    H.map((x) => `<tr><td class="amber">${esc(x.sym)}</td><td>${fmt(x.weight, 1)}%</td><td class="${x.risk > x.weight * 1.3 ? "down" : ""}">${fmt(x.risk, 1)}%</td>
      <td style="width:110px"><div class="rbar"><span class="w" style="width:${Math.min(100, x.weight)}%"></span><span class="r" style="width:${Math.max(0, Math.min(100, x.risk))}%"></span></div></td>
      <td class="${cls(x.cagr)}">${pct(x.cagr)}</td><td class="${cls(x.total)}">${pct(x.total, 1)}</td><td>${fmt(x.vol, 1)}%</td><td class="down">${pct(x.mdd, 1)}</td>
      <td>${fmt(x.sharpe)}</td><td>${fmt(x.corr)}</td><td class="muted">${esc(x.since)}</td></tr>`).join("")}</tbody></table>
    <div class="note">Bars: <span class="amber">weight</span> vs <span style="color:var(--blue)">share of portfolio risk</span>. A holding whose risk share far exceeds its weight dominates the portfolio's swings.</div>`;
  const stressT = `<table class="t"><thead><tr><th>Episode</th><th>Window</th><th>Portfolio</th><th>${esc(B)}</th><th>Difference</th></tr></thead><tbody>${
    d.stress.map((x) => `<tr><td class="nm">${esc(x.name)}</td><td class="muted">${esc(x.start)} &rarr; ${esc(x.end)}</td>
      <td>${isNum(x.port) ? `<span class="pill ${cls(x.port)}">${pct(x.port, 1)}</span>${x.coverage < 100 ? ` <span class="muted" title="Only ${x.coverage}% of the portfolio existed then; result uses those holdings">(${fmt(x.coverage, 0)}% cov.)</span>` : ""}` : `<span class="muted">no data</span>`}</td>
      <td class="${cls(x.bench)}">${pct(x.bench, 1)}</td><td class="${cls(isNum(x.port) && isNum(x.bench) ? x.port - x.bench : null)}">${isNum(x.port) && isNum(x.bench) ? pct(x.port - x.bench, 1) : "--"}</td></tr>`).join("")}</tbody></table>
    <div class="note">Buy-and-hold return of today's weights through each historical episode (peak-to-trough windows of the S&amp;P 500, plus the 2020 rebound).</div>`;
  const C = d.corr;
  const corrT = `<table class="t corr"><thead><tr><th></th>${C.syms.map((s) => `<th>${esc(s)}</th>`).join("")}</tr></thead><tbody>${
    C.syms.map((a, i) => `<tr><td class="amber">${esc(a)}</td>${C.m[i].map((v) => `<td style="background:${corrC(v)}">${fmt(v)}</td>`).join("")}</tr>`).join("")}</tbody></table>`;
  const F = d.frontier && !d.frontier.error ? d.frontier : null;
  const wTable = (p, title, key) => `<div class="opt"><b>${title}</b> <span class="muted">ret ${pct(p.ret, 1)} &middot; vol ${fmt(p.vol, 1)}% &middot; Sharpe ${fmt(p.sharpe)}</span>
    <div class="chips" style="margin-top:4px">${Object.entries(p.w).sort((a, b) => b[1] - a[1]).map(([s, w]) => `<span class="chip" style="padding-right:7px">${esc(s)} ${fmt(w, 1)}%</span>`).join("")}</div>
    ${key ? `<button type="button" class="btn sm" data-apply="${key}" style="margin-top:5px">APPLY THESE WEIGHTS</button>` : ""}</div>`;
  const M = d.mc && !d.mc.error ? d.mc : null;
  const mcBox = M ? `<div class="kpis small">${kpi("Median outcome", money(M.median_end), `after ${M.years}y`)}${kpi("Bad case (5th pct)", money(M.p5_end), "", "down")}
      ${kpi("Good case (95th pct)", money(M.p95_end), "", "up")}${kpi("Chance of loss", fmt(M.prob_loss, 1) + "%", `vs ${money(M.invested)} invested`, M.prob_loss > 20 ? "down" : "")}
      ${kpi("Chance to double", fmt(M.prob_double, 1) + "%")}</div>
      <div class="chart-box"><canvas id="mc-cv"></canvas></div>
      <div class="note">${fmt(M.paths, 0)} simulated paths, resampling 3-month blocks of this portfolio's own ${M.hist_months} months of history${S.contrib ? `, adding ${money(S.contrib)}/month` : ""}. Past behaviour is not a forecast.</div>` : errBox(d.mc && d.mc.error);

  $("#results").innerHTML = `
    <section class="panel"><div class="ph"><h3>${esc(S.name)} vs ${esc(B)}</h3><span class="muted">${esc(d.start)} &rarr; ${esc(d.end)} &middot; ${rebal} &middot; risk-free ${fmt(d.rf)}%</span>
      <span class="src">${d.limiter ? `history limited by <b class="amber">${esc(d.limiter)}</b>` : ""}</span></div>${kpis}</section>
    <div class="grid">
      ${panel("Growth of " + money(d.amount), `<div class="chart-box tall"><canvas id="g-cv"></canvas></div>`, { cls: "c8", tools: `<button class="btn sm" id="logbtn">${S.log ? "LINEAR" : "LOG SCALE"}</button><button class="btn sm" id="csv">CSV</button>` })}
      ${panel("Statistics", statT, { cls: "c4", scroll: true, maxh: 430 })}
      ${panel("Drawdowns (underwater)", `<div class="chart-box short"><canvas id="dd-cv"></canvas></div>`, { cls: "c6" })}
      ${panel("Rolling 1-Year Return &amp; 3-Month Volatility", `<div class="chart-box short"><canvas id="roll-cv"></canvas></div>`, { cls: "c6" })}
      ${panel("Calendar-Year Returns", `<div class="chart-box short"><canvas id="yr-cv"></canvas></div>`, { cls: "c12" })}
      ${panel("Monthly Returns (%)", monT, { cls: "c12", scroll: true, maxh: 360 })}
      ${panel("Holdings &amp; Risk Contribution", holdT, { cls: "c12" })}
      ${F ? panel("Efficient Frontier (long-only, 4,000 random portfolios)", `<div class="chart-box tall"><canvas id="ef-cv"></canvas></div>`, { cls: "c8" }) : ""}
      ${F ? panel("Optimised Mixes", wTable(F.current, "Your portfolio") + wTable(F.max_sharpe, "Max Sharpe", "max_sharpe") + wTable(F.min_vol, "Min Volatility", "min_vol") +
        `<div class="note">Optimised on historical returns over this window: they chase what worked in the past, so treat them as a sensitivity check, not a recommendation.</div>`, { cls: "c4" }) : ""}
      ${panel(`Monte Carlo - ${S.horizon} Year Projection`, mcBox, { cls: "c8" })}
      ${panel("Correlation Matrix", corrT, { cls: "c4", scroll: true, maxh: 520 })}
      ${panel("Historical Stress Tests", stressT, { cls: "c12" })}
    </div>`;

  const L = d.labels;
  const growth = () => line("g-cv", L, [{ label: S.name, data: d.port, color: "#ffa028", borderWidth: 2, fill: true, bg: "rgba(255,160,40,.07)" },
    ...(d.bench_series ? [{ label: B, data: d.bench_series, color: "#5cb3ff" }] : [])], { log: S.log, fmt: money, xticks: 10 });
  growth();
  $("#logbtn").onclick = () => { S.log = !S.log; save(); $("#logbtn").textContent = S.log ? "LINEAR" : "LOG SCALE"; growth(); };
  $("#csv").onclick = () => downloadCSV("backtest.csv", [["Date", S.name, B], ...L.map((x, i) => [x, d.port[i], d.bench_series ? d.bench_series[i] : ""])]);
  line("dd-cv", L, [{ label: S.name, data: d.dd, color: "#ff5252", fill: true, bg: "rgba(255,82,82,.15)" },
    ...(d.bench_dd ? [{ label: B, data: d.bench_dd, color: "#5cb3ff", borderWidth: 1 }] : [])], { fmt: (v) => fmt(v, 1) + "%", yfmt: (v) => fmt(v, 0) + "%", xticks: 5 });
  line("roll-cv", L, [{ label: "Rolling 1Y return", data: d.roll_ret, color: "#34d27b" }, { label: "Rolling 3M volatility", data: d.roll_vol, color: "#c084fc" }],
    { fmt: (v) => fmt(v, 1) + "%", yfmt: (v) => fmt(v, 0) + "%", xticks: 5 });
  bars("yr-cv", d.years.map((y) => String(y.year)), [
    { label: S.name, data: d.years.map((y) => y.port), backgroundColor: d.years.map((y) => (y.port >= 0 ? "#1faa5a" : "#dc3232")) },
    ...(d.bench ? [{ label: B, data: d.years.map((y) => y.bench), backgroundColor: "#5cb3ff88" }] : [])], { fmt: (v) => pct(v, 1), yfmt: (v) => fmt(v, 0) + "%" });
  if (F) {
    const shs = F.cloud.map((p) => p[2]).filter(isNum);
    const lo = Math.min(...shs), hi = Math.max(...shs);
    const col = (s) => { const t = isNum(s) && hi > lo ? (s - lo) / (hi - lo) : 0.5; return `hsla(${Math.round(220 - t * 190)},80%,55%,.55)`; };
    mkChart("ef-cv", {
      type: "scatter",
      data: { datasets: [
        { label: "Random portfolios", data: F.cloud.map((p) => ({ x: p[0], y: p[1], s: p[2] })), pointRadius: 2, backgroundColor: F.cloud.map((p) => col(p[2])) },
        { label: "Single assets", data: F.assets.map((a) => ({ x: a.vol, y: a.ret, n: a.sym })), pointRadius: 5, pointStyle: "rectRot", backgroundColor: "#e4e4e4" },
        { label: "Your portfolio", data: [{ x: F.current.vol, y: F.current.ret }], pointRadius: 9, pointStyle: "star", borderColor: "#ffa028", borderWidth: 2, backgroundColor: "#ffa028" },
        { label: "Max Sharpe", data: [{ x: F.max_sharpe.vol, y: F.max_sharpe.ret }], pointRadius: 7, pointStyle: "triangle", backgroundColor: "#34d27b" },
        { label: "Min Volatility", data: [{ x: F.min_vol.vol, y: F.min_vol.ret }], pointRadius: 7, pointStyle: "triangle", backgroundColor: "#5cb3ff" },
      ] },
      options: { responsive: true, maintainAspectRatio: false, animation: false,
        plugins: { legend: { labels: { color: "#cfcfcf", boxWidth: 10, usePointStyle: true } },
          tooltip: { ...TIP, callbacks: { label: (c) => ` ${c.raw.n || c.dataset.label}: return ${fmt(c.raw.y, 1)}%, vol ${fmt(c.raw.x, 1)}%${isNum(c.raw.s) ? `, Sharpe ${fmt(c.raw.s)}` : ""}` } } },
        scales: { x: { title: { display: true, text: "Volatility (annualised %)" } }, y: { position: "right", title: { display: true, text: "Return (annualised %)" } } } },
      plugins: [{ id: "lbl", afterDatasetsDraw(ch) {
        const ctx = ch.ctx; ctx.save(); ctx.font = "10px Cascadia Mono, Consolas, monospace"; ctx.fillStyle = "#e4e4e4";
        ch.getDatasetMeta(1).data.forEach((el, i) => ctx.fillText(F.assets[i].sym, el.x + 7, el.y - 5)); ctx.restore();
      } }],
    });
    $$("[data-apply]").forEach((b) => (b.onclick = () => {
      const p = F[b.dataset.apply];
      S.rows = Object.entries(p.w).map(([s, w]) => [s, w]); S.name = S.name.replace(/ \((Max Sharpe|Min Vol)\)$/, "") + (b.dataset.apply === "max_sharpe" ? " (Max Sharpe)" : " (Min Vol)");
      save(); renderEditor(); run();
    }));
  }
  if (M) {
    const lab = M.months.map((m) => (m % 12 === 0 ? `Y${m / 12}` : `${(m / 12).toFixed(1)}`));
    line("mc-cv", lab, [
      { label: "5th pct", data: M.bands.p5, color: "rgba(255,82,82,.6)", borderWidth: 1, noLegend: true },
      { label: "5-95% range", data: M.bands.p95, color: "rgba(52,210,123,.6)", borderWidth: 1, fill: "-1", bg: "rgba(92,179,255,.08)" },
      { label: "25th pct", data: M.bands.p25, color: "rgba(92,179,255,.4)", borderWidth: 1, noLegend: true },
      { label: "25-75% range", data: M.bands.p75, color: "rgba(92,179,255,.4)", borderWidth: 1, fill: "-1", bg: "rgba(92,179,255,.18)" },
      { label: "Median", data: M.bands.p50, color: "#ffa028", borderWidth: 2.2 },
    ], { fmt: money, xticks: 12 });
  }
}

renderEditor();
if (holdingsParam()) run();

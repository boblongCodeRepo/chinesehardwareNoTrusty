/* Device Watch - what is this PC talking to, and what did the manufacturer put on it? */
"use strict";
const PAGE = $("#page");
const DS = Object.assign({ tab: "home", hours: 168, q: "", flaggedOnly: false, hideMs: false, view: "prog" }, store("dev.state") || {});
const saveD = () => store("dev.state", DS);
{ const t = location.hash.replace(/^#\/?/, ""); if (t) DS.tab = t; }
let gen = 0, timer = null;
const IS_MAC = /Macintosh|Mac OS X/.test(navigator.userAgent);
const IS_WIN = /Windows/.test(navigator.userAgent);
const CAN_BLOCK = IS_WIN;  // macOS's built-in firewall can't block outgoing traffic per program
const blockBtn = (exe, style) => (CAN_BLOCK && exe ? `<button class="btn sm" ${style ? `style="${style}"` : ""} data-block="${esc(exe)}" title="Block this program's internet access (Windows Firewall, asks for admin)">BLOCK</button>` : "");
const OSWORD = IS_MAC ? "Mac" : "PC";

function go(tab) { DS.tab = tab; saveD(); render(); }
$("#tabs").onclick = (e) => { const b = e.target.closest("button[data-tab]"); if (b) go(b.dataset.tab); };
const cmd = $("#cmd");
const submit = () => { DS.q = cmd.value.trim(); saveD(); if (!["hist", "dns", "live"].includes(DS.tab)) DS.tab = "hist"; render(); };
cmd.onkeydown = (e) => { if (e.key === "Enter") submit(); };
$(".cmd-go").onclick = submit;
cmd.value = DS.q || "";

function render() {
  gen++;
  clearInterval(timer);
  $$("#tabs button").forEach((b) => b.classList.toggle("active", b.dataset.tab === DS.tab));
  ({ home, live, hist, dns, traffic, audit, alerts, about }[DS.tab] || home)(gen);
}

/* ------------------------------------------------------------------ helpers */
function bytes(v, rate) {
  if (!isNum(v)) return "--";
  const u = ["B", "KB", "MB", "GB", "TB"]; let i = 0;
  while (Math.abs(v) >= 1024 && i < u.length - 1) { v /= 1024; i++; }
  return fmt(v, i ? 1 : 0) + " " + u[i] + (rate ? "/s" : "");
}
const when = (ts) => (ts ? new Date(ts * 1000).toLocaleString([], { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" }) : "--");
const LVL = ["", "REVIEW", "ALERT"], LVLC = ["#8b8b92", "#ffa028", "#ff5252"];
const lvlTag = (l, title) => (l ? `<span class="stag" style="--c:${LVLC[l]}" title="${esc(title || "")}">${LVL[l]}</span>` : "");
const okTag = () => `<span class="stag" style="--c:#34d27b">OK</span>`;
const CC = { US: "United States", CN: "China", HK: "Hong Kong", MO: "Macau", IE: "Ireland", NL: "Netherlands", DE: "Germany", GB: "United Kingdom",
  JP: "Japan", SG: "Singapore", TW: "Taiwan", KR: "South Korea", CA: "Canada", FR: "France", AU: "Australia", IN: "India", RU: "Russia", "??": "Unknown" };
const ccName = (c) => CC[c] || c || "?";
const base = (p) => (p || "").split(/[\\/]/).pop();
function signerHTML(s) {
  if (!s) return `<span class="muted">checking...</span>`;
  if (s === "NotSigned") return `<span class="down">NOT SIGNED</span>`;
  if (s.startsWith("BAD:")) return `<span class="down">INVALID SIGNATURE</span>`;
  return esc(s);
}
function destHTML(d) {
  const where = d.kind === "public" ? `${esc(d.org || "looking up...")}${d.country ? ` <span class="${d.lvl >= 2 ? "down" : "muted"}">${esc(d.country)}</span>` : ""}` : `<span class="muted">${esc(d.cat)}</span>`;
  return `${lvlTag(d.lvl, (d.why || []).join("; "))}<span class="amber">${esc(d.host || d.ip)}</span>${d.host ? ` <span class="muted small">${esc(d.ip)}</span>` : ""} &middot; ${where}`;
}
const MS = IS_MAC
  ? /^apple$|apple inc|com\.apple|mdnsresponder|trustd|nsurlsessiond|apsd|cloudd|identityservicesd|akd|rapportd|sharingd|softwareupdated|parsecd|assistantd|safari|mail$|timed|symptomsd|networkserviceproxy/i
  : /microsoft|windows|msedge|onedrive|copilot|searchhost|smartscreen|svchost|msmpeng|mssense|nissrv|widgets|phoneexperience|wudf|lsass|system$/i;
const matchQ = (s) => !DS.q || s.toLowerCase().includes(DS.q.toLowerCase());
async function statusBar() {
  const s = await soft(api("/api/dev/status"));
  if (s.error) { setStatus("err", "Collector error"); return s; }
  $("#rate").innerHTML = `&#9650; <b>${bytes(s.up_bps, 1)}</b> &nbsp;&#9660; <b>${bytes(s.down_bps, 1)}</b>`;
  setStatus(s.err ? "err" : "ok", s.err ? "Collector: " + s.err : `Logging every ${s.interval}s${s.always_on ? " · always-on" : ""}`);
  return s;
}

/* ================================================================== HOME */
async function home(g) {
  PAGE.innerHTML = `<div class="loading">Reading the network log...</div>`;
  const [s, h, ev, tr] = await Promise.all([statusBar(), soft(api(`/api/dev/history?hours=${DS.hours}`)), soft(api("/api/dev/events")), soft(api("/api/dev/traffic?hours=24"))]);
  if (g !== gen) return;
  if (h.error) { PAGE.innerHTML = errBox(h.error); return; }
  const flaggedOrgs = h.orgs.filter((o) => o.lvl >= 2);
  const flaggedProgs = h.programs.filter((p) => p.lvl >= 1);
  const alertsN = arr(ev.rows).filter((e) => e.level >= 2).length;
  const span = s.since ? (Date.now() / 1000 - s.since) / 3600 : 0;
  const verdict = flaggedOrgs.length
    ? `<b class="down">${flaggedOrgs.length} Chinese-linked network owner(s)</b> contacted in this window. They're listed below with the program that made each connection. Open WHO for detail; a program you don't need can be blocked from there.`
    : span < 1 ? `Device Watch has only just started logging. Leave it running (or turn on <b>always-on</b> below): the useful picture builds up over hours and days, especially overnight when nobody is using the PC.`
    : `<b class="up">No connections to networks registered in China, Hong Kong or Macau</b> in the last ${fmt(Math.min(span, DS.hours), 0)} hours of logging, out of <b>${h.orgs.length}</b> network owners contacted by <b>${h.programs.length}</b> programs.`;
  PAGE.innerHTML = `<div class="grid">
    <section class="panel c12"><div class="pb flush"><div class="intro dev">${verdict}</div></div></section>
    <section class="panel c12"><div class="pb flush"><div class="kpis">
      <div class="kpi"><span>Logging since</span><b>${s.since ? when(s.since) : "now"}</b><small>${fmt(span, 1)} h &middot; ${fmt(s.cov24, 0)}% of last 24h covered</small></div>
      <div class="kpi"><span>Programs online</span><b>${h.programs.length}</b><small>${flaggedProgs.length} to review</small></div>
      <div class="kpi"><span>Network owners</span><b>${h.orgs.length}</b><small>${s.pending_ips ? s.pending_ips + " still being looked up" : "all identified"}</small></div>
      <div class="kpi"><span>China / HK / Macau</span><b class="${flaggedOrgs.length ? "down" : "up"}">${flaggedOrgs.length}</b><small>network owners</small></div>
      <div class="kpi"><span>Uploaded (24h)</span><b>${bytes(tr.tot_sent)}</b><small>whole PC</small></div>
      <div class="kpi"><span>Downloaded (24h)</span><b>${bytes(tr.tot_recv)}</b><small>whole PC</small></div>
      <div class="kpi"><span>Alerts</span><b class="${alertsN ? "down" : ""}">${alertsN}</b><small>${arr(ev.rows).length} events logged</small></div>
      <div class="kpi"><span>Always-on</span><b>${s.always_on ? `<span class="up">ON</span>` : `<span class="amber">OFF</span>`}</b><small><a href="#" id="ao">${s.always_on ? "turn off" : "turn on (log 24/7)"}</a></small></div>
    </div></div></section>
    ${panel(`Window ${segHTML("hw", [[24, "24H"], [168, "7D"], [720, "30D"], [8760, "ALL"]], DS.hours)}`, "", { cls: "c12" })}
    ${panel("Which countries the PC talks to (by connection time)", `<div class="chart-box"><canvas id="cc-cv"></canvas></div>`, { cls: "c4" })}
    ${panel("What kind of companies", `<div class="chart-box"><canvas id="cat-cv"></canvas></div>`, { cls: "c4" })}
    ${panel("Upload vs download, last 24h", `<div class="chart-box"><canvas id="tr-cv"></canvas></div>`, { cls: "c4", src: "whole PC" })}
    ${panel("Needs a look", flagList(h), { cls: "c6", scroll: true, maxh: 420 })}
    ${panel("Busiest programs", `<table class="t"><thead><tr><th class="l">Program</th><th class="l">Signed by</th><th>Destinations</th><th>Last seen</th></tr></thead><tbody>${
      h.programs.slice().sort((a, b) => b.samples - a.samples).slice(0, 18).map((p) => `<tr><td class="l">${lvlTag(p.lvl)}<span class="amber">${esc(p.proc)}</span></td>
        <td class="l">${signerHTML(p.signer)}</td><td>${p.ndest}</td><td class="muted">${when(p.last)}</td></tr>`).join("")}</tbody></table>`, { cls: "c6", scroll: true, maxh: 420 })}
  </div>`;
  bindSeg("hw", (v) => { DS.hours = +v; saveD(); render(); });
  $("#ao").onclick = async (e) => { e.preventDefault(); const r = await soft(api(`/api/dev/always_on?on=${s.always_on ? 0 : 1}`)); if (r.error) alert(r.error); render(); };
  const top = h.countries.slice(0, 10);
  bars("cc-cv", top.map(([c]) => ccName(c)), [{ label: "samples", data: top.map(([, n]) => n), backgroundColor: top.map(([c]) => (["CN", "HK", "MO"].includes(c) ? "#ff5252" : "#5cb3ff")) }],
    { horizontal: true, legend: false, fmt: (v) => fmt(v, 0) });
  const cats = h.cats.slice(0, 10);
  bars("cat-cv", cats.map(([c]) => c || "?"), [{ label: "samples", data: cats.map(([, n]) => n), backgroundColor: "#f472b6" }], { horizontal: true, legend: false, fmt: (v) => fmt(v, 0) });
  trafficChart("tr-cv", tr);
  timer = setInterval(statusBar, 5000);
}
function flagList(h) {
  const rows = [];
  h.programs.forEach((p) => {
    if (p.lvl >= 1 && p.why.length) rows.push({ lvl: p.lvl, html: `<b class="amber">${esc(p.proc)}</b>: ${esc(p.why.join("; "))} <span class="muted small">${esc(p.exe)}</span>` });
    p.dests.filter((d) => d.lvl >= 2).forEach((d) => rows.push({ lvl: d.lvl, html: `<b class="amber">${esc(p.proc)}</b> &rarr; ${destHTML(d)} <span class="muted small">${d.samples} samples, last ${when(d.last)}</span>` }));
  });
  rows.sort((a, b) => b.lvl - a.lvl);
  return rows.length ? `<ul class="news iw">${rows.slice(0, 80).map((r) => `<li><span class="tx">${lvlTag(r.lvl)}${r.html}</span></li>`).join("")}</ul>`
    : `<div class="loading">Nothing flagged. Every program that used the network is signed, and no destination is registered in China / Hong Kong / Macau.</div>`;
}
function trafficChart(id, tr) {
  const L = tr.t.map((t) => new Date(t * 1000).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }));
  bars(id, L, [{ label: "Upload", data: tr.sent, backgroundColor: "#ffa028" }, { label: "Download", data: tr.recv, backgroundColor: "rgba(92,179,255,.5)" }],
    { fmt: (v) => bytes(v), yfmt: (v) => bytes(v), xticks: 8 });
}

/* ================================================================== LIVE */
async function live(g) {
  PAGE.innerHTML = `<div class="grid">${panel("Programs connected right now", `<div class="iwbar" style="padding:6px 8px">
      <label class="muted"><input type="checkbox" id="hidems" ${DS.hideMs ? "checked" : ""}> hide ${IS_MAC ? "Apple / macOS" : "Microsoft / Windows"}</label>
      <span class="muted small">Refreshes every 5 seconds. Loopback (this ${OSWORD} talking to itself) is hidden.</span></div>
      <div id="partial-note"></div><div id="live-box"><div class="loading">Sampling sockets...</div></div>`,
    { cls: "c12", src: "psutil, RDAP, Authenticode" })}</div>`;
  $("#hidems").onchange = (e) => { DS.hideMs = e.target.checked; saveD(); tick(); };
  const tick = async () => {
    const [d, s] = await Promise.all([soft(api("/api/dev/live")), statusBar()]);
    if (g !== gen || d.error) return;
    $("#partial-note").innerHTML = s && s.partial ? `<div class="note"><b class="amber">Showing your own programs only.</b> macOS only lets an administrator list
      every program's connections. To include system services too, start it from Terminal with <code>sudo python3 start.py</code>.</div>` : "";
    const ps = d.procs.filter((p) => (!DS.hideMs || !MS.test(p.proc + " " + p.signer)) && matchQ(p.proc + " " + p.exe + " " + p.conns.map((c) => c.ip + c.host + c.org).join(" ")));
    $("#live-box").innerHTML = `<table class="t"><thead><tr><th class="l">Program</th><th class="l">Signed by</th><th class="l">Connected to</th><th></th></tr></thead><tbody>${
      ps.map((p) => `<tr><td class="l" style="vertical-align:top">${lvlTag(p.lvl, p.why.join("; "))}<b class="amber">${esc(p.proc)}</b> <span class="muted small">pid ${p.pids.join(",")}</span>
          <div class="muted small">${esc(p.exe)}</div></td>
        <td class="l" style="vertical-align:top">${signerHTML(p.signer)}${p.company ? `<div class="muted small">${esc(p.company)}</div>` : ""}</td>
        <td class="l wrap">${p.conns.slice(0, 12).map((c) => `<div>${destHTML(c)} <span class="muted small">${c.proto}/${c.rport} ${esc(c.status === "NONE" ? "" : c.status)}</span></div>`).join("")}
          ${p.conns.length > 12 ? `<div class="muted small">+${p.conns.length - 12} more</div>` : ""}</td>
        <td style="vertical-align:top">${blockBtn(p.exe)}</td></tr>`).join("")
      || "<tr><td class='muted'>No matching connections right now</td></tr>"}</tbody></table>`;
    bindBlock();
  };
  await tick();
  timer = setInterval(() => { if (g === gen) tick(); }, 5000);
}
function bindBlock() {
  $$("[data-block]").forEach((b) => (b.onclick = async () => {
    const exe = b.dataset.block, undo = b.dataset.undo === "1";
    if (!confirm(undo ? `Remove the firewall block on\n${exe}?` : `Block ALL internet access for\n${exe}\n\nWindows will ask for administrator permission. You can undo it from the AUDIT tab.`)) return;
    const r = await soft(api(`/api/dev/block?exe=${enc(exe)}${undo ? "&undo=1" : ""}`));
    alert(r.error ? "Not done: " + r.error : undo ? "Block removed (if you approved the prompt)." : "Firewall rule added (if you approved the prompt).");
  }));
}

/* ================================================================== WHO (history) */
async function hist(g) {
  PAGE.innerHTML = `<div class="loading">Loading every destination...</div>`;
  const [h] = await Promise.all([soft(api(`/api/dev/history?hours=${DS.hours}`)), statusBar()]);
  if (g !== gen) return;
  if (h.error) { PAGE.innerHTML = errBox(h.error); return; }
  const tools = `<div class="iwbar" style="padding:6px 8px">${segHTML("hw", [[24, "24H"], [168, "7D"], [720, "30D"], [8760, "ALL"]], DS.hours)}
    ${segHTML("hv", [["prog", "BY PROGRAM"], ["org", "BY COMPANY"]], DS.view)}
    <label class="muted"><input type="checkbox" id="fo" ${DS.flaggedOnly ? "checked" : ""}> flagged only</label>
    <label class="muted"><input type="checkbox" id="hidems" ${DS.hideMs ? "checked" : ""}> hide Microsoft / Windows</label>
    ${DS.q ? `<span class="chip">search: ${esc(DS.q)} <button class="x" id="clrq">&times;</button></span>` : ""}
    <button class="btn sm" id="csv">CSV</button></div>`;
  let body;
  if (DS.view === "org") {
    const os = h.orgs.filter((o) => (!DS.flaggedOnly || o.lvl >= 2) && (!DS.hideMs || o.cat !== "Microsoft") && matchQ(o.org + " " + o.country + " " + o.progs.join(" ")));
    body = `<table class="t"><thead><tr><th class="l">Network owner</th><th>Country</th><th class="l">Type</th><th>IPs</th><th class="l">Programs that connected</th><th>Samples</th></tr></thead><tbody>${
      os.map((o) => `<tr><td class="l">${lvlTag(o.lvl)}<b>${esc(o.org)}</b></td><td class="${o.lvl >= 2 ? "down" : ""}">${esc(ccName(o.country))}</td><td class="l muted">${esc(o.cat)}</td>
        <td>${o.ips}</td><td class="l wrap">${o.progs.map(esc).join(", ")}</td><td>${fmt(o.samples, 0)}</td></tr>`).join("") || "<tr><td class='muted'>Nothing matches</td></tr>"}</tbody></table>`;
  } else {
    const ps = h.programs.filter((p) => (!DS.flaggedOnly || p.lvl >= 1) && (!DS.hideMs || !MS.test(p.proc + " " + p.signer)) &&
      matchQ(p.proc + " " + p.exe + " " + p.dests.map((d) => d.ip + d.host + d.org).join(" ")));
    body = ps.map((p) => `<details class="prog" ${p.lvl ? "open" : ""}><summary>${lvlTag(p.lvl, p.why.join("; "))}<b class="amber">${esc(p.proc)}</b>
        <span class="muted"> &middot; ${p.ndest} destinations &middot; signed by </span>${signerHTML(p.signer)}<span class="muted"> &middot; first ${when(p.first)} &middot; last ${when(p.last)}</span>
        ${blockBtn(p.exe, "float:right")}</summary>
        <div class="muted small" style="padding:0 8px 4px">${esc(p.exe)}${p.why.length ? ` &middot; <span class="amber">${esc(p.why.join("; "))}</span>` : ""}</div>
        <table class="t"><thead><tr><th class="l">Destination</th><th class="l">Ports</th><th>First seen</th><th>Last seen</th><th>Samples</th></tr></thead><tbody>${
          p.dests.filter((d) => !DS.flaggedOnly || d.lvl >= 2 || p.lvl).map((d) => `<tr><td class="l wrap">${destHTML(d)}</td><td class="l muted">${esc(d.ports.join(" "))}</td>
            <td class="muted">${when(d.first)}</td><td class="muted">${when(d.last)}</td><td>${d.samples}</td></tr>`).join("")}</tbody></table></details>`).join("")
      || `<div class="loading">Nothing matches</div>`;
  }
  PAGE.innerHTML = `<div class="grid">${panel(`Every destination contacted (${DS.hours >= 8760 ? "all time" : fmt(DS.hours / 24, 0) + " days"})`, tools + body, { cls: "c12", src: "RDAP (ARIN/RIPE/APNIC/LACNIC/AFRINIC) + DNS cache" })}</div>`;
  bindSeg("hw", (v) => { DS.hours = +v; saveD(); render(); });
  bindSeg("hv", (v) => { DS.view = v; saveD(); render(); });
  $("#fo").onchange = (e) => { DS.flaggedOnly = e.target.checked; saveD(); render(); };
  $("#hidems").onchange = (e) => { DS.hideMs = e.target.checked; saveD(); render(); };
  if ($("#clrq")) $("#clrq").onclick = () => { DS.q = ""; cmd.value = ""; saveD(); render(); };
  $("#csv").onclick = () => downloadCSV(`device-destinations-${new Date().toISOString().slice(0, 10)}.csv`,
    [["Program", "Path", "Signed by", "IP", "Host", "Owner", "Country", "Type", "Ports", "First seen", "Last seen", "Samples", "Flag"],
      ...h.programs.flatMap((p) => p.dests.map((d) => [p.proc, p.exe, p.signer, d.ip, d.host, d.org, d.country, d.cat, d.ports.join(" "),
        new Date(d.first * 1000).toISOString(), new Date(d.last * 1000).toISOString(), d.samples, LVL[Math.max(d.lvl, p.lvl)]]))]);
  bindBlock();
}

/* ================================================================== DNS */
async function dns(g) {
  PAGE.innerHTML = `<div class="loading">Loading DNS log...</div>`;
  const [d] = await Promise.all([soft(api(`/api/dev/dns?hours=${DS.hours}`)), statusBar()]);
  if (g !== gen) return;
  if (d.error) { PAGE.innerHTML = errBox(d.error); return; }
  const rows = d.rows.filter((r) => (!DS.flaggedOnly || r.lvl >= 2) && matchQ(r.name + " " + r.ips.join(" ")));
  const byBase = {};
  d.rows.forEach((r) => { byBase[r.base] = (byBase[r.base] || 0) + 1; });
  const tb = Object.entries(byBase).sort((a, b) => b[1] - a[1]).slice(0, 20);
  PAGE.innerHTML = `<div class="grid">
    ${panel(`Domain names this PC looked up <span class="muted">${d.rows.length} names, ${d.flagged} flagged</span>`, `<div class="iwbar" style="padding:6px 8px">
        ${segHTML("hw", [[24, "24H"], [168, "7D"], [720, "30D"], [8760, "ALL"]], DS.hours)}
        <label class="muted"><input type="checkbox" id="fo" ${DS.flaggedOnly ? "checked" : ""}> flagged only</label></div>
      <table class="t"><thead><tr><th class="l">Domain</th><th class="l">Resolved to</th><th class="l">Company</th><th>First seen</th><th>Last seen</th></tr></thead><tbody>${
        rows.slice(0, 1500).map((r) => `<tr><td class="l">${lvlTag(r.lvl)}<span class="${r.lvl ? "amber" : ""}">${esc(r.name)}</span></td><td class="l muted small">${esc(r.ips.join(" "))}</td>
          <td class="l muted">${esc(r.cat)}</td><td class="muted">${when(r.first)}</td><td class="muted">${when(r.last)}</td></tr>`).join("") || `<tr><td class='muted wrap'>${IS_WIN ? `Nothing recorded. Windows' own DNS cache is read every 30 seconds, but on this PC it is empty: Edge, Chrome and similar apps use their own
            secure DNS (DNS-over-HTTPS) and bypass it.` : `macOS doesn't let apps read its DNS cache, so this tab stays empty on a Mac.`}
            Host names on the WHO tab come from reverse lookups instead. To log every domain for every program, point the ${OSWORD}
            (or your router) at a Pi-hole / AdGuard Home DNS server.</td></tr>`}</tbody></table>`,
      { cls: "c8", scroll: true, maxh: 820, src: IS_WIN ? "Windows DNS client cache" : "" })}
    ${panel("Most looked-up base domains", `<div class="chart-box tall"><canvas id="dom-cv"></canvas></div>
      <div class="note">DNS lookups show <i>intent</i>: a domain is looked up just before a connection is made to it. Flags: .cn domains, and Chinese companies' domains (Baidu, Tencent/QQ, Alibaba, Huawei, Xiaomi, ByteDance, 360...).</div>`, { cls: "c4" })}
  </div>`;
  bindSeg("hw", (v) => { DS.hours = +v; saveD(); render(); });
  $("#fo").onchange = (e) => { DS.flaggedOnly = e.target.checked; saveD(); render(); };
  bars("dom-cv", tb.map(([b]) => b), [{ label: "names", data: tb.map(([, n]) => n), backgroundColor: "#f472b6" }], { horizontal: true, legend: false, fmt: (v) => fmt(v, 0) });
}

/* ================================================================== DATA (traffic) */
async function traffic(g) {
  const hrs = DS.trHours || 24;
  const [t] = await Promise.all([soft(api(`/api/dev/traffic?hours=${hrs}`)), statusBar()]);
  if (g !== gen) return;
  if (t.error) { PAGE.innerHTML = errBox(t.error); return; }
  const night = t.hourly.filter((x) => x.h >= 1 && x.h <= 5 && isNum(x.sent));
  const day = t.hourly.filter((x) => x.h >= 9 && x.h <= 21 && isNum(x.sent));
  const avg = (a) => (a.length ? a.reduce((s, x) => s + x.sent, 0) / a.length : null);
  const n = avg(night), dd = avg(day);
  PAGE.innerHTML = `<div class="grid">
    ${panel(`Upload / download ${segHTML("th", [[6, "6H"], [24, "24H"], [168, "7D"], [720, "30D"]], hrs)}`, `<div class="chart-box tall"><canvas id="tr-cv"></canvas></div>
      <div class="note">Total in window: uploaded <b>${bytes(t.tot_sent)}</b>, downloaded <b>${bytes(t.tot_recv)}</b>. Gaps = the PC was off or nothing was logging.</div>`, { cls: "c8", src: "network adapters (whole PC)" })}
    ${panel("Average upload by hour of day (30 days)", `<div class="chart-box tall"><canvas id="hr-cv"></canvas></div>
      <div class="note">${isNum(n) && isNum(dd) ? `Night (1-5am) upload averages <b>${bytes(n)}/h</b> vs <b>${bytes(dd)}/h</b> in the day.
        ${n > dd * 0.5 && n > 20 * 1048576 ? `<b class="down">That's high for an idle PC</b> - check WHO for what was connected overnight.` : `Night-time activity is low, which is what you'd expect from an idle ${OSWORD} (${IS_MAC ? "iCloud, Time Machine and software updates" : "Windows Update and Defender"} do wake up at night).`}`
        : "Needs some overnight logging (turn on always-on on the HOME tab)."}</div>`, { cls: "c4" })}
    ${panel(`Why only whole-${OSWORD} totals?`, `<div class="desc note">${IS_MAC ? "macOS" : "Windows"} does not give per-program byte counts to normal (non-admin) apps. What you <i>can</i> see per program is <b>who</b> it talks to and <b>when</b> (WHO and LIVE tabs).
      ${IS_MAC ? `To measure bytes per program, open <b>Activity Monitor</b> (Applications &gt; Utilities) and pick the <b>Network</b> tab: it shows sent/received bytes per process.`
        : `To measure bytes per program, use <b>Resource Monitor</b> (press Win+R, type <code>resmon</code>, open the Network tab). It shows send/receive bytes per process live.`}</div>`, { cls: "c12" })}
  </div>`;
  bindSeg("th", (v) => { DS.trHours = +v; saveD(); render(); });
  trafficChart("tr-cv", t);
  bars("hr-cv", t.hourly.map((x) => String(x.h).padStart(2, "0")), [{ label: "Upload/h", data: t.hourly.map((x) => x.sent), backgroundColor: t.hourly.map((x) => (x.h >= 1 && x.h <= 5 ? "#c084fc" : "#ffa028")) },
    { label: "Download/h", data: t.hourly.map((x) => x.recv), backgroundColor: "rgba(92,179,255,.35)" }], { fmt: (v) => bytes(v), yfmt: (v) => bytes(v) });
}

/* ================================================================== AUDIT */
async function audit(g, refresh) {
  PAGE.innerHTML = `<div class="loading">Auditing firmware, drivers, services, tasks, certificates and settings (takes 20-60 seconds the first time)...</div>`;
  const [a, l] = await Promise.all([soft(api(`/api/dev/audit${refresh ? "?refresh=1" : ""}`)), soft(api("/api/dev/listening")), statusBar()]);
  if (g !== gen) return;
  if (a.error) { PAGE.innerHTML = errBox(a.error); return; }
  const groups = [...new Set(a.checks.map((c) => c.group))];
  const sy = a.system || {};
  const lst = arr(l.rows).filter((r) => r.active);
  PAGE.innerHTML = `<div class="grid">
    <section class="panel c12"><div class="pb flush"><div class="intro dev">
      <b>${esc(sy.maker)} ${esc(sy.model)}</b> &middot; ${IS_MAC ? "firmware" : "BIOS"} ${esc(sy.bios)} &middot; ${esc(sy.os)} &middot;
      <span class="down">${a.score.alert} alert</span>, <span class="amber">${a.score.review} to review</span>, <span class="up">${a.score.ok} OK</span>
      <button class="btn sm" id="rerun" style="float:right">RE-RUN</button>
      <div class="muted small">Checked ${when(a.t)}. "Review" means "check you recognise this", not "malicious".</div></div></div></section>
    ${groups.map((gname) => panel(gname, a.checks.filter((c) => c.group === gname).map((c, i) => `<details class="chk" ${c.lvl ? "open" : ""}>
        <summary>${c.lvl ? lvlTag(c.lvl) : okTag()}<b>${esc(c.title)}</b></summary><div class="chk-d">${esc(c.detail)}</div>
        ${c.items.length ? `<table class="t"><tbody>${c.items.slice(0, 200).map((it) => `<tr><td class="l">${lvlTag(it.lvl)}${esc(it.a)}</td><td class="l muted">${esc(it.b)}</td>
          <td class="l muted small">${esc(it.c || "")}</td><td class="l muted small wrap">${esc(it.d || "")}</td></tr>`).join("")}</tbody></table>` : ""}</details>`).join(""), { cls: "c6" })).join("")}
    ${panel("Programs accepting connections from your network", lst.length ? `<table class="t"><thead><tr><th class="l">Program</th><th>Address</th><th>Port</th><th class="l">Signed by</th></tr></thead><tbody>${
      lst.map((r) => `<tr><td class="l">${r.exposed && !/microsoft/i.test(r.signer) ? lvlTag(1, "listens on every network interface") : ""}<span class="amber">${esc(r.proc)}</span></td><td>${esc(r.lip)}</td><td>${r.proto}/${r.lport}</td><td class="l">${signerHTML(r.signer)}</td></tr>`).join("")}</tbody></table>
      <div class="note">0.0.0.0 / :: = reachable from other devices on your network (the Windows Firewall still filters it).</div>` : `<div class="loading">None seen yet</div>`, { cls: "c6", src: "sockets in LISTEN state" })}
    ${!CAN_BLOCK ? panel("Blocking a program", `<div class="note">macOS's built-in firewall only blocks <i>incoming</i> connections. To stop a program sending data out, use <b>LuLu</b> (free, from objective-see.org) or Little Snitch: they ask you each time a new program tries to connect.</div>`, { cls: "c6" }) :
      panel("Programs you have blocked", arr(a.blocks).length ? `<table class="t"><tbody>${a.blocks.map((b) => `<tr><td class="l">${esc(b.prog)}</td><td>${esc(b.enabled)}</td>
      <td><button class="btn sm" data-block="${esc(b.prog)}" data-undo="1">UNBLOCK</button></td></tr>`).join("")}</tbody></table>` : `<div class="loading">None. Use BLOCK on the LIVE or WHO tab.</div>`, { cls: "c6" })}
  </div>`;
  $("#rerun").onclick = () => audit(gen, true);
  bindBlock();
}

/* ================================================================== ALERTS */
async function alerts(g) {
  const [e] = await Promise.all([soft(api("/api/dev/events")), statusBar()]);
  if (g !== gen) return;
  const rows = arr(e.rows);
  PAGE.innerHTML = `<div class="grid">${panel("Event log", `<table class="t"><thead><tr><th>When</th><th></th><th class="l">What happened</th><th class="l">Detail</th></tr></thead><tbody>${
    rows.map((r) => `<tr><td class="muted">${when(r.ts)}</td><td>${r.level ? lvlTag(r.level) : `<span class="stag" style="--c:#5cb3ff">NEW</span>`}</td><td class="l wrap">${esc(r.msg)}</td><td class="l muted small">${esc(r.ref)}</td></tr>`).join("")
    || "<tr><td class='muted'>No events yet</td></tr>"}</tbody></table>
    <div class="note">Logged automatically: a program using the network for the first time (NEW), a program that isn't signed (REVIEW), and any connection to a network registered in China / Hong Kong / Macau or owned by a Chinese company (ALERT).</div>`,
  { cls: "c12", scroll: true, maxh: 820 })}</div>`;
}

/* ================================================================== HOW */
async function about(g) {
  const s = await statusBar();
  if (g !== gen) return;
  PAGE.innerHTML = `<div class="grid">
    ${panel("What Device Watch does", `<div class="desc note">
      <p>Device Watch answers two questions about this ${OSWORD}: <b>what is it talking to</b>, and <b>${IS_MAC ? "is anything installed that shouldn't be" : "did the manufacturer put anything on it"}</b>. It was built for a budget mini PC from a Chinese OEM, and works on Windows 10/11 and macOS.</p>
      <ul class="insights">
        <li><b>Every connection</b>: every ${s.interval || 5} seconds it lists every open network connection and which program opened it${s.partial ? " (on a Mac without <code>sudo</code>: your own programs only)" : ""}. Nothing is sent anywhere; the log stays in <code>${esc(s.log || "")}</code>.</li>
        <li><b>Who owns each address</b>: each public IP is looked up at the official internet registry for its region (ARIN, RIPE, APNIC...), which says which company owns it and in which country. Only the IP address is sent, nothing about you.</li>
        <li><b>Who made each program</b>: each program's digital signature is checked (${IS_MAC ? "with Apple's <code>codesign</code>" : "Authenticode"}). Unsigned programs talking to the internet are flagged.</li>
        ${IS_WIN ? `<li><b>DNS</b>: the domain names Windows looked up (from its DNS cache) show which services were contacted by name.</li>` : ""}
        <li><b>AUDIT</b>: ${IS_MAC ? `checks System Integrity Protection, Gatekeeper, FileVault, the firewall, device-management (MDM) enrollment, launch agents &amp; daemons, system extensions, apps and their signatures, added trusted certificates, proxy/DNS settings, remote access and accounts.`
          : `checks the places an OEM can plant software: the <b>WPBT</b> firmware table (BIOS-injected programs that survive a Windows reinstall), drivers, services, scheduled tasks, startup entries, root certificates, proxy/DNS settings, remote-access tools and accounts.`}</li>
      </ul>
      <p><b>What it can't see.</b> Traffic is encrypted, so it shows <i>who / when / how often</i>, not the contents. Anything running <i>below</i> the operating system (firmware, management chips) is invisible to any program on this ${OSWORD}.
      For a check this ${OSWORD} can't fake, look at your <b>router's</b> traffic log, or put it behind a Pi-hole / AdGuard Home DNS filter and compare what it reports with what's shown here.</p>
      <p><b>For context:</b> ${IS_MAC ? `most traffic you'll see is Apple (iCloud, software update, push notifications, Siri, App Store) plus whatever apps you installed. The concerning things would be: an unknown launch daemon, an MDM enrollment you didn't set up, an added root certificate, Chinese DNS servers, or connections to Chinese networks from a program you didn't install.`
        : `most PC makers ship a stock Windows image. Most traffic you'll see is Microsoft (Windows Update, Defender, telemetry, Edge, OneDrive), plus whatever apps you installed. The concerning things would be: a WPBT table, unknown services or tasks, a non-standard root certificate, Chinese DNS servers, or connections to Chinese networks from a program you didn't install.`}</p></div>`, { cls: "c7" })}
    ${panel("Settings", `<div class="form">
      <div class="note" style="padding:0"><b>Always-on logging</b>: ${s.always_on ? `<span class="up">ON</span>. ${IS_MAC ? "A LaunchAgent (~/Library/LaunchAgents/com.marketterminal.devicewatch.plist)" : "A shortcut in your Startup folder"} runs the logger in the background from login (no window).` :
        `<span class="amber">OFF</span>. Logging happens only while one of the apps is open. Turn it on to catch what happens overnight and while you're away.`}</div>
      <button class="btn primary" id="ao">${s.always_on ? "TURN OFF ALWAYS-ON" : "TURN ON ALWAYS-ON"}</button>
      <div class="note" style="padding:0">Collector: ${s.running ? "running" : "stopped"}, ${fmt(s.samples, 0)} samples this session, ${s.dests} addresses / ${s.programs} programs recorded.
        Running as administrator: ${s.admin ? "yes" : IS_WIN ? "no (not needed; BLOCK asks for permission when used)" : "no (start with <code>sudo</code> to see every program's connections)"}.</div>
      ${CAN_BLOCK ? "" : `<div class="note" style="padding:0">To <b>block</b> a program from sending data on a Mac, use <b>LuLu</b> (free, objective-see.org) or Little Snitch. macOS's built-in firewall only blocks incoming connections.</div>`}
      <button class="btn" id="clr">CLEAR NETWORK LOG</button></div>`, { cls: "c5" })}
  </div>`;
  $("#ao").onclick = async () => { const r = await soft(api(`/api/dev/always_on?on=${s.always_on ? 0 : 1}`)); if (r.error) alert(r.error); render(); };
  $("#clr").onclick = async () => { if (confirm("Delete the whole network log (connections, DNS, traffic, events)?")) { await soft(api("/api/dev/clear")); render(); } };
}

render();

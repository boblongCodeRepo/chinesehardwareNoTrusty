/* Shared helpers for Portfolio Lab and Signal Monitor (Terminal has its own copy in app.js). */
"use strict";
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const isNum = (v) => typeof v === "number" && isFinite(v);
const cls = (v) => (!isNum(v) || v === 0 ? "" : v > 0 ? "up" : "down");
const sign = (v) => (v > 0 ? "+" : "");
const enc = encodeURIComponent;
const arr = (x) => (Array.isArray(x) ? x : []);
function fmt(v, d = 2) { return isNum(v) ? v.toLocaleString("en-US", { minimumFractionDigits: d, maximumFractionDigits: d }) : "--"; }
const pct = (v, d = 2) => (isNum(v) ? `${sign(v)}${fmt(v, d)}%` : "--");
function big(v) {
  if (!isNum(v)) return "--";
  const a = Math.abs(v);
  if (a >= 1e12) return fmt(v / 1e12, 2) + "T";
  if (a >= 1e9) return fmt(v / 1e9, 2) + "B";
  if (a >= 1e6) return fmt(v / 1e6, 2) + "M";
  if (a >= 1e3) return fmt(v / 1e3, 1) + "K";
  return fmt(v, 0);
}
const money = (v) => (isNum(v) ? "$" + (Math.abs(v) >= 1e6 ? big(v) : fmt(v, 0)) : "--");
function ago(ts) {
  if (!ts) return "";
  const s = Date.now() / 1000 - ts;
  if (s < 3600) return Math.max(1, Math.round(s / 60)) + "m";
  if (s < 86400) return Math.round(s / 3600) + "h";
  return Math.round(s / 86400) + "d";
}
async function api(path) {
  const r = await fetch(path);
  const j = await r.json();
  if (!r.ok || (j && j.error && Object.keys(j).length === 1)) throw new Error(j.error || r.statusText);
  return j;
}
const soft = (p) => p.catch((e) => ({ error: e.message || String(e) }));
function setStatus(kind, text) { const s = $("#status"); if (s) { s.className = kind; $("#status-text").textContent = text; } }
function panel(title, body, o = {}) {
  return `<section class="panel ${o.cls || ""}" ${o.id ? `id="${o.id}"` : ""}>
    <div class="ph"><h3>${title}</h3>${o.tools || ""}<span class="src">${o.src || ""}</span></div>
    <div class="pb ${o.flush === false ? "" : "flush"} ${o.scroll ? "scroll" : ""}" ${o.maxh ? `style="max-height:${o.maxh}px"` : ""}>${body}</div></section>`;
}
const errBox = (e) => `<div class="err-box">&#9888; ${esc(e && e.message ? e.message : e)}</div>`;
function spark(vals, w = 80, h = 20) {
  const v = (vals || []).filter(isNum);
  if (v.length < 2) return "";
  const mn = Math.min(...v), mx = Math.max(...v), rg = mx - mn || 1;
  const pts = v.map((y, i) => `${((i / (v.length - 1)) * w).toFixed(1)},${(h - 2 - ((y - mn) / rg) * (h - 4)).toFixed(1)}`).join(" ");
  return `<svg width="${w}" height="${h}" viewBox="0 0 ${w} ${h}"><polyline fill="none" stroke="var(--blue)" stroke-width="1.2" points="${pts}"/></svg>`;
}
function segHTML(id, items, cur) {
  return `<span class="seg" id="${id}">${items.map((x) => { const [v, l] = Array.isArray(x) ? x : [x, x];
    return `<button type="button" data-v="${esc(v)}" class="${String(v) === String(cur) ? "on" : ""}">${esc(l)}</button>`; }).join("")}</span>`;
}
function bindSeg(id, fn) { $$(`#${id} button`).forEach((b) => (b.onclick = () => { $$(`#${id} button`).forEach((x) => x.classList.toggle("on", x === b)); fn(b.dataset.v); })); }
function store(key, val) {
  if (val === undefined) { try { return JSON.parse(localStorage.getItem(key)); } catch (e) { return null; } }
  try { localStorage.setItem(key, JSON.stringify(val)); } catch (e) { /* ignore */ }
  return val;
}
function downloadCSV(name, rows) {
  const csv = rows.map((r) => r.map((v) => { const s = v === null || v === undefined ? "" : String(v); return /[",\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; }).join(",")).join("\r\n");
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
  a.download = name; document.body.appendChild(a); a.click(); a.remove();
}

/* ---- charts */
Chart.defaults.color = "#8b8b92";
Chart.defaults.font.family = "Cascadia Mono, Consolas, monospace";
Chart.defaults.font.size = 11;
Chart.defaults.borderColor = "#202024";
const charts = {};
const PALETTE = ["#ffa028", "#5cb3ff", "#c084fc", "#34d27b", "#ff5252", "#ffd84a", "#2dd4bf", "#f472b6", "#a3a3a3", "#fb923c"];
const TIP = { backgroundColor: "#141416", borderColor: "#ffa028", borderWidth: 1, titleColor: "#ffa028" };
function mkChart(id, cfg) {
  const cv = document.getElementById(id);
  if (!cv) return null;
  if (charts[id]) charts[id].destroy();
  charts[id] = new Chart(cv, cfg);
  return charts[id];
}
function line(id, labels, ds, o = {}) {
  return mkChart(id, {
    type: "line",
    data: { labels, datasets: ds.map((d, i) => ({ borderWidth: 1.6, pointRadius: 0, tension: 0.15, spanGaps: true,
      borderColor: d.color || PALETTE[i % PALETTE.length], backgroundColor: d.bg || "transparent", fill: d.fill ?? false, borderDash: d.dash || [], ...d })) },
    options: {
      responsive: true, maintainAspectRatio: false, animation: false, interaction: { mode: "index", intersect: false },
      plugins: { legend: { display: o.legend ?? ds.filter((d) => !d.noLegend).length > 1, labels: { boxWidth: 12, color: "#cfcfcf", filter: (it, cd) => !cd.datasets[it.datasetIndex].noLegend } },
        tooltip: { ...TIP, filter: (c) => !c.dataset.noTip, callbacks: { label: (c) => ` ${c.dataset.label || ""}: ${(o.fmt || ((v) => fmt(v, 2)))(c.parsed.y)}` } } },
      scales: {
        x: { ticks: { maxTicksLimit: o.xticks || 8, maxRotation: 0 }, grid: { display: false } },
        y: { type: o.log ? "logarithmic" : "linear", position: "right", ticks: { maxTicksLimit: 8, callback: (v) => (o.yfmt || o.fmt || ((x) => fmt(x, 0)))(v) },
          ...(isNum(o.ymin) ? { min: o.ymin } : {}), ...(isNum(o.ymax) ? { max: o.ymax } : {}) },
      },
    },
  });
}
function bars(id, labels, ds, o = {}) {
  return mkChart(id, {
    type: "bar",
    data: { labels, datasets: ds.map((d) => ({ borderWidth: 0, ...(d.type === "line" ? { pointRadius: 0, tension: 0.15, borderWidth: 1.5 } : {}), ...d })) },
    options: {
      indexAxis: o.horizontal ? "y" : "x", responsive: true, maintainAspectRatio: false, animation: false, interaction: { mode: "index", intersect: false },
      plugins: { legend: { display: o.legend ?? ds.length > 1, labels: { boxWidth: 12, color: "#cfcfcf" } },
        tooltip: { ...TIP, callbacks: { label: (c) => ` ${c.dataset.label || ""}: ${(o.fmt || ((v) => fmt(v, 2)))(o.horizontal ? c.parsed.x : c.parsed.y)}` } } },
      scales: o.horizontal ? {
        y: { grid: { display: false }, ticks: { autoSkip: false, color: "#cfcfcf" } },
        x: { ticks: { callback: (v) => (o.yfmt || o.fmt || ((x) => fmt(x, 0)))(v) } },
      } : {
        x: { stacked: !!o.stacked, grid: { display: false }, ticks: { maxRotation: 0, autoSkip: true, maxTicksLimit: o.xticks || 14 } },
        y: { stacked: !!o.stacked, position: "right", ticks: { maxTicksLimit: 7, callback: (v) => (o.yfmt || o.fmt || ((x) => fmt(x, 0)))(v) } },
        ...(o.y2 ? { y2: { position: "left", grid: { display: false }, ticks: { maxTicksLimit: 6, callback: o.y2 } } } : {}),
      },
    },
  });
}

/* keep the shared local server alive while this window is open */
/* ...and reload once if the app's page files were updated since this window loaded them (otherwise old code keeps running) */
let PAGE_V = null;
function ping() {
  fetch("/api/ping").then((r) => r.json()).then((j) => {
    if (!j || !j.v) return;
    if (PAGE_V === null) PAGE_V = j.v;
    else if (j.v !== PAGE_V && !(document.activeElement && /INPUT|SELECT|TEXTAREA/.test(document.activeElement.tagName))) location.reload();
  }).catch(() => {});
}
ping(); setInterval(ping, 20000);
function openApp(path) { window.open(path, "_blank", "popup,width=1500,height=920"); }
function tickClock() {
  const el = $("#clocks");
  if (!el) return;
  const now = new Date();
  const ny = new Date(now.toLocaleString("en-US", { timeZone: "America/New_York" }));
  const m = ny.getHours() * 60 + ny.getMinutes(), wd = ny.getDay(), wk = wd > 0 && wd < 6;
  const st = wk && m >= 570 && m < 960 ? ["OPEN", "up"] : wk && m >= 240 && m < 570 ? ["PRE-MKT", "amber"] : wk && m >= 960 && m < 1200 ? ["AFTER-HRS", "amber"] : ["CLOSED", "down"];
  el.innerHTML = `<span>NY <b>${now.toLocaleTimeString("en-GB", { timeZone: "America/New_York", hour: "2-digit", minute: "2-digit" })}</b></span><span class="${st[1]}">US ${st[0]}</span>`;
}
tickClock(); setInterval(tickClock, 15000);
